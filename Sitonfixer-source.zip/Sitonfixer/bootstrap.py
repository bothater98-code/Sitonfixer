"""Create the pinned source environment. Downloads public source; never touches an iPhone."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

payload = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--destination', type=Path, default=Path('Sitonfixer-source'))
args = parser.parse_args()
destination = args.destination.resolve()
if destination.exists():
    raise SystemExit('El destino ya existe; no se sobrescribe: ' + str(destination))
manifest = json.loads((payload/'manifest.json').read_text(encoding='utf-8'))
patch = payload/'changes.patch'
if hashlib.sha256(patch.read_bytes()).hexdigest() != manifest['patch_sha256']:
    raise SystemExit('El parche no coincide con su manifiesto')
for entry in manifest['files']:
    relative = Path(entry['path'])
    if relative.is_absolute() or '..' in relative.parts:
        raise SystemExit('Ruta no válida en manifiesto')
    if hashlib.sha256((payload/'Sources'/relative).read_bytes()).hexdigest() != entry['sha256']:
        raise SystemExit('Un archivo de código no coincide con el manifiesto')
def git(*args):
    subprocess.run(['git', '-C', str(destination), *args], check=True)
destination.mkdir(parents=True)
git('init', '--quiet')
git('config', 'core.autocrlf', 'false')
git('remote', 'add', 'origin', manifest['base_repository'])
git('fetch', '--depth', '1', 'origin', manifest['base_commit'])
git('checkout', '--quiet', '--detach', 'FETCH_HEAD')
git('apply', '--check', str(patch))
git('apply', str(patch))
# The inherited publication workflows must not become active if this source is
# later put into another repository. Our build-only template lives under sitonfixer/.
for workflow in (destination/'.github/workflows').glob('*'):
    if workflow.suffix in ('.yml', '.yaml'):
        workflow.rename(workflow.with_suffix(workflow.suffix + '.disabled'))
print('Código preparado en:', destination)
print('No se ha compilado, firmado, instalado, conectado por USB ni publicado nada.')
print('En un ejecutor macOS: bash sitonfixer/prepare-macos.sh; después bash sitonfixer/build-macos.sh')
