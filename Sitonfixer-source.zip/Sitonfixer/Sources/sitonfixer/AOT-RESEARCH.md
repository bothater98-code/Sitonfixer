# Sitonfixer: pretranslation and local signing experiment

Goal: investigate an execution path that does not attach a debugger, create a VPN,
or request writable executable memory. This is a research gate, not a working Wii U AOT engine.

The app translates an internally generated PowerPC integer block into ARM64,
places it into a Mach-O carrier built from scalar-probe.S, signs it locally with
the person's existing development certificate, and loads that immutable signed image.
The imported certificate must occur in this app installation's embedded profile.
Its password and bytes are held in memory for this operation, never uploaded or saved.
This operation does not authenticate to Apple or install/renew any profile.

The probe refuses to run if CS_DEBUGGED/P_TRACED is present or cannot be checked.
It changes the arithmetic challenge every run and checks all 32 guest integer
registers after execution. The disposable image is removed after unloading.
Disconnect VPN and enable airplane mode for the physical device test.

Supported instructions: addi, addis, ori, add without OE/Rc, terminal blr.
Everything else is rejected. No guest RAM accesses, FPU, paired-single, exceptions,
timing, modules, GPU or game execution are implemented in this experimental path.
The normal emulator remains separate and still uses its existing JIT path.

The CI test executes 300 synthetic translated blocks under Unicorn ARM64 and
compares the resulting registers with an independent Python PowerPC reference.
This checks arithmetic semantics; it does not test Apple's loader, certificate
acceptance, TXM on iPhone 17, emulator compatibility, speed, or profile renewal.

Preconditions for the next stage:

1. Physical iPhone 17 accepts locally signed generated code without JIT/VPN.
2. Wider translation supports Wii U execution semantics and the core ABI.
3. Signed block batches support indirect dispatch and invalidation safely.
4. Measure real games; avoid claiming native speed before measurement.
5. Solve installation/profile renewal independently. A successful AOT probe does
   not remove the free account's expiry or prove VPN-free renewal.

Related primary implementation: https://github.com/LiveContainer/LiveContainer
(JIT-less loading of signed native applications; no LiveContainer code copied).

Signing uses apple-codesign-quick 0.1.0 (LGPL-2.1-or-later), already used by the
base project's isideload dependency, now called directly for local Mach-O signing.
Source: https://github.com/Dadoum/apple-crates
Published source: https://crates.io/crates/apple-codesign-quick/0.1.0
The full app source and build scripts are published so the dependency can be
rebuilt/relinked. Other upstream notices and licenses remain applicable.


SideStore certificate transfer is also supported without an export menu. Source
verified at SideStore 0.7.0-alpha commit 6032424a0e56c1c319762e786099bdd9186a238b:
SideStore/DeepLinks/URLHandler.swift and ExportCertificateDialog.swift.
It uses sidestore://certificate with an explicit confirmation in SideStore.
Sitonfixer accepts only a fresh, single-use 120-second nonce, bounds the input,
keeps the result in memory and does not log the URL. This upstream SideStore
implementation logs its outgoing callback URL locally; do not upload its logs.
A successful callback is not a signing-validation result; the probe also checks
that the certificate occurs in this installation's provisioning profile.
