#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -s)" == Darwin ]] || { echo 'Compilación iOS requiere macOS/Xcode.' >&2; exit 2; }
for tool in xcodebuild xcodegen cmake ninja rustup; do command -v "$tool" >/dev/null; done
export VCPKG_BINARY_SOURCES="clear;files,$PWD/.vcpkg-archives,readwrite"
export IPHONEOS_DEPLOYMENT_TARGET=17.4
bash sitonfixer/typecheck-ios.sh
bash ci/build-core.sh
bash ci/gate-exports.sh
bash ci/build-jit-ffi.sh
(cd src/ios && xcodegen generate)
xcodebuild -project src/ios/MuffinEMU.xcodeproj -scheme MuffinEMU \
  -configuration Release -sdk iphoneos -destination 'generic/platform=iOS' \
  -derivedDataPath "$PWD/.sitonfixer-derived" CODE_SIGNING_ALLOWED=NO build \
  2>&1 | tee sitonfixer/xcodebuild-local.log
app="$PWD/.sitonfixer-derived/Build/Products/Release-iphoneos/Sitonfixer.app"
test ! -d "$app/PlugIns/IslaLocalTunnel.appex"
test -d "$app/PlugIns/MuffinJITHelper.appex"
mkdir -p sitonfixer-dist/Payload
cp -R "$app" sitonfixer-dist/Payload/
/usr/bin/ditto -c -k --keepParent sitonfixer-dist/Payload sitonfixer-dist/Sitonfixer-unsigned.ipa
echo 'IPA compilada sin firma. El instalador debe conservar get-task-allow y el auxiliar JIT.'
