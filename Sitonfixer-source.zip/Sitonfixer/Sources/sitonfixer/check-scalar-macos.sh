#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
testdir="$(mktemp -d "${TMPDIR:-/tmp}/sitonfixer-check.XXXXXX")"
trap 'rm -rf "$testdir"' EXIT
xcrun swiftc src/ios/AOT/ScalarTranslation.swift src/ios/AOT/CertificateCallback.swift sitonfixer/tests/main.swift -o "$testdir/translator-check"
python3 -m venv "$testdir/venv"
"$testdir/venv/bin/pip" -q install unicorn==2.1.4
"$testdir/venv/bin/python" sitonfixer/tests/check-translator.py "$testdir/translator-check"

xcrun clang++ -std=c++20 -Isitonfixer/tests/include -Isrc/Cafe/HW/Espresso/Recompiler -Isrc sitonfixer/tests/instruction-window.cpp -o "$testdir/instruction-window-check"
"$testdir/instruction-window-check"
