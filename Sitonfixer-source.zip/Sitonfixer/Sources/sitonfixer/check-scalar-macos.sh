#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
testdir="$(mktemp -d "${TMPDIR:-/tmp}/sitonfixer-check.XXXXXX")"
trap 'rm -rf "$testdir"' EXIT
xcrun swiftc src/ios/AOT/ScalarTranslation.swift sitonfixer/tests/main.swift -o "$testdir/translator-check"
python3 -m venv "$testdir/venv"
"$testdir/venv/bin/pip" -q install unicorn==2.1.4
"$testdir/venv/bin/python" sitonfixer/tests/check-translator.py "$testdir/translator-check"
