#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
testdir="$(mktemp -d "${TMPDIR:-/tmp}/sitonfixer-check.XXXXXX")"
trap 'rm -rf "$testdir"' EXIT
xcrun swiftc src/ios/AOT/ScalarTranslation.swift src/ios/AOT/CertificateCallback.swift sitonfixer/tests/main.swift -o "$testdir/translator-check"
python3 -m venv "$testdir/venv"
"$testdir/venv/bin/pip" -q install unicorn==2.1.4
"$testdir/venv/bin/python" sitonfixer/tests/check-translator.py "$testdir/translator-check"
git submodule update --init --depth 1 dependencies/xbyak_aarch64
"$testdir/venv/bin/python" sitonfixer/tests/check-interface.py
"$testdir/venv/bin/python" sitonfixer/tests/check-dispatch.py
python3 sitonfixer/tests/check-initialization.py
"$testdir/venv/bin/python" sitonfixer/tests/check-interpreter.py
"$testdir/venv/bin/python" sitonfixer/tests/check-mixed.py
xcrun swiftc -swift-version 5 src/ios/AOT/ResearchOperationGate.swift sitonfixer/tests/research-gate/main.swift -o "$testdir/research-gate-check"
"$testdir/research-gate-check"
bash sitonfixer/build-probe-template.sh
xcrun swiftc src/ios/AOT/ScalarTranslation.swift src/ios/AOT/SignedProbeModule.swift \
  sitonfixer/tests/modules/main.swift -o "$testdir/module-check"
"$testdir/module-check" src/ios/Resources/AOT/scalar-probe.bin "$testdir/module.dylib"
"$testdir/venv/bin/python" sitonfixer/tests/check-module.py \
  src/ios/Resources/AOT/scalar-probe.bin "$testdir/module.dylib"
bash sitonfixer/check-module-loader-macos.sh

xcrun clang++ -std=c++20 -Isitonfixer/tests/include -Isrc/Cafe/HW/Espresso/Recompiler -Isrc sitonfixer/tests/instruction-window.cpp -o "$testdir/instruction-window-check"
"$testdir/instruction-window-check"
