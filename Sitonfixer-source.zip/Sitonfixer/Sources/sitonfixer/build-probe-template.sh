#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p src/ios/Resources/AOT
xcrun --sdk iphoneos clang -target arm64-apple-ios17.4 -dynamiclib \
  -Wl,-install_name,@rpath/SitonfixerModule-00000000-0000-0000-0000-000000000000.dylib -Wl,-headerpad,0x4000 \
  -Wl,-exported_symbol,_sitonfixer_aot_probe \
  sitonfixer/scalar-probe.S -o src/ios/Resources/AOT/scalar-probe.bin
