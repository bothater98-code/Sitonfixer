#!/bin/bash
# Sitonfixer. SPDX-License-Identifier: MPL-2.0
set -euo pipefail
cd "$(dirname "$0")/.."
folder="$(mktemp -d "${TMPDIR:-/tmp}/sitonfixer-frontend.XXXXXX")"
trap 'rm -rf "$folder"' EXIT
xcrun clang++ -std=c++20 -Wall -Wextra -Werror -Isrc \
  sitonfixer/tests/instruction-window.cpp -o "$folder/window"
"$folder/window"
xcrun clang++ -std=c++20 -Wall -Wextra -Werror -Wno-logical-op-parentheses -Wno-unused-parameter \
  -Isitonfixer/tests/stubs -Isrc sitonfixer/tests/instruction-boundaries.cpp -o "$folder/boundaries"
"$folder/boundaries"
python3 sitonfixer/check-frontend-loop.py
echo 'Private instruction window and real boundary tracker tests passed; no global RAM read in the private path.'
