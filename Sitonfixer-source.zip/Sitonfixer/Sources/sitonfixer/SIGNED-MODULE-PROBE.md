# Controlled larger signed module fixture (revision 10)

Revision 9 passed 32 real PowerPC frontend cases on the device after the requested
offline reboot procedure. Revision 10 keeps that exact core fixture unchanged.

The platform assembler/linker now builds a carrier with a 65,536-byte __text
section aligned to 16,384 bytes. This is a fixed-capacity research carrier, not a
variable-size Mach-O builder. The runtime patches only the existing text range;
it does not move segments, load commands, symbols or signature offsets. The local
signer then regenerates the image's signature using the same host identity rules.

The original frontend wrapper/body is at text offset 32,768. Entry zero contains
a five-instruction ABI bridge calling it. Entry 49,152 contains another bridge
calling entry zero, which in turn calls the real frontend body. Bridges preserve
x29/x30 and the stack, and forward x0/x1 (CPU/RAM). The native frontend wrapper
continues to preserve the wider set of ABI registers as in revision 9.

The independent core checker is invoked for each of these three entry offsets,
with 32 CPU/RAM inputs each. The direct body, one bridge and two nested bridges
must each produce the same expected PowerPC semantics, including cycle counts.
The user-facing success result requires all 96 checks. Generation/check failures
use SF-MODULE; signed-loader failures remain SF-LOAD. Clean-process guards remain
in place. No identity persistence, networking or debugger operation is added.

The native preflight compiles the actual Swift composer, patches the actual
platform-linked carrier, checks the exported symbol is at the section start and
that all bytes outside text are unchanged. An independent Unicorn ARM64 emulator
executes all three entries with a small increment stub, checking call/return,
argument forwarding, callee-saved registers, stack and canary memory. That test
does not replace physical iOS signature validation or the device's Cemu checker.

Passing this fixture would demonstrate a larger signed image and cross-page
native function calls around one real PowerPC program. Game function publication,
entry/exit stubs, module ownership/invalidation/shutdown, batching, persistent
cache relocations, games/performance and profile renewal remain separate work.
