# Real Cemu ARM64 backend probe

This bounded integration gate reuses AArch64GenContext_t and real IMLInstruction builders. It does not use the scalar Swift translator, PPC instruction decoding, global guest memory, the scheduler, game files, or the normal recompiler initialization path.

The C ABI prepare function emits into an explicitly writable-only AArch64Allocator. It cannot call finalize; useProtect is false. Xbyak resolves internal labels without requesting executable permissions. The caller copies at most 1028 bytes into the existing Mach-O template and signs that image using the already validated local signer. The library and Cemu framework stay loaded until all calls finish, then unload in dependency order.

The entry uses the native C ABI with private PPCInterpreter_t and 64-byte guest RAM fixtures. It preserves all used callee-saved registers and stack alignment. Real backend methods implement integer register transfers, add, big-endian load/store, divw (including zero and signed overflow branches), double addition/multiplication and an indirect absolute host helper call. The checker tests 32 input cases including boundary values, all GPR/FPR canaries and all 64 RAM bytes. It returns bounded numeric diagnostics, without account identifiers or logs.

No debug attach, VPN, network operation, production code publication, game launch, or signature renewal is implemented here. Successful compilation is not proof of successful device execution. A physical cold app start without USB, network, VPN or prior JIT remains required. The normal scalar regression path remains available.

Next gates after a successful device result: PPC frontend/IML integration, signed publication of function and bootstrap code, safe immutable module leases through compiler/scheduler shutdown, invalidation correctness, bounded batching/cache and measured title performance. Do not replace the production allocator with a per-function dlopen loop before these lifetime and performance questions are resolved.
