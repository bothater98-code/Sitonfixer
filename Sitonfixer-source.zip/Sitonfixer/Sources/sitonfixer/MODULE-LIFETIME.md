# Reusable fixed-carrier loader: revision 11

Revision 10 passed the requested device reboot test: one 64 KiB code carrier,
three entries and 96 real frontend checks. Revision 11 adds scoped ownership of
loaded images and distinct identities before signing. Device validation of this
revision remains pending.

`SignedCodeImage` accepts the trusted 64 KiB carrier and bounded entry offsets.
It patches text using the existing parser, then replaces LC_UUID and the name in
the preallocated LC_ID_DYLIB slot. It never moves commands or segments. The new
identity is set before the local signature is generated; CodeDirectory identity
rules and the signer's filename restriction are unchanged. The private key,
password and provisioning profile are not stored in the loaded-module object.

`SignedCodeModule` owns one dlopen reference and its temporary directory. A
directory is created exclusively with mkdir; failing to create it cannot cause
cleanup of another live image's files. Signing/validation/loading failures clean
up only the directory that this load created. Native pointers are borrowed inside
`withEntry` and must not escape the closure. Closing rejects new calls immediately
and defers dlclose/file cleanup until the last existing call finishes. The finalizer
runs once and outside the lifetime lock.

This balances loader references; it does not promise that the OS unmaps an image
immediately. Apple's [dynamic library usage guidelines](https://developer.apple.com/library/archive/documentation/DeveloperTools/Conceptual/DynamicLibraries/100-Articles/DynamicLibraryUsageGuidelines.html)
describe the reference count and the loader's ability to retain an image after
the count reaches zero.

The device probe opens two images together, with marker entries returning 0x1357
and 0x2468. Each also contains the unchanged PPC9 frontend body and its two native
bridges, for 96 checks per image (192 total). Closing A while its entry is borrowed
must keep that borrowed call valid, reject a new call and finalize after the
borrow ends; B must still return its own marker. Both owned files must be cleaned
up. SF-LIFE identifies preparation/ownership checks; SF-LOAD identifies loading.

The native preflight builds the same assembly carrier for ARM64 macOS and uses
the actual Swift image factory and loader with ad hoc signing, without phone
credentials. It checks header edits, malformed identity slots, entry bounds,
process/signing failure cleanup, a duplicate identity collision, two distinct
simultaneous native images, cross-page calls, deferred close and continued use of
the other image. A separate two-thread test checks the lifetime finalizer runs
once only after all active borrowers finish. These checks do not validate iOS's
provisioning/signing policy; the physical offline reboot test is still required.

The game dispatcher still does not use this loader. Publishing native pointers
in Cemu's tables needs an explicit session owner spanning all guest/native worker
threads and a shutdown/invalidation contract. Scoped probe calls do not establish
that contract for escaped or published pointers. Game memory initialization,
several guest functions and dispatcher calls, batching/budgets, performance,
persistent cache relocations and renewal remain separate work.
