#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
sdk="$(xcrun --sdk iphoneos --show-sdk-path)"
xcrun --sdk iphoneos swiftc -typecheck -swift-version 5 \
  -sdk "$sdk" -target arm64-apple-ios17.4 \
  sitonfixer/typecheck-stubs.swift \
  src/ios/JIT/LocalJITEndpointResolver.swift \
  src/ios/LocalTunnel/LocalGameLaunchGate.swift \
  src/ios/LocalTunnel/LocalPairingSection.swift \
  src/ios/LocalTunnel/LocalRuntimeSection.swift \
  src/ios/LocalTunnel/PaperMarioCompatibility.swift \
  src/ios/AOT/ScalarTranslation.swift \
  src/ios/AOT/SignedProbeModule.swift \
  src/ios/AOT/ModuleLifetime.swift \
  src/ios/AOT/SignedCodeImage.swift \
  src/ios/AOT/SignedCodeModule.swift \
  src/ios/AOT/ManagedModuleProbe.swift \
  src/ios/AOT/DispatchModuleProbe.swift \
  src/ios/AOT/CertificateCallback.swift \
  src/ios/AOT/OfflineProbe.swift \
  src/ios/AOT/OfflineCertificateTransfer.swift \
  src/ios/AOT/OfflineProbeSection.swift
echo 'New native components passed iOS API/type checks; full app compilation still required.'
