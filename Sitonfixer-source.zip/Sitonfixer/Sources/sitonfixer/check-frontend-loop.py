"""Compile the actual loop classifier in a narrow native fixture.

Only the two containing records are stand-ins; instruction decoding, private
instruction provider, tracker and the classifier body are the production sources.
This catches missing-scope errors before the expensive full iOS build.
"""
import argparse
import pathlib
import subprocess
import tempfile

parser = argparse.ArgumentParser()
parser.add_argument('--compiler')
args = parser.parse_args()
root = pathlib.Path(__file__).resolve().parents[1]
source = (root/'src/Cafe/HW/Espresso/Recompiler/PPCRecompilerImlGen.cpp').read_text(encoding='utf-8')
start = source.index('bool PPCRecompiler_IsBasicBlockATightFiniteLoop(')
opening = source.index('{', start)
depth, end = 1, opening + 1
while depth:
    depth += (source[end] == '{') - (source[end] == '}')
    end += 1
function = source[start:end]
fixture = '''
#define main boundary_fixture_main
#include "instruction-boundaries.cpp"
#undef main
struct IMLSegment { IMLSegment* nextSegmentBranchTaken = nullptr; };
struct PPCBasicBlockInfo { uint32 lastAddress; };
#define PPC_OPC_TEMPL_B(op, BO, BI, BD) do { BO = ((op) >> 21) & 31; BI = ((op) >> 16) & 31; BD = (op) & 0xfffc; } while (0)
''' + function + '''
int main() {
    const uint32 words[] = {be(0x4200fffc), be(0x4182fffc)};
    PPCInstructionWindow window(0x1000, words, 2);
    PPCFunctionBoundaryTracker tracker(&window);
    IMLSegment segment; segment.nextSegmentBranchTaken = &segment;
    PPCBasicBlockInfo info{0x1000};
    assert(PPCRecompiler_IsBasicBlockATightFiniteLoop(tracker, &segment, info));
    info.lastAddress = 0x1004;
    assert(!PPCRecompiler_IsBasicBlockATightFiniteLoop(tracker, &segment, info));
    segment.nextSegmentBranchTaken = nullptr;
    info.lastAddress = 0x1008;
    assert(!PPCRecompiler_IsBasicBlockATightFiniteLoop(tracker, &segment, info));
    assert(globalReads == 0);
    segment.nextSegmentBranchTaken = &segment;
    rejects([&]{PPCRecompiler_IsBasicBlockATightFiniteLoop(tracker, &segment, info);});
    assert(globalReads == 0);
}
'''
with tempfile.TemporaryDirectory(prefix='sitonfixer-loop-') as folder:
    folder = pathlib.Path(folder)
    cpp, executable = folder/'classifier.cpp', folder/'classifier.exe'
    cpp.write_text(fixture, encoding='utf-8')
    compiler = [args.compiler] if args.compiler else ['xcrun', 'clang++']
    subprocess.run(compiler + ['-std=c++20', '-Wall', '-Wextra', '-Werror',
        '-Wno-unused-parameter', '-Wno-logical-op-parentheses', '-Wno-unused-but-set-variable',
        '-I'+str(root/'sitonfixer/tests/stubs'), '-I'+str(root/'sitonfixer/tests'),
        '-I'+str(root/'src'), str(cpp), '-o', str(executable)], check=True)
    subprocess.run([str(executable)], check=True)
print('Actual finite-loop classifier compiled and passed private-window cases; no global RAM reads.')
