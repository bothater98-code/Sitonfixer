# Revisión 16: módulos firmados e intérprete sobre CPU y RAM de Cemu

La revisión 15 pasó según la respuesta del usuario al protocolo explícito de
reinicio completo sin USB, red ni VPN: ocho condiciones, 32 casos y 320 llamadas
al intérprete real. No requería .p12 y no ejecutaba módulos firmados.

La 16 inicializa el mismo motor y obtiene la dirección invitada del bloque de
4 KiB SysAllocator de la 15. Prepara la función A mediante el frontend,
optimizador, asignador de registros y backend reales de Cemu en esa dirección
de la sesión. Incluye entrada y dos salidas compartidas en un módulo de 64 KiB,
que el host firma y carga localmente con el .p12 del perfil actual.

El recorrido es A firmada (mflr/add/bl), salida al host en B sin entrada
compilada, cuatro llamadas acotadas a PPCInterpreterSlim_executeInstruction
(stw/lwz/addi/blr), y reentrada en la continuación firmada de A (mtlr/addi/blr).
La misma CPU y memory_base reales se usan en los tres tramos. No se cambia el
hook global attemptEnterAddr ni se publica una función en tablas de juegos.

La tabla privada reserva 512 MiB virtuales con MemMapper, sin recorrerlos ni
rellenarlos. Solo compromete la página del slot cero y la de A/B/continuación
según el tamaño de página real. Comprueba que las tres entradas caben en esa
página. Las páginas comprometidas se rellenan con la salida elegida antes de
publicar las dos entradas conocidas de A. Se prueban ambas salidas, 32 estados
cada una: 64 casos y 256 pasos interpretados. La reserva puede ser rechazada en
iOS: el fallo devuelve un diagnóstico y libera lo ya reservado, sin iniciar JIT.
Su viabilidad física sigue pendiente de la prueba en el dispositivo.

El checker verifica estado intermedio y final, CPU, SPR, FPR, CR/FPSCR/XER,
RAM big-endian, código y guardas del bloque completo. La API Slim no descuenta
ciclos; el fixture descuenta uno explícitamente antes de cada paso. Se espera
1000 → 997 → 993 → 990. Es contabilidad del ensayo, sin validar scheduler,
interrupciones ni tiempos de juego.

Los cinco préstamos withEntry siguen vivos durante toda la llamada C++ y ambas
salidas. Al retornar se cierra el módulo y se comprueba su eliminación. La tabla
privada se libera por RAII y los 4 KiB propios se limpian; la asignación del
motor permanece hasta terminar el proceso. Se usa el mismo bloqueo de proceso
que 14/15, sin cancelación insegura ni solapamiento con juegos u otras pruebas.

El test host ejecuta el checker y ensamblador de imagen reales con interfaces
sustitutas de CPU, inicialización, allocator, MemMapper y emisión de código.
Unicorn PPC32 sirve de referencia para cada tramo; los callbacks de entrada
no son ARM64 firmado. Comprueba 64/256, ambas salidas, peticiones de reserva y
dos páginas, liberación, corrupción y rechazos. No demuestra frontend/backend
de producción, reserva virtual iOS ni ejecución firmada. La compilación completa
y la prueba física cubren esas fronteras.

Prueba física, solo después de instalar y verificar: primer arranque con Internet
si iOS exige confianza inicial, desconectar USB/VPN, avión y Wi-Fi apagado,
reinicio completo offline, abrir desde icono. En JIT → Pruebas de módulos
firmados (.p12), elegir el certificado local ya existente y contraseña vacía;
pulsar directamente Probar puente mixto de Cemu, sin pulsar antes 14/15.
Esperado 64 casos, 256 pasos y dos páginas, o SF-MIX con el diagnóstico. Después
cerrar completamente la app. No atribuir juegos, rendimiento, invalidación de
producción ni renovación autónoma a este resultado.
