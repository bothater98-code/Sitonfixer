# Revisión 14: inicialización real, sin título

La revisión 13 pasó físicamente, según la respuesta del usuario al protocolo de
reinicio completo sin USB/red/VPN: 192 comprobaciones, dos funciones distintas y
dos módulos firmados. Esto no demostraba que la inicialización de Cemu y su MMU
completas funcionase en ese mismo estado del proceso.

El botón nuevo **Probar inicialización real de Cemu** no utiliza certificados,
firma módulos ni activa JIT. Llama al puente normal de inicialización, que llama
`CemuInitialize`, `CafeSystem::Initialize`, `memory_init`, PPCCore, RPLLoader y
los subsistemas persistentes existentes. Selecciona el intérprete en memoria,
sin guardar preferencias del usuario. No prepara ni inicia un título.

## Resultado y exclusión

El puente ya usaba `g_initialized` como cerrojo de entrada y lo ponía a true
antes de terminar. Se añade una señal atómica distinta, publicada solamente al
final del puente. El diagnóstico exige ocho condiciones (máscara 255):

1. El puente ha llegado al final.
2. `CemuIsInitialized()` confirma que el núcleo terminó.
3. Existe `memory_base`.
4. La zona inicial CEMU_AREA está mapeada.
5. La zona inicial SHARED_AREA está mapeada.
6. El puente ha seleccionado intérprete y no solicita recompilador.
7. El proceso sigue limpio: csops conocido, sin CS_DEBUGGED, sysctl conocido,
   sin P_TRACED. Se exige también antes de inicializar.
8. No hay título iniciado.

Estas comprobaciones de metadatos NO leen/escriben toda la RAM ni prueban cada
página, instrucciones del intérprete, un juego o rendimiento.

GameManager acepta la prueba solo estando idle, sin preparación de lanzamiento
ni reinicio limpio pendiente. Comprueba y reclama la sesión en MainActor antes
de suspenderse. Hasta cerrar el proceso, se rechazan lanzamientos y se evita
shutdown desde stopEmulation. Un cerrojo compartido excluye otras pruebas
sintéticas, incluso si se sale y vuelve a entrar a Ajustes mientras siguen en
segundo plano. No se libera la reserva de inicialización al cancelar o salir de
la vista, ni se intenta cancelar la llamada C++.

El diagnóstico nativo rechaza una segunda llamada y una inicialización previa,
un título existente o un proceso depurado. Devuelve código y máscara fijos,
sin rutas, cuenta, claves ni registros. La UI guarda solo las etiquetas
`initializing`/`returned` en UserDefaults. Un marcador pendiente al siguiente
arranque significa que no se registró el resultado; no identifica causa ni
demuestra un rechazo de memoria. No se declara éxito tras un cierre de la app.

## Límites y prueba física pendiente

La inicialización original puede finalizar el proceso si no consigue reservar
la ventana MMU o mapear una zona. No se oculta ni se cambia ese comportamiento.
Una excepción capturable no cruza el ABI; queda como SF-INIT. Ningún temporizador
finge cancelación o éxito. El intento requiere cerrar completamente la app
antes de continuar y se limita al sandbox de Sitonfixer Prueba.

El test nativo compila el diagnóstico real con sustitutos de inicialización y
SO: comprueba cada bit independiente, errores de consulta, depurador, estado
previo, excepción, argumentos y repetición. No es un arranque real de Cemu. El
SDK iOS y el enlace del motor se comprueban en CI. La ejecución real requiere
instalación y respuesta física al protocolo de reinicio sin USB/red/VPN, usando
el botón nuevo y sin seleccionar ningún .p12.

Siguen pendientes ejecución real del intérprete, integración de módulos con la
sesión y tablas de juegos, invalidación y cierre con todos los joins completos,
gráficos/audio/partidas/rendimiento y renovación autónoma de firma.
