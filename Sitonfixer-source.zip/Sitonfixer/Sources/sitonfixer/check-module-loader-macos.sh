#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -m)" == arm64 ]] || { echo 'Native loader check requires an ARM64 Mac runner.' >&2; exit 1; }
folder="$(mktemp -d "${TMPDIR:-/tmp}/sitonfixer-loader.XXXXXX")"
trap 'rm -rf "$folder"' EXIT
xcrun --sdk macosx clang -target arm64-apple-macos13.0 -dynamiclib \
  -Wl,-install_name,@rpath/SitonfixerModule-00000000-0000-0000-0000-000000000000.dylib \
  -Wl,-headerpad,0x4000 -Wl,-exported_symbol,_sitonfixer_aot_probe \
  sitonfixer/scalar-probe.S -o "$folder/carrier.dylib"
xcrun swiftc -swift-version 5 src/ios/AOT/ScalarTranslation.swift \
  src/ios/AOT/SignedProbeModule.swift src/ios/AOT/ModuleLifetime.swift \
  src/ios/AOT/SignedCodeImage.swift src/ios/AOT/SignedCodeModule.swift \
  sitonfixer/tests/module-loader/main.swift -o "$folder/loader-check"
"$folder/loader-check" "$folder/carrier.dylib"
