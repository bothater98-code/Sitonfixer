"""Compile the actual shared entry/exit emitter methods, then emulate their ABI.

The small CPU layout here is deliberately a test layout. The full iOS core build
and physical fixture separately verify the production layout and frontend.
"""
import pathlib, subprocess, tempfile, struct
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM, UC_HOOK_CODE
from unicorn.arm64_const import *

root = pathlib.Path(__file__).resolve().parents[2]
backend = (root/'src/Cafe/HW/Espresso/Recompiler/BackendAArch64/BackendAArch64.cpp').read_text()
start = backend.index('void AArch64GenContext_t::enterRecompilerCode(bool runtimeContext)')
end = backend.index('bool PPCRecompiler_emitAArch64InterfaceBytes(', start)
methods = backend[start:end]
source = r'''
#include <xbyak_aarch64.h>
#include <cstdint>
#include <cstdlib>
#include <cstddef>
#include <fstream>
using namespace Xbyak_aarch64;
using uint64 = uint64_t;
struct PPCInterpreter_t { uint32_t instructionPointer; };
void* ppcRecompilerInstanceData = reinterpret_cast<void*>(0x77770000);
void* memory_base = reinterpret_cast<void*>(0x88880000);
static const XReg HCPU_REG{29}, PPC_REC_INSTANCE_REG{27}, MEM_BASE_REG{28};
struct SavedReg { const ::WReg WReg{26}; };
static const SavedReg LR{};
struct WritableAllocator : Allocator {
    uint32_t* alloc(size_t size) override { return static_cast<uint32_t*>(std::malloc(size)); }
    void free(uint32_t* p) override { std::free(p); }
    bool useProtect() const override { return false; }
};
struct AArch64GenContext_t : CodeGenerator {
    explicit AArch64GenContext_t(Allocator* a) : CodeGenerator(4096, AutoGrow, a) {}
    void enterRecompilerCode(bool runtimeContext = false);
    void leaveRecompilerCode();
};
'''+methods+r'''
int main(int argc, char** argv) {
    if (argc != 2) return 1;
    WritableAllocator allocator;
    AArch64GenContext_t code(&allocator);
    code.enterRecompilerCode(true);
    while (code.getSize() % 16) code.nop();
    const uint64_t unvisited = code.getSize();
    code.leaveRecompilerCode();
    while (code.getSize() % 16) code.nop();
    const uint64_t visited = code.getSize();
    code.leaveRecompilerCode();
    code.ready(CodeArray::PROTECT_RW);
    std::ofstream out(argv[1], std::ios::binary);
    out.write(reinterpret_cast<const char*>(&unvisited), sizeof(unvisited));
    out.write(reinterpret_cast<const char*>(&visited), sizeof(visited));
    out.write(reinterpret_cast<const char*>(code.getCode()), code.getSize());
    return out.good() ? 0 : 2;
}
'''
with tempfile.TemporaryDirectory(prefix='sitonfixer-interface-') as folder:
    folder = pathlib.Path(folder)
    cpp, exe, binary = folder/'main.cpp', folder/'emitter', folder/'interface.bin'
    cpp.write_text(source)
    subprocess.run(['xcrun','clang++','-std=c++20',
        '-I'+str(root/'dependencies/xbyak_aarch64/xbyak_aarch64'),str(cpp),
        str(root/'dependencies/xbyak_aarch64/src/xbyak_aarch64_impl.cpp'),'-o',str(exe)],check=True)
    subprocess.run([str(exe),str(binary)],check=True)
    data = binary.read_bytes()
unvisited, visited = struct.unpack_from('<QQ',data)
code = data[16:]
assert 0 < unvisited < visited < len(code) <= 1028
for iteration in range(32):
    machine = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    base, stack, cpu, instance, ram = 0x10000,0x30000,0x40000,0x50000,0x60000
    for address in (base,stack,cpu,instance,ram): machine.mem_map(address,0x10000)
    machine.mem_write(base,code)
    # Test guest: x26 := new guest IP; branch to supplied real exit stub.
    machine.mem_write(base+0x1000,struct.pack('<II',0x5280001a | ((iteration+1)<<5),0xd61f0080))
    registers = [UC_ARM64_REG_X19+i for i in range(10)] + [UC_ARM64_REG_X29,UC_ARM64_REG_X30]
    saved = {reg:0x123400000000+index*0x10203+iteration for index,reg in enumerate(registers)}
    saved[UC_ARM64_REG_X30] = base+0x2000
    for reg,value in saved.items(): machine.reg_write(reg,value)
    floats = {UC_ARM64_REG_Q8+i:((i+1)<<100) | (0x8877665544332200+i+iteration) for i in range(8)}
    for reg,value in floats.items(): machine.reg_write(reg,value)
    machine.reg_write(UC_ARM64_REG_SP,stack+0x8000)
    for reg,value in [(UC_ARM64_REG_X0,base+0x1000),(UC_ARM64_REG_X1,cpu),
                      (UC_ARM64_REG_X2,instance),(UC_ARM64_REG_X3,ram),
                      (UC_ARM64_REG_X4,base+(visited if iteration%2 else unvisited))]:
        machine.reg_write(reg,value)
    seen = []
    def observe(uc,address,size,_):
        if address == base+0x1000:
            assert uc.reg_read(UC_ARM64_REG_X29)==cpu
            assert uc.reg_read(UC_ARM64_REG_X27)==instance
            assert uc.reg_read(UC_ARM64_REG_X28)==ram
            assert uc.reg_read(UC_ARM64_REG_SP)==stack+0x8000-160
            seen.append(address)
    machine.hook_add(UC_HOOK_CODE,observe)
    machine.emu_start(base,base+0x2000,count=300)
    assert machine.reg_read(UC_ARM64_REG_PC)==base+0x2000 and len(seen)==1
    assert machine.reg_read(UC_ARM64_REG_SP)==stack+0x8000
    assert struct.unpack('<I',machine.mem_read(cpu,4))[0]==iteration+1
    for reg,value in saved.items(): assert machine.reg_read(reg)==value
    # AAPCS64 requires preservation of the low 64 bits of v8..v15.
    for reg,value in floats.items(): assert machine.reg_read(reg)&((1<<64)-1)==value&((1<<64)-1)
print('Shared Cemu entry/exit emitter: 32 independent ARM64 ABI cases passed, both exit offsets, explicit context and stack/register restoration.')
