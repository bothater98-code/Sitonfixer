import Foundation
import Dispatch

// An existing detached synthetic probe must exclude initialization; an
// initialization claim must keep excluding new probes for the entire process.
precondition(ResearchOperationGate.acquire())
DispatchQueue.concurrentPerform(iterations: 256) { _ in
    precondition(!ResearchOperationGate.acquire())
}
ResearchOperationGate.releaseSyntheticProbe()
let counterLock = NSLock()
var owners = 0
var highWater = 0
var successful = 0
DispatchQueue.concurrentPerform(iterations: 256) { _ in
    if ResearchOperationGate.acquire() {
        counterLock.lock(); owners += 1; successful += 1; highWater = max(highWater, owners); counterLock.unlock()
        Thread.sleep(forTimeInterval: 0.0001)
        counterLock.lock(); owners -= 1; counterLock.unlock()
        ResearchOperationGate.releaseSyntheticProbe()
    }
}
precondition(successful > 0 && highWater == 1 && owners == 0)
precondition(ResearchOperationGate.acquire()) // sticky initialization claim
DispatchQueue.concurrentPerform(iterations: 256) { _ in
    precondition(!ResearchOperationGate.acquire())
}
print("Research operation gate: detached-probe exclusion, concurrent ownership and sticky initialization exclusion passed.")
