// Test-only MMU include. Production builds never add this directory to include paths.
// The native tracker test supplies throwing memory/game-patch functions explicitly.
#pragma once
