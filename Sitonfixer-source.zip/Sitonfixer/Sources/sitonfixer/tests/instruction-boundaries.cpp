// Sitonfixer. SPDX-License-Identifier: MPL-2.0
#include <cassert>
#include <bit>
#include <cstdint>
#include <set>
#include <stdexcept>
#include <vector>
using uint8 = uint8_t;
using sint16 = int16_t;
using uint32 = uint32_t;
using sint32 = int32_t;
using MPTR = uint32_t;
#define cemu_assert_debug(x) assert(x)
static unsigned globalReads = 0;
uint32 memory_readU32(uint32) { ++globalReads; throw std::runtime_error("Global RAM touched"); }
bool GamePatch_IsNonReturnFunction(uint32) { throw std::runtime_error("Global game patches touched"); }
#include "Cafe/HW/Espresso/Recompiler/PPCFunctionBoundaryTracker.h"
#include "Cafe/HW/Espresso/Recompiler/BackendAArch64/OfflineDispatchPrograms.h"

constexpr uint32_t be(uint32_t value)
{
    if constexpr (std::endian::native == std::endian::big) return value;
    return (value >> 24) | ((value >> 8) & 0xff00) | ((value << 8) & 0xff0000) | (value << 24);
}
template<class F> void rejects(F operation)
{
    bool caught = false;
    try { operation(); } catch (const std::exception&) { caught = true; }
    assert(caught);
}
int main()
{
    const uint32 words[] = {be(0x7cc32214), be(0x90c50010), be(0x80e50010),
        be(0x2c070000), be(0x4182000c), be(0x39070001), be(0x48000008),
        be(0x3900ffff), be(0x4e800020)};
    PPCInstructionWindow window(0x1000, words, 9);
    PPCFunctionBoundaryTracker tracker(&window);
    tracker.trackStartPoint(0x1000);
    PPCFunctionBoundaryTracker::PPCRange_t range;
    assert(tracker.getRangeForAddress(0x1000, range));
    assert(range.startAddress == 0x1000 && range.length == 36);
    assert(tracker.GetRanges().size() == 1);
    assert(tracker.GetBranchTargets().contains(0x101c));
    assert(tracker.GetBranchTargets().contains(0x1020));
    assert(!tracker.ContainsAddress(0x1024));
    assert(globalReads == 0);
    rejects([&] { PPCFunctionBoundaryTracker bad(&window); bad.trackStartPoint(0x1024); });
    const uint32 outside[] = {be(0x41820010), be(0x4e800020)};
    PPCInstructionWindow small(0x2000, outside, 2);
    rejects([&] { PPCFunctionBoundaryTracker bad(&small); bad.trackStartPoint(0x2000); });
    assert(globalReads == 0);
    // The original/default path must still use the normal guest memory provider.
    using namespace OfflineDispatchPrograms;
    for (unsigned fixture = 0; fixture < 2; ++fixture) {
        std::vector<uint32> instructions;
        if (!fixture) for (auto word : caller) instructions.push_back(be(word));
        else for (auto word : callee) instructions.push_back(be(word));
        const uint32 address = fixture ? calleeAddress : callerAddress;
        PPCInstructionWindow function(address, instructions.data(), instructions.size());
        PPCFunctionBoundaryTracker boundaries(&function);
        boundaries.trackStartPoint(address);
        assert(boundaries.getRangeForAddress(address, range));
        assert(range.startAddress == address && range.length == instructions.size() * 4);
        assert(boundaries.GetRanges().size() == 1);
        if (!fixture) assert(boundaries.ContainsAddress(continuationAddress));
        assert(globalReads == 0);
    }
    rejects([&] { PPCFunctionBoundaryTracker legacy; legacy.trackStartPoint(0x1000); });
    assert(globalReads == 1);
    return 0;
}
