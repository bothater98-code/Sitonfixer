// SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Dispatch

enum TestFailure: Error { case expected, signing }
func rejects(_ action: () throws -> Void) {
    do { try action(); fatalError("Invalid operation accepted") } catch { }
}
final class Counter {
    private let lock = NSLock()
    private var count = 0
    func increment() { lock.lock(); count += 1; lock.unlock() }
    var value: Int { lock.lock(); defer { lock.unlock() }; return count }
}

// Two independently held calls must survive closing; the second release finalizes.
let cleanup = Counter()
let life = ModuleLifetime { cleanup.increment() }
let first = try life.beginCall(), second = try life.beginCall()
life.requestClose(); life.requestClose()
precondition(life.phase == .closing && cleanup.value == 0)
rejects { _ = try life.beginCall() }
life.endCall(first); life.endCall(first)
precondition(life.phase == .closing && cleanup.value == 0)
life.endCall(second); life.requestClose()
precondition(life.phase == .closed && cleanup.value == 1)

// Exercise actual simultaneous borrowers, not just sequential accounting.
let concurrentCleanup = Counter()
let concurrent = ModuleLifetime { concurrentCleanup.increment() }
let entered = DispatchSemaphore(value: 0), finish = DispatchSemaphore(value: 0)
let group = DispatchGroup()
for _ in 0..<2 {
    group.enter()
    DispatchQueue.global(qos: .userInitiated).async {
        defer { group.leave() }
        let token = try! concurrent.beginCall()
        entered.signal()
        precondition(finish.wait(timeout: .now() + 5) == .success)
        concurrent.endCall(token)
    }
}
precondition(entered.wait(timeout: .now() + 5) == .success)
precondition(entered.wait(timeout: .now() + 5) == .success)
concurrent.requestClose()
precondition(concurrentCleanup.value == 0)
rejects { _ = try concurrent.beginCall() }
finish.signal(); finish.signal()
precondition(group.wait(timeout: .now() + 5) == .success)
precondition(concurrent.phase == .closed && concurrentCleanup.value == 1)

let template = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
let body: [UInt32] = [0xb9400009, 0x11000529, 0xb9000009, 0xd65f03c0]
let offsets = SignedProbeModule.entryOffsets + [SignedProbeModule.markerOffset]
func image(_ marker: UInt16) throws -> SignedCodeImage {
    try SignedCodeImage.prepare(template: template,
        instructions: SignedProbeModule.compose(frontend: body, marker: marker), entries: offsets)
}
let imageA = try image(0x1357), imageB = try image(0x2468)
precondition(imageA.identifier != imageB.identifier && imageA.bytes != imageB.bytes)
precondition(imageA.textBytes == 65536 && imageA.platform == 1)
var uuid = imageA.identifier.uuid
let expectedUUID = withUnsafeBytes(of: &uuid) { Data($0) }
precondition(imageA.bytes.subdata(in: imageA.uuidRange) == expectedUUID)
let name = String(bytes: imageA.bytes[imageA.nameRange].prefix { $0 != 0 }, encoding: .utf8)!
precondition(name == "@rpath/SitonfixerModule-\(imageA.identifier.uuidString).dylib")
precondition(imageA.bytes.count == template.count)
// Identity edits must stay in their preallocated load-command slots.
let justText = try ScalarTranslation.replaceText(in: template,
    instructions: SignedProbeModule.compose(frontend: body, marker: 0x1357))
for index in 0..<template.count where !imageA.uuidRange.contains(index) && !imageA.nameRange.contains(index) {
    precondition(imageA.bytes[index] == justText[index])
}
for invalid in [[], [0, 0], [0, -4], [0, 65536], [0, 1]] {
    rejects { _ = try SignedCodeImage.prepare(template: template,
        instructions: SignedProbeModule.compose(frontend: body), entries: invalid) }
}
// Corrupt the identity command's name offset and remove UUID independently.
var brokenName = template
let nameCommand = imageA.nameRange.lowerBound - 24
brokenName.replaceSubrange(nameCommand + 8..<nameCommand + 12, with: [UInt8](repeating: 0xff, count: 4))
rejects { _ = try SignedCodeImage.prepare(template: brokenName,
    instructions: SignedProbeModule.compose(frontend: body), entries: offsets) }
var noUUID = template
noUUID.replaceSubrange(imageA.uuidRange.lowerBound - 8..<imageA.uuidRange.lowerBound - 4, with: [0x31, 0, 0, 0])
rejects { _ = try SignedCodeImage.prepare(template: noUUID,
    instructions: SignedProbeModule.compose(frontend: body), entries: offsets) }

func sign(_ file: URL) throws {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: "/usr/bin/codesign")
    process.arguments = ["--force", "--sign", "-", "--timestamp=none", file.path]
    process.standardOutput = FileHandle.nullDevice
    process.standardError = FileHandle.nullDevice
    try process.run(); process.waitUntilExit()
    guard process.terminationStatus == 0 else { throw TestFailure.signing }
}
func path(_ image: SignedCodeImage) -> URL {
    FileManager.default.temporaryDirectory.appendingPathComponent("SitonfixerModule-" + image.identifier.uuidString)
}
// Failed validation/signing must leave no owned temporary directory.
rejects { _ = try SignedCodeModule.load(image: imageA, sign: sign, validate: { throw TestFailure.expected }) }
precondition(!FileManager.default.fileExists(atPath: path(imageA).path))
rejects { _ = try SignedCodeModule.load(image: imageA, sign: { _ in throw TestFailure.expected }, validate: {}) }
precondition(!FileManager.default.fileExists(atPath: path(imageA).path))
let a = try SignedCodeModule.load(image: imageA, sign: sign, validate: {})
defer { a.requestClose() }
let b = try SignedCodeModule.load(image: imageB, sign: sign, validate: {})
defer { b.requestClose() }
typealias Marker = @convention(c) () -> UInt32
func marker(_ module: SignedCodeModule) throws -> UInt32 {
    try module.withEntry(at: SignedProbeModule.markerOffset) { unsafeBitCast($0, to: Marker.self)() }
}
let valueA = try marker(a), valueB = try marker(b)
precondition(valueA == 0x1357 && valueB == 0x2468)
rejects { _ = try SignedCodeModule.load(image: imageA, sign: sign, validate: {}) }
precondition(FileManager.default.fileExists(atPath: a.fileURL.path))
let valueAAfterCollision = try marker(a)
precondition(valueAAfterCollision == 0x1357)
typealias Increment = @convention(c) (UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt8>?) -> Void
for module in [a, b] {
    var cpu: UInt32 = 42
    var ram: UInt8 = 0xa5
    for offset in SignedProbeModule.entryOffsets {
        try module.withEntry(at: offset) { unsafeBitCast($0, to: Increment.self)(&cpu, &ram) }
    }
    precondition(cpu == 45 && ram == 0xa5)
}
try a.withEntry(at: SignedProbeModule.markerOffset) { pointer in
    a.requestClose()
    precondition(a.phase == .closing)
    rejects { _ = try a.withEntry(at: 0) { _ in 0 } }
    precondition(unsafeBitCast(pointer, to: Marker.self)() == 0x1357)
}
precondition(a.phase == .closed && !FileManager.default.fileExists(atPath: a.fileURL.path))
let valueBAfterClosingA = try marker(b)
precondition(valueBAfterClosingA == 0x2468)
b.requestClose()
precondition(b.phase == .closed && !FileManager.default.fileExists(atPath: b.fileURL.path))
print("Real macOS ARM64 loader passed two distinct simultaneous images, scoped calls, deferred close, rejection and cleanup; concurrent lifetime check finalized once. iOS signing still requires device validation.")
