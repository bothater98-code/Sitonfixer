"""Execute the real mixed fixture/checker with independent PPC32 reference steps.

CPU, init, allocator and MemMapper are host substitutes. Native entries are PPC
reference callbacks, NOT production ARM64 code. Full iOS compilation and the
physical signed-module test cover those boundaries. The sparse table stub backs
only the low-address test window; it records the actual 512-MiB reservation and
page requests without committing a large host allocation.
"""
import ctypes as C
import _ctypes
import os, pathlib, subprocess, sys, tempfile
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import UC_PPC_REG_0, UC_PPC_REG_PC, UC_PPC_REG_LR, UC_PPC_REG_CTR, UC_PPC_REG_CR, UC_PPC_REG_XER

root=pathlib.Path(__file__).resolve().parents[2]
reference=root/'sitonfixer/tests/check-interpreter.py'
namespace={'__file__':str(reference)}
# Reuse declarations and host types, never run the previous script's tests.
exec(compile(reference.read_text().split('with tempfile.TemporaryDirectory')[0],str(reference),'exec'),namespace)
CPU,Step=namespace['CPU'],namespace['Step']
source=namespace['source']
source+=r'''
#include <cstdlib>
static int mappingFailure=0;static size_t reservationRequests=0,requestedBytes=0,committedBytes=0,freeRequests=0;
static void* privateReservation=nullptr;
namespace MemMapper {
enum class PAGE_PERMISSION {P_NONE,P_RW};
size_t GetPageSize(){return mappingFailure==3?3:4096;}
void* ReserveMemory(void*,size_t bytes,PAGE_PERMISSION){
    ++reservationRequests;requestedBytes=bytes;
    if(mappingFailure==1)return nullptr;
    privateReservation=std::malloc(65536);return privateReservation;
}
void FreeReservation(void* ptr,size_t bytes){
    if(ptr!=privateReservation || bytes!=requestedBytes)std::abort();
    ++freeRequests;std::free(ptr);privateReservation=nullptr;
}
void* AllocateMemory(void* ptr,size_t bytes,PAGE_PERMISSION,bool fromReservation){
    if(mappingFailure==2)return nullptr;
    auto offset=uintptr_t(ptr)-uintptr_t(privateReservation);
    if(!fromReservation || !privateReservation || offset%4096 || bytes!=4096 || offset+bytes>65536)std::abort();
    committedBytes+=bytes;return ptr;
}
}
static bool recompiler=false;
bool PPCRecompilerInitialized(){return recompiler;}
#ifdef _WIN32
EXPORT int sitonfixer_mixed_probe_begin(const char*,uint32_t*,uint32_t*) noexcept;
EXPORT int sitonfixer_mixed_probe_check(void*,void*,void*,void*,void*,uint32_t,uint32_t*,uint32_t*,uint32_t*) noexcept;
#endif
'''
source+=(root/'src/ios/Bridge/OfflineMixedProbe.inc').read_text().replace('#include "util/MemMapper/MemMapper.h"','')
source+=r'''
EXPORT void mixed_reset(Step callback,int condition,int mapping){
    fixture_reset(callback,condition);s_mixedGuest.store(0);s_mixedChecked.store(false);recompiler=condition==7;
    mappingFailure=mapping;reservationRequests=0;requestedBytes=0;committedBytes=0;freeRequests=0;
}
EXPORT size_t mixed_metric(int index){
    return index==0?reservationRequests:index==1?requestedBytes:index==2?committedBytes:freeRequests;
}
struct AArch64CodeBytes {std::vector<uint8_t> bytes;std::vector<std::pair<uint32_t,size_t>> entries;};
struct AArch64InterfaceBytes {std::vector<uint8_t> bytes;size_t enterOffset=0,unvisitedOffset=4,visitedOffset=8;};
struct PPCRecompilerInstanceData_t {void* ppcRecompilerDirectJumpTable[1];};
int PPCRecompiler_prepareOfflineMixed(uint32_t guest,AArch64CodeBytes& out) noexcept {
    if(guest<0x0e000000u || guest%4096 || uint64_t(guest)+4096>0x10000000ull)return -1;
    out.bytes.assign(8,0);out.entries={{guest+64,0},{guest+76,4}};return 0;
}
bool PPCRecompiler_emitAArch64InterfaceBytes(AArch64InterfaceBytes& out,size_t){out.bytes.assign(16,0);return true;}
#ifdef _WIN32
EXPORT int sitonfixer_mixed_probe_prepare(uint32_t,uint8_t*,size_t,size_t*,size_t*,size_t) noexcept;
#endif
'''
source=source.replace('#include <cstdlib>','#include <cstdlib>\n#include <vector>\n#include <utility>')
source+=(root/'src/Cafe/HW/Espresso/Recompiler/BackendAArch64/OfflineMixedCode.inc').read_text()

Enter=C.CFUNCTYPE(None,C.c_void_p,C.POINTER(CPU),C.c_void_p,C.c_void_p)
with tempfile.TemporaryDirectory(prefix='sitonfixer-mixed-',ignore_cleanup_errors=sys.platform=='win32') as folder:
    folder=pathlib.Path(folder);cpp=folder/'mixed.cpp';cpp.write_text(source,encoding='utf-8')
    windows=sys.platform=='win32';library=folder/('mixed.dll' if windows else 'mixed.dylib')
    compiler=[os.environ['SITONFIXER_TEST_CLANG']] if os.environ.get('SITONFIXER_TEST_CLANG') else ['xcrun','clang++']
    subprocess.run(compiler+['-std=c++20']+(['-shared'] if windows else ['-dynamiclib','-fPIC'])+
                   ['-I'+str(root/'src/ios/Bridge'),str(cpp),'-o',str(library)],check=True)
    lib=C.CDLL(str(library));lib.fixture_memory.restype=C.POINTER(C.c_uint8)
    lib.mixed_reset.argtypes=[Step,C.c_int,C.c_int];lib.mixed_metric.argtypes=[C.c_int];lib.mixed_metric.restype=C.c_size_t
    lib.sitonfixer_mixed_probe_begin.argtypes=[C.c_char_p,C.POINTER(C.c_uint32),C.POINTER(C.c_uint32)]
    lib.sitonfixer_mixed_probe_check.argtypes=[C.c_void_p]*5+[C.c_uint32]+[C.POINTER(C.c_uint32)]*3
    memory=lib.fixture_memory();base=C.addressof(memory.contents)
    uc=Uc(UC_ARCH_PPC,UC_MODE_32|UC_MODE_BIG_ENDIAN);uc.mem_map(0x1000,4096)
    errors=[];nativeCalls=0;steps=0;fault=None
    def execute(cpu,count):
        uc.mem_write(0x1000,C.string_at(base+0x1000,4096))
        for i in range(32):uc.reg_write(UC_PPC_REG_0+i,cpu.gpr[i])
        uc.reg_write(UC_PPC_REG_LR,cpu.spr.LR);uc.reg_write(UC_PPC_REG_CTR,cpu.spr.CTR)
        uc.reg_write(UC_PPC_REG_CR,cpu.cr)
        uc.reg_write(UC_PPC_REG_XER,(cpu.xer_ca<<29)|(cpu.xer_ov<<30)|(cpu.xer_so<<31))
        uc.emu_start(cpu.instructionPointer,0,count=count)
        for i in range(32):cpu.gpr[i]=uc.reg_read(UC_PPC_REG_0+i)
        cpu.spr.LR=uc.reg_read(UC_PPC_REG_LR);cpu.spr.CTR=uc.reg_read(UC_PPC_REG_CTR)
        cpu.cr=uc.reg_read(UC_PPC_REG_CR);cpu.instructionPointer=uc.reg_read(UC_PPC_REG_PC)
        xer=uc.reg_read(UC_PPC_REG_XER);cpu.xer_ca=(xer>>29)&1;cpu.xer_ov=(xer>>30)&1;cpu.xer_so=(xer>>31)&1
        C.memmove(base+0x1000,bytes(uc.mem_read(0x1000,4096)),4096)
    @Step
    def interpret(pointer):
        global steps
        try:
            execute(pointer.contents,1);steps+=1
            if fault=='step_pc':pointer.contents.instructionPointer=0xffff0000
            if fault=='step_guard' and steps==1:memory[0x1fff]^=1
        except Exception as error:errors.append(repr(error));pointer.contents.instructionPointer=0xffff0000
    caller,continuation,unvisited,visited=0x1230,0x1234,0x2340,0x2344
    @Enter
    def native(entry,pointer,context,ram):
        global nativeCalls
        try:
            assert ram==base
            table=C.cast(context,C.POINTER(C.c_void_p))
            assert table[0] in (unvisited,visited)
            assert table[(0x1000+64)//4]==caller and table[(0x1000+76)//4]==continuation
            assert table[(0x1000+320)//4]==table[0], 'B must leave to host'
            assert entry in (caller,continuation)
            assert pointer.contents.instructionPointer==0x1000+(64 if entry==caller else 76)
            execute(pointer.contents,3);pointer.contents.remainingCycles-=3;nativeCalls+=1
            if fault=='native_register':pointer.contents.gpr[31]^=1
            if fault=='native_cycles':pointer.contents.remainingCycles-=1
        except Exception as error:errors.append(repr(error));pointer.contents.instructionPointer=0xffff0000
    nativeAddress=C.cast(native,C.c_void_p)
    def begin(condition=0,mapping=0,corruption=None):
        global steps,nativeCalls,fault
        steps=0;nativeCalls=0;fault=corruption;errors.clear();lib.mixed_reset(interpret,condition,mapping)
        conditions,guest=C.c_uint32(999),C.c_uint32(999)
        result=lib.sitonfixer_mixed_probe_begin(b'mlc',C.byref(conditions),C.byref(guest))
        return result,conditions.value,guest.value
    def check(guest=0x1000):
        completed,interpreted,pages=C.c_uint32(999),C.c_uint32(999),C.c_uint32(999)
        result=lib.sitonfixer_mixed_probe_check(nativeAddress,unvisited,visited,caller,continuation,guest,
                                              C.byref(completed),C.byref(interpreted),C.byref(pages))
        assert not errors,errors
        return result,completed.value,interpreted.value,pages.value
    assert begin()==(0,255,0x1000)
    assert check()==(0,64,256,2)
    assert nativeCalls==128 and steps==256
    assert [lib.mixed_metric(i) for i in range(4)]==[1,512*1024*1024,8192,1]
    assert C.string_at(base+0x1000,4096)==bytes(4096)
    assert C.string_at(base,0x1000)==b'\x7e'*0x1000 and C.string_at(base+0x2000,0x3000)==b'\x7e'*0x3000
    assert check()==(2,0,0,0),'second check must be rejected'
    for mapping in (1,2,3):
        assert begin(mapping=mapping)==(0,255,0x1000)
        assert check()==(5,0,0,0)
        assert lib.mixed_metric(3)==(1 if mapping==2 else 0)
    for condition,code in ((1,3),(4,105),(5,2),(6,2),(7,2)):
        result,mask,guest=begin(condition)
        assert result==code and guest==0,(condition,result,mask,guest)
    for corruption,code in (('native_register',6),('native_cycles',6),('step_pc',7),('step_guard',8)):
        assert begin(corruption=corruption)==(0,255,0x1000)
        result=check()
        assert result[0]==code,(corruption,result)
        assert C.string_at(base+0x1000,4096)==bytes(4096)
        assert lib.mixed_metric(3)==1
    assert begin()==(0,255,0x1000)
    assert check(0x2000)==(1,0,0,0)
    for condition in (2,3):
        assert begin(condition)==(0,255,0x1000)
        assert check()==(3,0,0,0)
    # Actual module assembly wrapper; frontend/interface emission are substitutes.
    lib.sitonfixer_mixed_probe_prepare.argtypes=[C.c_uint32,C.POINTER(C.c_uint8),C.c_size_t,C.POINTER(C.c_size_t),C.POINTER(C.c_size_t),C.c_size_t]
    image=(C.c_uint8*65536)();offsets=(C.c_size_t*4)();written=C.c_size_t()
    prepare=lib.sitonfixer_mixed_probe_prepare
    assert prepare(0x0e001000,None,0,C.byref(written),offsets,4)==-6 and written.value==65536
    assert prepare(0x0e001000,image,len(image),C.byref(written),offsets,4)==0
    assert list(offsets)==[4,8,32768,32772] and written.value==65536
    assert bytes(image[16384:16388])==bytes.fromhex('1f2003d5')
    for address in (0,0x1000,0x0e001001,0x10000000):
        assert prepare(address,image,len(image),C.byref(written),offsets,4)==-1 and written.value==0
    assert prepare(0x0e001000,image,len(image),C.byref(written),offsets,3)==-1
    checks,guest=C.c_uint32(9),C.c_uint32(9)
    assert lib.sitonfixer_mixed_probe_begin(None,C.byref(checks),C.byref(guest))==1 and checks.value==guest.value==0
    if windows:_ctypes.FreeLibrary(lib._handle)
print('Mixed checker: 64 cases, 256 PPC32 reference interpreter steps, both native callback exits, sparse-page requests/cleanup and failure guards passed. Host substitutes do not execute production ARM64/Cemu or prove iOS sparse mapping.')
