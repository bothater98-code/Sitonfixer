"""Independent PPC integer reference versus emulated ARM64 execution of Swift-generated code.
No ROMs, signing identity or phone data. Deterministic randomized synthetic cases only.
"""
import json, random, struct, subprocess, sys, tempfile
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM
from unicorn.arm64_const import UC_ARM64_REG_X0, UC_ARM64_REG_LR

rng = random.Random(0x5170F1)
fixtures = []
for case in range(300):
    initial = [rng.getrandbits(32) for _ in range(32)]
    expected = initial.copy()
    words = []
    for _ in range(25):
        op = rng.choice([14, 15, 24, 31])
        d, a, b = [rng.randrange(32) for _ in range(3)]
        imm = rng.choice([0, 1, 0x7fff, 0x8000, 0xffff, rng.randrange(65536)])
        word = op << 26 | d << 21 | a << 16
        if op in [14, 15]:
            word |= imm
            value = imm if imm < 0x8000 else imm - 0x10000
            expected[d] = ((expected[a] if a else 0) + (value << (16 if op == 15 else 0))) & 0xffffffff
        elif op == 24:
            word |= imm
            expected[a] = expected[d] | imm
        else:
            word |= b << 11 | 266 << 1
            expected[d] = (expected[a] + expected[b]) & 0xffffffff
        words.append(word)
    fixtures.append(dict(words=words + [0x4e800020], registers=initial, expected=expected))

with tempfile.TemporaryDirectory(prefix='sitonfixer-scalar-') as directory:
    base = Path(directory)
    inputs, outputs = base/'input.json', base/'native.json'
    inputs.write_text(json.dumps(fixtures))
    subprocess.run([sys.argv[1], str(inputs), str(outputs)], check=True)
    blocks = json.loads(outputs.read_text())
    assert len(blocks) == len(fixtures)
    for case, (fixture, block) in enumerate(zip(fixtures, blocks)):
        emulator = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
        emulator.mem_map(0x10000, 0x10000)
        emulator.mem_map(0x30000, 0x1000)
        machine = b''.join(struct.pack('<I', word) for word in block)
        emulator.mem_write(0x10000, machine)
        emulator.mem_write(0x30000, struct.pack('<32I', *fixture['registers']))
        emulator.reg_write(UC_ARM64_REG_X0, 0x30000)
        emulator.reg_write(UC_ARM64_REG_LR, 0x18000)
        emulator.emu_start(0x10000, 0x18000, count=1000)
        actual = list(struct.unpack('<32I', emulator.mem_read(0x30000, 128)))
        assert actual == fixture['expected'], f'Wrong registers in synthetic case {case}'
print('300 synthetic PowerPC blocks agree with independent ARM64 emulation; unsupported instructions rejected.')
