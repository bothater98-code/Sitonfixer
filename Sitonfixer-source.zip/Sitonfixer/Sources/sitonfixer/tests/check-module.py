"""Run actual Swift-generated bridge code in an independent ARM64 emulator.

Also validate the platform-linker's real carrier and that only its text changed.
No certificate, signing, iOS execution or game compatibility is claimed here.
"""
import struct
import sys
from pathlib import Path
from unicorn import Uc, UC_ARCH_ARM64, UC_MODE_ARM
from unicorn import arm64_const as registers

original, patched = [Path(name).read_bytes() for name in sys.argv[1:3]]
assert len(original) == len(patched)
magic, cpu, subtype, kind, count, command_bytes, flags, reserved = struct.unpack_from('<8I', original)
assert magic == 0xfeedfacf and cpu == 0x0100000c and kind == 6
cursor, text, symbols, ios = 32, None, None, False
for _ in range(count):
    command, size = struct.unpack_from('<II', original, cursor)
    assert size >= 8 and cursor + size <= 32 + command_bytes
    if command == 0x19:
        segment, address, vmsize, fileoff, filesize, maxprot, initprot, sections, segflags = struct.unpack_from('<16s4Q4I', original, cursor + 8)
        for index in range(sections):
            position = cursor + 72 + 80 * index
            section, parent, start, length, offset, alignment = struct.unpack_from('<16s16sQQII', original, position)
            if section.rstrip(b'\0') == b'__text':
                assert text is None and parent.rstrip(b'\0') == segment.rstrip(b'\0') == b'__TEXT'
                assert initprot == 5 and maxprot & 4
                assert length == 65_536 and alignment >= 14 and start % 16_384 == 0
                assert fileoff <= offset and offset + length <= fileoff + filesize <= len(original)
                text = offset, length, start
    if command == 2:
        symbols = struct.unpack_from('<4I', original, cursor + 8)
    if command == 0x32:
        ios = struct.unpack_from('<I', original, cursor + 8)[0] == 2
    cursor += size
assert cursor == 32 + command_bytes and text and symbols and ios
offset, length, virtual = text
assert original[:offset] == patched[:offset] and original[offset + length:] == patched[offset + length:]
assert original[offset:offset + length] == struct.pack('<I', 0xd503201f) * 16383 + struct.pack('<I', 0xd65f03c0)
symoff, symcount, stroff, strsize = symbols
export_found = False
for index in range(symcount):
    string, symbol_type, section, description, value = struct.unpack_from('<IBBHQ', original, symoff + index * 16)
    name = original[stroff + string:stroff + strsize].split(b'\0', 1)[0]
    if name == b'_sitonfixer_aot_probe':
        assert symbol_type & 0x0f == 0x0f and section and value == virtual
        export_found = True
assert export_found
code = patched[offset:offset + length]
for entry in [0, 32_768, 49_152]:
    emulator = Uc(UC_ARCH_ARM64, UC_MODE_ARM)
    emulator.mem_map(0x10000, 0x10000)
    emulator.mem_write(0x10000, code)
    emulator.mem_map(0x30000, 0x1000)
    emulator.mem_map(0x40000, 0x1000)
    emulator.mem_map(0x50000, 0x10000)
    initial = bytes([0xa5] * 4096)
    emulator.mem_write(0x30000, initial)
    emulator.mem_write(0x40000, initial)
    for index in range(19, 30):
        emulator.reg_write(getattr(registers, f'UC_ARM64_REG_X{index}'), 0xabc00000 + index)
    emulator.reg_write(registers.UC_ARM64_REG_X0, 0x30000)
    emulator.reg_write(registers.UC_ARM64_REG_X1, 0x40000)
    emulator.reg_write(registers.UC_ARM64_REG_SP, 0x5fff0)
    emulator.reg_write(registers.UC_ARM64_REG_LR, 0x90000)
    emulator.emu_start(0x10000 + entry, 0x90000, count=100)
    assert emulator.reg_read(registers.UC_ARM64_REG_PC) == 0x90000
    assert emulator.reg_read(registers.UC_ARM64_REG_SP) == 0x5fff0
    for index in range(19, 30):
        assert emulator.reg_read(getattr(registers, f'UC_ARM64_REG_X{index}')) == 0xabc00000 + index
    assert emulator.reg_read(registers.UC_ARM64_REG_X0) == 0x30000
    assert emulator.reg_read(registers.UC_ARM64_REG_X1) == 0x40000
    expected = struct.pack('<I', 0xa5a5a5a6) + initial[4:]
    assert bytes(emulator.mem_read(0x30000, 4096)) == expected
    assert bytes(emulator.mem_read(0x40000, 4096)) == initial
print('64 KiB module passed 3 cross-page ARM64 entry paths, ABI preservation and carrier layout checks.')
