"""Independent PPC ISA reference plus compilation of the actual dispatch fixture.

The native compile uses test CPU/body substitutes, not the production frontend.
Its purpose is to catch C++ API/layout-emission errors before a full iOS build.
"""
import pathlib, re, struct, subprocess, tempfile
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_PPC32, UC_MODE_BIG_ENDIAN, UC_HOOK_CODE
from unicorn.ppc_const import *

root = pathlib.Path(__file__).resolve().parents[2]
programs = root/'src/Cafe/HW/Espresso/Recompiler/BackendAArch64/OfflineDispatchPrograms.h'
header = programs.read_text()
def words(name):
    array = re.search(r'\b'+name+r'\{([^}]+)\}',header).group(1)
    return [int(word,16) for word in re.findall(r'0x[0-9a-f]+',array)]
caller, callee = words('caller'), words('callee')
with tempfile.TemporaryDirectory(prefix='sitonfixer-dispatch-') as folder:
    folder = pathlib.Path(folder)
    text = bytearray(0x2010)
    text[0x1000:0x1018] = struct.pack('>6I',*caller)
    text[0x2000:0x2010] = struct.pack('>4I',*callee)
    for iteration in range(32):
        uc = Uc(UC_ARCH_PPC,UC_MODE_PPC32|UC_MODE_BIG_ENDIAN)
        uc.mem_map(0,0x10000)
        uc.mem_write(0,bytes(text))
        uc.mem_write(0x4000,b'\xa5'*64)
        initial = [(iteration*37) ^ (i*0x01020304) for i in range(32)]
        initial[3] = 0xffffffff if iteration==0 else 0x7fffffff if iteration==1 else iteration*0x1234567
        initial[4] = iteration*13+1
        initial[5] = 0x4000
        for i,value in enumerate(initial): uc.reg_write(UC_PPC_REG_0+i,value)
        uc.reg_write(UC_PPC_REG_LR,0)
        executed=[]
        uc.hook_add(UC_HOOK_CODE,lambda u,address,size,data: executed.append(address))
        uc.emu_start(0x1000,0,count=30)
        assert uc.reg_read(UC_PPC_REG_PC)==0 and uc.reg_read(UC_PPC_REG_LR)==0
        assert executed == [0x1000,0x1004,0x1008,0x2000,0x2004,0x2008,0x200c,0x100c,0x1010,0x1014]
        expected = list(initial)
        expected[6]=(initial[3]+initial[4])&0xffffffff
        expected[7]=expected[6]; expected[8]=(expected[7]+5)&0xffffffff
        expected[9]=(expected[8]+3)&0xffffffff; expected[10]=0
        assert [uc.reg_read(UC_PPC_REG_0+i) for i in range(32)]==expected
        ram = bytearray(b'\xa5'*64);ram[16:20]=struct.pack('>I',expected[6])
        assert uc.mem_read(0x4000,64)==ram

    # Reuse construction of the actual shared entry/exit emitter, without running
    # the other test script or its test cases a second time.
    interfaceTest = root/'sitonfixer/tests/check-interface.py'
    namespace={'__file__':str(interfaceTest)}
    exec(compile(interfaceTest.read_text().split('with tempfile.TemporaryDirectory')[0],str(interfaceTest),'exec'),namespace)
    source=namespace['source'].split('int main(int argc')[0]
    source=source.replace('struct PPCInterpreter_t { uint32_t instructionPointer; uint32_t gpr[32]; };', '''
struct PPCInterpreter_t {
    uint32_t instructionPointer, gpr[32];
    struct FPR { double fp0,fp1; } fpr[32];
    struct SPR { uint32_t LR; } spr;
    uint32_t cr; uint8_t xer_ca,xer_so; int32_t remainingCycles;
};''')
    source+='''
bool PPCRecompilerInitialized() { return false; }
struct AArch64CodeBytes { std::vector<uint8_t> bytes; std::vector<std::pair<uint32_t,size_t>> entries; };
int PPCRecompiler_prepareOfflineDispatch(uint32_t fixture,AArch64CodeBytes& out) noexcept {
    if(fixture>1)return -1;
    const uint32_t nop=0xd503201f, ret=0xd65f03c0;
    out.bytes.resize(8);std::memcpy(out.bytes.data(),&nop,4);std::memcpy(out.bytes.data()+4,&ret,4);
    out.entries={{fixture?0x2000u:0x1000u,0}};
    if(!fixture)out.entries.emplace_back(0x100c,4);
    return 0;
}
'''
    source+=(root/'src/Cafe/HW/Espresso/Recompiler/BackendAArch64/OfflineDispatchProbe.inc').read_text()
    source+='''
int main() {
    std::array<uint8_t,65536> bytes{};size_t written=123;size_t offsets[4]{};
    if(sitonfixer_dispatch_probe_prepare(2,bytes.data(),bytes.size(),&written,offsets,4)!=-1||written)return 1;
    if(sitonfixer_dispatch_probe_prepare(0,bytes.data(),bytes.size(),&written,offsets,3)!=-1||written)return 2;
    if(sitonfixer_dispatch_probe_prepare(0,nullptr,0,&written,offsets,4)!=-6||written!=65536)return 3;
    for(uint32_t fixture=0;fixture<2;++fixture) {
        if(sitonfixer_dispatch_probe_prepare(fixture,bytes.data(),bytes.size(),&written,offsets,4)||written!=65536)return 4;
        if(!offsets[0]||offsets[0]==offsets[1]||offsets[1]>=32768||offsets[2]!=32768||offsets[3]!=(fixture?32768u:32772u))return 5;
        uint32_t word=0;std::memcpy(&word,bytes.data()+16384,4);if(word!=0xd503201f)return 6;
    }
    written=123;if(sitonfixer_dispatch_probe_check(nullptr,nullptr,nullptr,nullptr,nullptr,1,&written)!=-1||written)return 7;
    return 0;
}
'''
    cpp,exe = folder/'dispatch.cpp',folder/'dispatch-check'
    cpp.write_text(source)
    subprocess.run(['xcrun','clang++','-std=c++20',
        '-I'+str(root/'dependencies/xbyak_aarch64/xbyak_aarch64'),
        '-I'+str(programs.parent),str(cpp),str(root/'dependencies/xbyak_aarch64/src/xbyak_aarch64_impl.cpp'),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
print('Dispatch fixture: 32 independent PPC32 ISA states and exact call/return path passed. Actual native fixture API compiled; private capacity/layout checks passed using test CPU/body substitutes.')
