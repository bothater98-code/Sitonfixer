// Sitonfixer. SPDX-License-Identifier: MPL-2.0
#include <array>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <new>
#include <stdexcept>
#include "Cafe/HW/Espresso/Recompiler/PPCInstructionWindow.h"

template<class F> void rejects(F operation)
{
    bool caught = false;
    try { operation(); } catch (const std::exception&) { caught = true; }
    assert(caught);
}

int main()
{
    alignas(4) const uint8_t bytes[] = {
        0x7c,0xc3,0x22,0x14, 0x90,0xc5,0x00,0x10,
        0x80,0xe5,0x00,0x10, 0x4e,0x80,0x00,0x20};
    const auto* words = reinterpret_cast<const uint32_t*>(bytes);
    // Poison storage so forgetting constructor member initialization fails deterministically.
    alignas(PPCInstructionWindow) std::array<std::byte, sizeof(PPCInstructionWindow)> storage;
    storage.fill(std::byte{0xa5});
    auto* window = new (storage.data()) PPCInstructionWindow(0x1000, words, 4);
    assert(window->end() == 0x1010);
    assert(window->pointer(0x1000) == words);
    assert(window->read(0x1000) == 0x7cc32214);
    assert(window->read(0x100c) == 0x4e800020);
    rejects([&] { window->read(0xffc); });
    rejects([&] { window->read(0x1010); });
    rejects([&] { window->read(0x1001); });
    rejects([&] { PPCInstructionWindow bad(0, nullptr, 4); });
    rejects([&] { PPCInstructionWindow bad(0, words, 0); });
    rejects([&] { PPCInstructionWindow bad(1, words, 4); });
    rejects([&] { PPCInstructionWindow bad(0xfffffffc, words, 1); });
    rejects([&] { PPCInstructionWindow bad(0, reinterpret_cast<const uint32_t*>(bytes + 1), 1); });
    window->~PPCInstructionWindow();
    PPCInstructionWindow other(0x2000, words + 3, 1);
    assert(other.read(0x2000) == 0x4e800020);
    assert(other.end() == 0x2004);
}
