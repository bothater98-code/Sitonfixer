"""Compile the actual diagnostic against controlled initialization/OS substitutes.

This tests reporting and refusal paths, NOT real Cemu/MMU initialization. That
requires the complete iOS build and a separate physical offline device test.
"""
import pathlib, subprocess, tempfile, os, sys

root = pathlib.Path(__file__).resolve().parents[2]
source = r'''
#include <atomic>
#include <cstdint>
#include <cstddef>
#include <stdexcept>
constexpr int CTL_KERN=1,KERN_PROC=2,KERN_PROC_PID=3,P_TRACED=0x800;
struct kinfo_proc { struct { int p_flag=0; } kp_proc; };
static bool csFailure=false,sysFailure=false,traced=false,debugged=false,postDirty=false;
static int csops(int,int,void* out,size_t) { *static_cast<uint32_t*>(out)=debugged?0x10000000u:0;return csFailure?-1:0; }
static int sysctl(int*,unsigned,void* out,size_t* size,void*,size_t) {
    static_cast<kinfo_proc*>(out)->kp_proc.p_flag=traced?P_TRACED:0;
    *size=sizeof(kinfo_proc);return sysFailure?-1:0;
}
static int getpid() { return 42; }
static std::atomic<bool> g_initialized{false},g_initializationComplete{false},g_recompilerRequested{true};
static constexpr int kCpuModeInterpreter=1;
static std::atomic<int> g_cpuMode{0};
static bool coreReady=false,titleRunning=false,throws=false;
static uint32_t omitted=0; static int calls=0;
static uint8_t* memory_base=nullptr;
struct Range { bool mapped=false; bool isMapped() const {return mapped;} };
static Range mmuRange_CEMU_AREA,mmuRange_SHARED_AREA;
static bool CemuIsInitialized() {return coreReady;}
static bool cemu_bridge_is_title_running() {return titleRunning;}
static void cemu_bridge_initialize(const char*) {
    ++calls;if(g_recompilerRequested.load())throw std::runtime_error("requested JIT");
    if(throws)throw std::runtime_error("test init failure");
    g_initialized=true;g_initializationComplete=!(omitted&1);coreReady=!(omitted&2);
    memory_base=(omitted&4)?nullptr:reinterpret_cast<uint8_t*>(0x10000000);
    mmuRange_CEMU_AREA.mapped=!(omitted&8);mmuRange_SHARED_AREA.mapped=!(omitted&16);
    g_cpuMode=(omitted&32)?2:1;debugged=postDirty;titleRunning=(omitted&128)!=0;
}
'''
source += (root/'src/ios/Bridge/OfflineInitializationProbe.inc').read_text(encoding='utf-8')
source += r'''
static void reset() {
    s_initializationProbeAttempted=false;csFailure=sysFailure=traced=debugged=postDirty=false;
    g_initialized=g_initializationComplete=false;g_recompilerRequested=true;g_cpuMode=0;
    coreReady=titleRunning=throws=false;omitted=0;calls=0;memory_base=nullptr;
    mmuRange_CEMU_AREA.mapped=mmuRange_SHARED_AREA.mapped=false;
}
int main() {
    uint32_t checks=999;
    reset(); if(sitonfixer_initialization_probe("mlc",nullptr)!=1||calls)return 1;
    if(sitonfixer_initialization_probe(nullptr,&checks)!=1||checks||calls)return 2;
    for(int dirty=0;dirty<4;++dirty) {
        reset();csFailure=dirty==0;sysFailure=dirty==1;traced=dirty==2;debugged=dirty==3;
        if(sitonfixer_initialization_probe("mlc",&checks)!=3||checks||calls)return 3;
    }
    for(int prior=0;prior<4;++prior) {
        reset();g_initialized=prior==0;g_initializationComplete=prior==1;coreReady=prior==2;titleRunning=prior==3;
        if(sitonfixer_initialization_probe("mlc",&checks)!=4||checks||calls)return 4;
    }
    reset();throws=true;if(sitonfixer_initialization_probe("mlc",&checks)!=6||checks||calls!=1)return 5;
    reset();if(sitonfixer_initialization_probe("mlc",&checks)||checks!=255||calls!=1)return 6;
    if(sitonfixer_initialization_probe("mlc",&checks)!=2||checks||calls!=1)return 7;
    for(uint32_t bit=1;bit<=128;bit<<=1) {
        reset();if(bit==64)postDirty=true;else omitted=bit;
        if(sitonfixer_initialization_probe("mlc",&checks)!=5||checks!=(255u^bit)||calls!=1)return 8;
    }
    return 0;
}
'''
with tempfile.TemporaryDirectory(prefix='sitonfixer-init-') as folder:
    cpp,exe=pathlib.Path(folder)/'check.cpp',pathlib.Path(folder)/'check'
    cpp.write_text(source,encoding='utf-8')
    compiler=[os.environ['SITONFIXER_TEST_CLANG']] if os.environ.get('SITONFIXER_TEST_CLANG') else ['xcrun','clang++']
    subprocess.run(compiler+['-std=c++20',str(cpp),'-o',str(exe)],check=True)
    subprocess.run([str(exe)],check=True)
    if sys.platform == 'darwin':
        # The fake OS structure above tests refusal paths only. Also compile the
        # real process guard against the actual iOS SDK types and declarations.
        sdk=subprocess.check_output(['xcrun','--sdk','iphoneos','--show-sdk-path'],text=True).strip()
        ios=pathlib.Path(folder)/'ios-check.cpp'
        ios.write_text(r'''
#include <atomic>
#include <cstdint>
#include <cstddef>
#include <sys/sysctl.h>
#include <sys/proc.h>
#include <unistd.h>
extern "C" int csops(pid_t,unsigned,void*,size_t);
std::atomic<bool> g_initialized{false},g_initializationComplete{false},g_recompilerRequested{true};
constexpr int kCpuModeInterpreter=1;std::atomic<int> g_cpuMode{0};
uint8_t* memory_base=nullptr;
struct Range {bool isMapped() const {return false;}};
Range mmuRange_CEMU_AREA,mmuRange_SHARED_AREA;
bool CemuIsInitialized(){return false;}
bool cemu_bridge_is_title_running(){return false;}
void cemu_bridge_initialize(const char*){}
'''+(root/'src/ios/Bridge/OfflineInitializationProbe.inc').read_text(encoding='utf-8'),encoding='utf-8')
        subprocess.run(['xcrun','--sdk','iphoneos','clang++','-std=c++20',
            '-target','arm64-apple-ios17.4','-isysroot',sdk,'-fsyntax-only',str(ios)],check=True)
print('Initialization diagnostic: all 8 independent conditions, dirty/prior states, exception, bad arguments and repeat refusal passed with controlled substitutes; not a real engine boot.')
