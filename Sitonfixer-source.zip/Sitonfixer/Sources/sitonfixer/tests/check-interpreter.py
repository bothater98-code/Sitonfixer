"""Run the actual fixture/checker against independent Unicorn PPC32 instructions.

The host shared library uses substitute CPU/allocator/initialization interfaces.
Unicorn supplies each single-instruction callback, not the production Cemu
interpreter. Full core compilation and physical execution test that boundary.
"""
import ctypes as C
import _ctypes
import os, pathlib, subprocess, sys, tempfile
from unicorn import Uc, UC_ARCH_PPC, UC_MODE_32, UC_MODE_BIG_ENDIAN
from unicorn.ppc_const import UC_PPC_REG_0, UC_PPC_REG_PC, UC_PPC_REG_LR, UC_PPC_REG_CTR, UC_PPC_REG_CR, UC_PPC_REG_XER

root=pathlib.Path(__file__).resolve().parents[2]
source=r'''
#include <array>
#include <algorithm>
#include <atomic>
#include <cstdint>
#include <cstring>
#include <cstddef>
using uint8=uint8_t;using uint32=uint32_t;
struct FPR {double fp0,fp1;};
struct PPCInterpreterGlobal_t {struct {uint32_t scr,car;} sprGlobal;uint64_t tb;};
struct PPCInterpreter_t {
    uint32_t instructionPointer,gpr[32];FPR fpr[32];
    struct {uint32_t LR,CTR,XER,UPIR,UGQR[8];} spr;
    uint32_t cr,fpscr;uint8_t xer_ca,xer_so,xer_ov;
    int32_t remainingCycles,skippedCycles;bool memoryException;
    PPCInterpreterGlobal_t* global;
};
std::array<uint8_t,0x5000> testMemory{};
uint8_t* memory_base=testMemory.data();
static bool badAllocation=false,clean=true,title=false,initialized=false;
static int initCode=0;static uint32_t initMask=255;
struct Range {uint32_t getBase()const{return 0x1000;}uint32_t getEnd()const{return 0x2000;}bool isMapped()const{return true;}} mmuRange_CEMU_AREA;
template<typename T,size_t Count,size_t Alignment> struct SysAllocator {
    uint32_t GetMPTR()const{return badAllocation?0:0x1000;}
    T* GetPtr()const{return reinterpret_cast<T*>(memory_base+0x1000);}
};
using Step=void(*)(PPCInterpreter_t*);static Step step=nullptr;
void PPCInterpreterSlim_executeInstruction(PPCInterpreter_t* cpu){step(cpu);}
void PPCInterpreter_jumpToInstruction(PPCInterpreter_t* cpu,uint32_t ip){cpu->instructionPointer=ip;}
void (*attemptEnterAddr)(PPCInterpreter_t*,uint32_t)=PPCInterpreter_jumpToInstruction;
bool sitonfixer_initialization_process_clean(){return clean;}
bool cemu_bridge_is_title_running(){return title;}
int sitonfixer_initialization_probe(const char*,uint32_t* checks){
    *checks=0;if(initialized)return 2;initialized=true;*checks=initMask;return initCode;
}
#ifdef _WIN32
#define EXPORT extern "C" __declspec(dllexport)
EXPORT int sitonfixer_interpreter_probe(const char*,uint32_t*,uint32_t*,uint32_t*) noexcept;
#else
#define EXPORT extern "C"
#endif
'''
source+=(root/'src/ios/Bridge/OfflineInterpreterProbe.inc').read_text(encoding='utf-8')
source+=r'''
EXPORT void fixture_reset(Step callback,int condition){
    step=callback;initialized=false;badAllocation=condition==1;clean=condition!=2;title=condition==3;
    initCode=condition==4?5:0;initMask=condition==5?254:255;testMemory.fill(0x7e);
    attemptEnterAddr=condition==6?nullptr:PPCInterpreter_jumpToInstruction;
}
EXPORT uint8_t* fixture_memory(){return testMemory.data();}
'''

class FPR(C.Structure):_fields_=[('fp0',C.c_double),('fp1',C.c_double)]
class SPR(C.Structure):_fields_=[(n,C.c_uint32) for n in ('LR','CTR','XER','UPIR')]+[('UGQR',C.c_uint32*8)]
class GlobalSPR(C.Structure):_fields_=[('scr',C.c_uint32),('car',C.c_uint32)]
class Global(C.Structure):_fields_=[('sprGlobal',GlobalSPR),('tb',C.c_uint64)]
class CPU(C.Structure):
    _fields_=[('instructionPointer',C.c_uint32),('gpr',C.c_uint32*32),('fpr',FPR*32),('spr',SPR),
              ('cr',C.c_uint32),('fpscr',C.c_uint32),('xer_ca',C.c_uint8),('xer_so',C.c_uint8),('xer_ov',C.c_uint8),
              ('remainingCycles',C.c_int32),('skippedCycles',C.c_int32),('memoryException',C.c_bool),('global_',C.POINTER(Global))]
Step=C.CFUNCTYPE(None,C.POINTER(CPU))

with tempfile.TemporaryDirectory(prefix='sitonfixer-interpreter-',ignore_cleanup_errors=sys.platform=='win32') as folder:
    cpp=pathlib.Path(folder)/'check.cpp';cpp.write_text(source,encoding='utf-8')
    windows=sys.platform=='win32'
    library=pathlib.Path(folder)/('check.dll' if windows else 'check.dylib')
    compiler=[os.environ['SITONFIXER_TEST_CLANG']] if os.environ.get('SITONFIXER_TEST_CLANG') else ['xcrun','clang++']
    flags=['-shared'] if windows else ['-dynamiclib','-fPIC']
    subprocess.run(compiler+['-std=c++20']+flags+['-I'+str(root/'src/ios/Bridge'),str(cpp),'-o',str(library)],check=True)
    lib=C.CDLL(str(library));lib.fixture_reset.argtypes=[Step,C.c_int];lib.fixture_memory.restype=C.POINTER(C.c_uint8)
    lib.sitonfixer_interpreter_probe.argtypes=[C.c_char_p]+[C.POINTER(C.c_uint32)]*3
    memory=lib.fixture_memory();base=C.addressof(memory.contents)
    uc=Uc(UC_ARCH_PPC,UC_MODE_32|UC_MODE_BIG_ENDIAN);uc.mem_map(0x1000,4096)
    errors=[];callback_count=0;fault=None
    @Step
    def execute(pointer):
        global callback_count
        try:
            cpu=pointer.contents
            uc.mem_write(0x1000,C.string_at(base+0x1000,4096))
            for i in range(32):uc.reg_write(UC_PPC_REG_0+i,cpu.gpr[i])
            uc.reg_write(UC_PPC_REG_LR,cpu.spr.LR);uc.reg_write(UC_PPC_REG_CTR,cpu.spr.CTR)
            uc.reg_write(UC_PPC_REG_CR,cpu.cr)
            uc.reg_write(UC_PPC_REG_XER,(cpu.xer_ca<<29)|(cpu.xer_ov<<30)|(cpu.xer_so<<31))
            uc.emu_start(cpu.instructionPointer,0,count=1)
            for i in range(32):cpu.gpr[i]=uc.reg_read(UC_PPC_REG_0+i)
            cpu.spr.LR=uc.reg_read(UC_PPC_REG_LR);cpu.spr.CTR=uc.reg_read(UC_PPC_REG_CTR)
            cpu.cr=uc.reg_read(UC_PPC_REG_CR);cpu.instructionPointer=uc.reg_read(UC_PPC_REG_PC)
            xer=uc.reg_read(UC_PPC_REG_XER);cpu.xer_ca=(xer>>29)&1;cpu.xer_ov=(xer>>30)&1;cpu.xer_so=(xer>>31)&1
            C.memmove(base+0x1000,bytes(uc.mem_read(0x1000,4096)),4096)
            callback_count+=1
            if fault=='pc':cpu.instructionPointer=0xffff0000
            if fault=='register':cpu.gpr[31]^=1
            if fault=='guard':memory[0x1000+4095]^=1
        except Exception as error:
            errors.append(repr(error));pointer.contents.instructionPointer=0xffff0000
    def run(condition=0,corruption=None):
        global fault,callback_count
        fault=corruption;callback_count=0;errors.clear();lib.fixture_reset(execute,condition)
        checks,completed,executed=C.c_uint32(999),C.c_uint32(999),C.c_uint32(999)
        result=lib.sitonfixer_interpreter_probe(b'mlc',C.byref(checks),C.byref(completed),C.byref(executed))
        assert not errors,errors
        return result,checks.value,completed.value,executed.value
    assert run()==(0,255,32,320)
    assert callback_count==320
    assert C.string_at(base+0x1000,4096)==bytes(4096),'owned block was not cleared'
    assert C.string_at(base,0x1000)==b'\x7e'*0x1000 and C.string_at(base+0x2000,0x3000)==b'\x7e'*0x3000
    assert run(1)==(3,255,0,0)
    assert run(2)==(6,255,32,320)
    assert run(3)==(6,255,32,320)
    assert run(4)==(105,255,0,0)
    assert run(5)==(2,254,0,0)
    assert run(6)==(9,255,0,0)
    assert run(corruption='pc')==(4,255,0,1)
    # One odd number of mutations ensures the final guard/register differs.
    original_execute=execute
    # Mutate only the first callback; every later instruction remains normal.
    @Step
    def corrupt_once(pointer):
        global fault
        original_execute(pointer);fault=None
    for mode in ('register','guard'):
        fault=mode;callback_count=0;errors.clear();lib.fixture_reset(corrupt_once,0)
        checks,completed,executed=C.c_uint32(),C.c_uint32(),C.c_uint32()
        assert lib.sitonfixer_interpreter_probe(b'mlc',C.byref(checks),C.byref(completed),C.byref(executed))==5
        assert completed.value==0 and executed.value==10 and not errors
        assert C.string_at(base+0x1000,4096)==bytes(4096)
    checks,completed,executed=C.c_uint32(9),C.c_uint32(9),C.c_uint32(9)
    lib.fixture_reset(execute,0)
    assert lib.sitonfixer_interpreter_probe(None,C.byref(checks),C.byref(completed),C.byref(executed))==1
    assert (checks.value,completed.value,executed.value)==(0,0,0)
    if windows: _ctypes.FreeLibrary(lib._handle)
print('Actual fixture/checker: 32 PPC32 ISA cases, 320 calls, bounded trace, RAM/code guards and cleanup passed using Unicorn plus CPU/allocator/init substitutes. Production Cemu interpreter execution remains a physical test.')
