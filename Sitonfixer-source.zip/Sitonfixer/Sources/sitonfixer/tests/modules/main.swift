// SPDX-License-Identifier: GPL-3.0-only
import Foundation

// A tiny ABI-compatible native function, checked by an independent ARM64 emulator.
// It increments CPU word zero once; bridges must preserve CPU/RAM arguments and stack.
let body: [UInt32] = [0xb9400009, 0x11000529, 0xb9000009, 0xd65f03c0]
let module = try SignedProbeModule.compose(frontend: body)
precondition(module.count * 4 == 65_536)
precondition(SignedProbeModule.entryOffsets == [0, 32_768, 49_152])
precondition(Array(module[8192..<8196]) == body)
for invalid in [[], Array(repeating: UInt32(0xd503201f), count: 258)] {
    do { _ = try SignedProbeModule.compose(frontend: invalid); fatalError("Invalid body accepted") }
    catch is ScalarTranslation.Failure { }
}
let original = try Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1]))
let image = try ScalarTranslation.replaceText(in: original, instructions: module)
precondition(image.count == original.count)
do {
    _ = try ScalarTranslation.replaceText(in: original, instructions: module + [0xd65f03c0])
    fatalError("Oversized module accepted")
} catch is ScalarTranslation.Failure { }
var wrongCPU = original
wrongCPU[4] = 0
do {
    _ = try ScalarTranslation.replaceText(in: wrongCPU, instructions: module)
    fatalError("Wrong CPU accepted")
} catch is ScalarTranslation.Failure { }
try image.write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
print("64 KiB module layout prepared by the actual Swift composer; invalid sizes rejected.")
