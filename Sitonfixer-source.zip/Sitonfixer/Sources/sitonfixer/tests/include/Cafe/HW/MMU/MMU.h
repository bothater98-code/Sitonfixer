// Test stub: production MMU must not be accessed.
#pragma once
