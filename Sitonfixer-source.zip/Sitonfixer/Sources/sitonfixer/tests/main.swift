// SPDX-License-Identifier: GPL-3.0-only
import Foundation
struct Fixture: Codable { let words: [UInt32]; let registers: [UInt32]; let expected: [UInt32] }
let fixtures = try JSONDecoder().decode([Fixture].self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let translated = try fixtures.map { try ScalarTranslation.translate($0.words) }
let badBlocks: [[UInt32]] = [[0x38600001], [0x4e800020, 0x4e800020], [0x80640000, 0x4e800020], [0x7cc32a15, 0x4e800020], [0x7cc32e14, 0x4e800020]]
for bad in badBlocks {
    do { _ = try ScalarTranslation.translate(bad); fatalError("unsupported input was accepted") }
    catch is ScalarTranslation.Failure { }
}
for size in 0..<80 {
    do { _ = try ScalarTranslation.replaceText(in: Data(repeating: 0, count: size), instructions: [0xd65f03c0]); fatalError("invalid Mach-O accepted") }
    catch is ScalarTranslation.Failure { }
}
try JSONEncoder().encode(translated).write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
