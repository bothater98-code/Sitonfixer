// SPDX-License-Identifier: GPL-3.0-only
import Foundation
struct Fixture: Codable { let words: [UInt32]; let registers: [UInt32]; let expected: [UInt32] }
let fixtures = try JSONDecoder().decode([Fixture].self, from: Data(contentsOf: URL(fileURLWithPath: CommandLine.arguments[1])))
let translated = try fixtures.map { try ScalarTranslation.translate($0.words) }
let now = Date(timeIntervalSince1970: 1_000_000)
let key = Data([0xfb, 0xff, 0xef, 0x01])
func callback(_ nonce: String = "fresh", password: String = "test+password") -> URL {
    var url = URLComponents(string: "sitonfixer-aot://certificate")!
    url.queryItems = [.init(name: "nonce", value: nonce), .init(name: "cert", value: key.base64EncodedString()), .init(name: "password", value: password)]
    return url.url!
}
let deadline = now.addingTimeInterval(120)
let valid = CertificateCallback.parse(callback(), nonce: "fresh", deadline: deadline, now: now)
precondition(valid?.certificate == key && valid?.password == "test+password")
precondition(CertificateCallback.parse(callback(), nonce: nil, deadline: deadline, now: now) == nil)
precondition(CertificateCallback.parse(callback("wrong"), nonce: "fresh", deadline: deadline, now: now) == nil)
precondition(CertificateCallback.parse(callback(), nonce: "fresh", deadline: now, now: now) == nil)
precondition(CertificateCallback.parse(callback(password: String(repeating: "x", count: 4097)), nonce: "fresh", deadline: deadline, now: now) == nil)
for badURL in [callback().absoluteString + "&cert=QQ==", callback().absoluteString + "#fragment", callback().absoluteString.replacingOccurrences(of: "sitonfixer-aot:", with: "https:")] {
    precondition(CertificateCallback.parse(URL(string: badURL)!, nonce: "fresh", deadline: deadline, now: now) == nil)
}
let badBlocks: [[UInt32]] = [[0x38600001], [0x4e800020, 0x4e800020], [0x80640000, 0x4e800020], [0x7cc32a15, 0x4e800020], [0x7cc32e14, 0x4e800020]]
for bad in badBlocks {
    do { _ = try ScalarTranslation.translate(bad); fatalError("unsupported input was accepted") }
    catch is ScalarTranslation.Failure { }
}
for size in 0..<80 {
    do { _ = try ScalarTranslation.replaceText(in: Data(repeating: 0, count: size), instructions: [0xd65f03c0]); fatalError("invalid Mach-O accepted") }
    catch is ScalarTranslation.Failure { }
}
try JSONEncoder().encode(translated).write(to: URL(fileURLWithPath: CommandLine.arguments[2]))
