# Revisión 15: intérprete real y memoria propia de Cemu

La revisión 14 pasó en el dispositivo según la respuesta del usuario al
protocolo de reinicio completo sin USB/red/VPN: ocho condiciones de
inicialización. La confianza inicial de esa instalación se verificó antes con
Internet. No se habían ejecutado instrucciones del intérprete.

## Alcance de la prueba nueva

El botón **Probar intérprete real con RAM de Cemu**, en **Motor real sin
certificado**, inicializa primero el motor usando la prueba 14. No se pulsa
primero el botón 14 en la misma sesión: ambos reclaman el proceso hasta cerrarlo.
Se conserva la misma exclusión de GameManager, del cierre y de otras pruebas.

`OfflineInterpreterProbe.inc` registra un `SysAllocator<uint8_t,4096,4096>`
estático antes de inicializar el motor. El contenedor original le asigna un
bloque en CEMU_AREA. Se valida dirección invitada, alineación, pertenencia al
rango mapeado y relación con el puntero de memoria real. No se reemplaza
`memory_base`, no se elige una página arbitraria ni se crea el SysHeap de un
título para obtener memoria temporal.

La asignación pertenece al proceso: el allocator del área de sistema no ofrece
una liberación individual implementada. Se reservan 4 KiB por proceso, se
limpian al salir de la prueba y se conservan hasta terminar el proceso. No es
un gestor de memoria de juegos. La inicialización normal de esta compilación
también reserva esos 4 KiB, aunque no se pulse la prueba.

Se reutiliza la semántica de las dos funciones PPC de la revisión 13,
reubicándolas en el bloque asignado: mflr/add/bl/mtlr/addi/blr en A y
stw/lwz/addi/blr en B. Antes de cada llamada a
`PPCInterpreterSlim_executeInstruction` se comprueba la dirección esperada del
recorrido de diez instrucciones. Las instrucciones de rama de Cemu pasan por
`attemptEnterAddr`; se exige que apunte a
`PPCInterpreter_jumpToInstruction` antes de ejecutar, sin cambiar ese puntero.
No se invoca scheduler, HLE, compilación o despacho de módulos firmados.

Son **32 estados y 320 llamadas a la API de una instrucción**, comprobando
registros enteros/flotantes, SPR/LR/CTR, CR/FPSCR/XER, IP, estado global de CPU,
ausencia de excepción y los 4096 bytes completos, incluidos código y guardas.
El store big-endian debe afectar solo a sus cuatro bytes. La API de una
instrucción no descuenta el presupuesto del scheduler: se comprueba que los
campos de ciclos se conservan y se cuenta aparte el número de instrucciones.
No se presenta ese conteo como tiempo de emulación ni como rendimiento.

## Validación previa

El test host compila el fixture y comprobador reales en una biblioteca con
interfaces sustitutas de CPU/allocator/inicialización. Un callback ejecuta cada
instrucción PPC32 con Unicorn, sincronizando registros y los 4 KiB: 32 casos,
320 llamadas, ruta exacta, endianess, guardas y limpieza. Comprueba también
rechazos de puntero de despacho, asignación, estado limpio, título, máscara,
inicialización, argumentos, saltos inesperados y corrupción de registro/guarda.
No ejecuta el intérprete Cemu de producción ni el allocator real en el host.
La compilación completa y la prueba física cubren esa frontera, sin atribuir
al test host resultados que no mide.

El gate de exportaciones exige diez símbolos de pruebas. La UI separa las dos
pruebas del motor sin certificado de las pruebas de módulos firmados con .p12.
No hay cambios en el firmador Rust, identidad, perfiles o permisos.

## Prueba física pendiente

Después de instalar y verificar la revisión 15: abrir desde icono con Internet
solo si iOS exige verificar esa nueva instalación; desconectar USB/VPN, activar
modo avión, apagar Wi-Fi, reiniciar completamente sin conexión y abrir desde
icono. En JIT → Motor real sin certificado, pulsar directamente **Probar
intérprete real con RAM de Cemu**, sin .p12. Esperado: ocho condiciones,
32 casos y 320 instrucciones. Copiar resultado o SF-INTERP con código,
máscara/casos/instrucciones; después cerrar completamente la app.

Siguen pendientes el recorrido mixto módulos firmados/intérprete, publicación
en tablas de juegos con dueño de sesión e invalidación segura, mapeo por
título, gráficos/audio/partidas, rendimiento y renovación autónoma.
