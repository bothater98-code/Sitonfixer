"""Reconstruct a checksum-pinned LGPL signing dependency with the library fix.

Upstream: https://github.com/Dadoum/apple-crates, apple-codesign-quick 0.1.0.
Changes: omit entitlement blobs and their hashes from non-main Mach-O binaries.
No user data, credentials, provisioning profiles or phone connection are used.
"""
import argparse,hashlib,io,json,tarfile,urllib.request
from pathlib import Path

CHECKSUM='519defc726db80b8a43836bbd6f69eb606a42783db799716a103436042593f0b'
VERSION='apple-codesign-quick-0.1.0'
ROOT=Path(__file__).resolve().parent.parent
TARGET=ROOT/'.sitonfixer-deps'/VERSION

def change(text,old,new):
    assert text.count(old)==1,'Pinned source does not match the reviewed change'
    return text.replace(old,new)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--archive',type=Path)
    args=parser.parse_args()
    patch_id=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    if TARGET.exists():
        stamp=json.loads((TARGET/'sitonfixer-patch.json').read_text())
        assert stamp['patch_id']==patch_id,'Existing dependency uses another patch; preserve it and use a fresh checkout'
        for name,digest in stamp['sources'].items():
            assert hashlib.sha256((TARGET/name).read_bytes()).hexdigest()==digest
        print('Reviewed library-signature fix already prepared');return
    archive=args.archive.read_bytes() if args.archive else urllib.request.urlopen(
        'https://crates.io/api/v1/crates/apple-codesign-quick/0.1.0/download',timeout=60).read()
    assert hashlib.sha256(archive).hexdigest()==CHECKSUM,'Dependency checksum mismatch'
    TARGET.mkdir(parents=True,exist_ok=False)
    with tarfile.open(fileobj=io.BytesIO(archive),mode='r:gz') as tar:
        for member in tar.getmembers():
            relative=Path(member.name)
            assert relative.parts[0]==VERSION and '..' not in relative.parts and not relative.is_absolute()
            destination=TARGET.joinpath(*relative.parts[1:]).resolve()
            assert destination.is_relative_to(TARGET.resolve())
            if member.isdir():destination.mkdir(parents=True,exist_ok=True)
            else:
                assert member.isfile(),'Unexpected non-file in dependency archive'
                destination.parent.mkdir(parents=True,exist_ok=True)
                destination.write_bytes(tar.extractfile(member).read())
    macho=TARGET/'src/macho.rs'
    text=macho.read_text()
    text=change(text,'    let entitlements = entitlements_blob(&entitlements_xml);',
        '    // Sitonfixer: iOS rejects entitlement blobs on non-main binaries.\n'
        '    let entitlements = if macho.is_executable() { entitlements_blob(&entitlements_xml) } else { Vec::new() };')
    test='''    #[test]
    fn sitonfixer_library_has_no_entitlements_and_main_keeps_them() {
        for file_type in [2u32, 6u32] {
            let mut macho = minimal_macho_with_empty_signature();
            LittleEndian::write_u32(&mut macho[12..16], file_type);
            let mut permissions = Dictionary::new();
            if file_type == 2 { permissions.insert("get-task-allow".into(), plist::Value::Boolean(true)); }
            let config = MachOSigningConfig::new("dev.sitonfixer.test", "TESTTEAM", &permissions, None);
            let signed = sign_macho_data(Path::new("SyntheticOnly"), &macho, &config).unwrap();
            let command = 32 + 72 + 72;
            let start = LittleEndian::read_u32(&signed[command+8..command+12]) as usize;
            let count = BigEndian::read_u32(&signed[start+8..start+12]) as usize;
            let mut slots = Vec::new();
            for index in 0..count {
                let p = start + 12 + index*8;
                let slot = BigEndian::read_u32(&signed[p..p+4]);
                slots.push(slot);
                if file_type == 6 && (slot == 0 || slot == 4096) {
                    let cd = start + BigEndian::read_u32(&signed[p+4..p+8]) as usize;
                    let hashes = BigEndian::read_u32(&signed[cd+16..cd+20]) as usize;
                    let width = signed[cd+36] as usize;
                    // Absent slot -5 must be zero, not the digest of an empty byte array.
                    assert!(signed[cd+hashes-5*width..cd+hashes-4*width].iter().all(|b| *b == 0));
                }
            }
            assert_eq!(slots.contains(&5), file_type == 2);
            assert_eq!(slots.contains(&7), file_type == 2);
        }
    }

'''
    text=change(text,'    #[test]\n    fn signs_thin_macho_by_growing_existing_code_signature()',test+'    #[test]\n    fn signs_thin_macho_by_growing_existing_code_signature()')
    macho.write_text(text,encoding='utf-8',newline='\n')
    signature=TARGET/'src/signature.rs';text=signature.read_text()
    text=change(text,'    let count = 4\n        + usize::from(plan.der_entitlements_blob_len.is_some())',
        '    let count = 3\n        + usize::from(plan.entitlements_blob_len > 0)\n        + usize::from(plan.der_entitlements_blob_len.is_some())')
    text=change(text,'        (CSSLOT_ENTITLEMENTS, Cow::Borrowed(params.entitlements_blob)),\n','')
    text=change(text,'    if let Some(der_entitlements_blob) = params.der_entitlements_blob {',
        '    if !params.entitlements_blob.is_empty() {\n'
        '        blobs.push((CSSLOT_ENTITLEMENTS, Cow::Borrowed(params.entitlements_blob)));\n'
        '    }\n\n    if let Some(der_entitlements_blob) = params.der_entitlements_blob {')
    text=change(text,'    algorithm.push_digest(&mut out, params.entitlements_blob);',
        '    if params.entitlements_blob.is_empty() {\n'
        '        push_zero_hash(&mut out, hash_len);\n'
        '    } else {\n        algorithm.push_digest(&mut out, params.entitlements_blob);\n    }')
    signature.write_text(text,encoding='utf-8',newline='\n')
    sources={p.relative_to(TARGET).as_posix():hashlib.sha256(p.read_bytes()).hexdigest()
        for p in TARGET.rglob('*') if p.is_file()}
    (TARGET/'sitonfixer-patch.json').write_text(json.dumps({'upstream_checksum':CHECKSUM,
        'patch_id':patch_id,'license':'LGPL-2.1-or-later','sources':sources},indent=2))
    print('Prepared checksum-verified library-signature correction; no phone or credentials used')

if __name__=='__main__':main()
