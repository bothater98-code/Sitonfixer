"""Syntax/project checks only. This is not an Xcode compile or an iOS runtime test."""
import json
import plistlib
import subprocess
from pathlib import Path
import tree_sitter
import tree_sitter_swift
import yaml

root = Path(__file__).resolve().parents[1]
parser = tree_sitter.Parser(tree_sitter.Language(tree_sitter_swift.language()))
paths = set(subprocess.check_output(['git', '-C', str(root), '-c', 'core.safecrlf=false',
    'diff', '--name-only'], text=True).splitlines())
paths.update(subprocess.check_output(['git', '-C', str(root), 'ls-files', '--others', '--exclude-standard'],
    text=True).splitlines())
issues = []
count = 0
for name in sorted(paths):
    path = root/name
    if path.suffix == '.swift':
        count += 1
        def walk(node):
            if node.type == 'ERROR' or node.is_missing:
                issues.append({'file': name, 'line': node.start_point.row + 1})
            for child in node.children:
                walk(child)
        walk(parser.parse(path.read_bytes()).root_node)
    if path.suffix in ('.plist', '.entitlements'):
        plistlib.loads(path.read_bytes())
project = yaml.safe_load((root/'src/ios/project.yml').read_text(encoding='utf-8'))
for target in ('MuffinEMU', 'MuffinJITHelper'):
    for entry in project['targets'][target]['sources']:
        if not (root/'src/ios'/entry['path']).exists():
            raise SystemExit('Source missing from project: ' + entry['path'])
host_entitlements = plistlib.loads((root/'src/ios/LocalTunnel/Sitonfixer.entitlements').read_bytes())
assert 'com.apple.developer.networking.networkextension' not in host_entitlements
assert 'IslaLocalTunnel' not in project['targets']
result = {'swift_files_parsed': count, 'syntax_issues': issues,
    'project_and_plists_valid': True, 'compiled_with_xcode': False,
    'installed_on_iphone': False, 'offline_runtime_validated': False}
print(json.dumps(result, indent=2))
raise SystemExit(bool(issues))
