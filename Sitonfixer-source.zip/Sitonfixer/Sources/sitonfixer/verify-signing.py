"""Validate development profiles and final entitlements without printing personal identifiers."""
import datetime
import os
import plistlib
import subprocess
import sys
from pathlib import Path

KEY = 'com.apple.developer.networking.networkextension'

def capture(*args):
    return subprocess.check_output(args, stderr=subprocess.DEVNULL)

def profile(path):
    return plistlib.loads(capture('/usr/bin/security', 'cms', '-D', '-i', str(path)))

def validate(app):
    bundles = [(app, True, False), (app/'PlugIns/MuffinJITHelper.appex', True, False)]
    teams = set()
    for bundle, debug, network in bundles:
        info = plistlib.loads((bundle/'Info.plist').read_bytes())
        p = profile(bundle/'embedded.mobileprovision')
        ent = p['Entitlements']
        teams.add(ent['com.apple.developer.team-identifier'])
        appid = ent['application-identifier'].split('.', 1)[1]
        if appid != info['CFBundleIdentifier']:
            raise ValueError('Se requiere un perfil explícito para cada bundle de esta app')
        if p['ExpirationDate'] <= datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None):
            raise ValueError('Perfil caducado')
        if debug and ent.get('get-task-allow') is not True:
            raise ValueError('El perfil no permite la depuración necesaria para JIT')
        if network and 'packet-tunnel-provider' not in ent.get(KEY, []):
            raise ValueError('El perfil no autoriza la extensión de red')
    if len(teams) != 1:
        raise ValueError('Los dos perfiles deben pertenecer al mismo equipo')
    return bundles

if __name__ == '__main__':
    try:
        app = Path(sys.argv[1]).resolve()
        bundles = validate(app)
        if '--signed' in sys.argv:
            for bundle, debug, network in bundles:
                ent = plistlib.loads(capture('/usr/bin/codesign', '-d', '--entitlements', ':-', str(bundle)))
                if debug and ent.get('get-task-allow') is not True:
                    raise ValueError('La firma ha eliminado get-task-allow')
                if network and 'packet-tunnel-provider' not in ent.get(KEY, []):
                    raise ValueError('La firma ha eliminado Network Extension')
            subprocess.run(['/usr/bin/codesign', '--verify', '--deep', '--strict', str(app)], check=True,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print('Perfiles y permisos requeridos correctos; no se muestran identificadores personales.')
    except Exception as error:
        print('Verificación fallida:', type(error).__name__, str(error) if isinstance(error, ValueError) else '', file=sys.stderr)
        raise SystemExit(1)
