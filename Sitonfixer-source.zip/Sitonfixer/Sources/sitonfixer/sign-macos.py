"""Sign only using an identity already in this Mac's Keychain; no passwords or uploads."""
import os
import plistlib
import shutil
import subprocess
from pathlib import Path

root = Path(__file__).resolve().parents[1]
app = root/'sitonfixer-dist/Payload/Sitonfixer.app'
identity = os.environ.get('SITONFIXER_SIGNING_IDENTITY')
if not identity:
    raise SystemExit('Falta SITONFIXER_SIGNING_IDENTITY: una identidad de desarrollo ya presente en el llavero del ejecutor.')
destinations = [(app, 'SITONFIXER_HOST_PROFILE'),
    (app/'PlugIns/MuffinJITHelper.appex', 'SITONFIXER_JIT_PROFILE')]
for dest, variable in destinations:
    value = os.environ.get(variable)
    if not value or not Path(value).is_file():
        raise SystemExit('Falta un perfil local requerido: ' + variable)
    shutil.copyfile(value, dest/'embedded.mobileprovision')
subprocess.run(['python3', str(root/'sitonfixer/verify-signing.py'), str(app)], check=True)
for framework in sorted((app/'Frameworks').rglob('*.framework'), key=lambda p: len(p.parts), reverse=True):
    subprocess.run(['/usr/bin/codesign', '--force', '--sign', identity, '--timestamp=none', str(framework)], check=True,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
for dest, _ in reversed(destinations):
    data = subprocess.check_output(['/usr/bin/security', 'cms', '-D', '-i', str(dest/'embedded.mobileprovision')],
                                   stderr=subprocess.DEVNULL)
    # Use the entitlements actually authorized by the development profile.
    ent = plistlib.loads(data)['Entitlements']
    temporary = root/'sitonfixer-dist/signing-entitlements.plist'
    try:
        temporary.write_bytes(plistlib.dumps(ent))
        subprocess.run(['/usr/bin/codesign', '--force', '--sign', identity, '--timestamp=none',
                        '--entitlements', str(temporary), str(dest)], check=True,
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    finally:
        temporary.unlink(missing_ok=True)
subprocess.run(['python3', str(root/'sitonfixer/verify-signing.py'), str(app), '--signed'], check=True)
subprocess.run(['/usr/bin/ditto', '-c', '-k', '--keepParent', str(root/'sitonfixer-dist/Payload'),
                str(root/'sitonfixer-dist/Sitonfixer-signed.ipa')], check=True)
print('IPA firmada y verificada localmente. No se ha instalado ni publicado.')
