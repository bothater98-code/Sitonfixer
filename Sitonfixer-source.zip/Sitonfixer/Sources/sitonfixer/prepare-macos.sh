#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
[[ "$(uname -s)" == Darwin ]] || { echo 'Se necesita un ejecutor macOS; no se usa el iPhone por USB.' >&2; exit 2; }
command -v brew >/dev/null || { echo 'Este ejecutor necesita Homebrew instalado.' >&2; exit 2; }
xcodebuild -version
sdk="$(xcrun --sdk iphoneos --show-sdk-version)"
[[ "${sdk%%.*}" -ge 27 ]] || { echo 'La base upstream requiere el SDK iOS 27 para compilar.' >&2; exit 2; }
brew bundle --file=sitonfixer/Brewfile
if ! command -v rustup >/dev/null; then
  curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh -s -- -y --profile minimal
fi
export PATH="$HOME/.cargo/bin:$PATH"
rustup toolchain install stable --profile minimal
rustup target add aarch64-apple-ios
if ! xcrun --sdk iphoneos metal --version >/dev/null 2>&1; then
  xcodebuild -downloadComponent MetalToolchain
fi
if [[ "${SITONFIXER_BUILD_CORE_FROM_SOURCE:-0}" == 1 ]]; then
  git submodule sync --recursive
  git submodule update --init --recursive
fi
echo 'Entorno macOS preparado. No se ha instalado nada en un iPhone ni publicado archivos.'
