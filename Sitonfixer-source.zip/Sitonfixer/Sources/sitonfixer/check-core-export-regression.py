"""Exercise the shell gate with large tables and a genuinely missing definition."""
import pathlib, subprocess, tempfile, shutil

root = pathlib.Path(__file__).resolve().parent
bash = shutil.which('bash')
assert bash, 'bash is required for the actual shell gate'
with tempfile.TemporaryDirectory(prefix='sitonfixer-export-check-') as folder:
    dump = pathlib.Path(folder) / 'symbols.txt'
    before = ''.join(f'0000000000000010 T _fixture_before_{i}\n' for i in range(32000))
    after = ''.join(f'0000000000000020 T _fixture_after_{i}\n' for i in range(32000))
    required = ['_sitonfixer_backend_probe_prepare', '_sitonfixer_backend_probe_check']
    for case in ('large-valid', 'missing', 'suffix-collision'):
        names = required if case == 'large-valid' else [required[0], required[1] + '_wrong']
        if case == 'missing': names = required[:1]
        dump.write_text(before + ''.join(f'0000000000000030 T {name}\n' for name in names) + after, encoding='utf-8')
        result = subprocess.run([bash, str(root / 'check-core-exports.sh'), str(dump)], capture_output=True, text=True)
        assert (result.returncode == 0) == (case == 'large-valid'), (case, result.stdout, result.stderr)
        assert 'Broken pipe' not in result.stderr and 'i/o error' not in result.stderr
print('Core export gate: large valid table accepted; missing and suffixed symbols rejected.')
