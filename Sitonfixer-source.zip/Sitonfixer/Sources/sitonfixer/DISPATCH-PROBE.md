# Cross-module PowerPC dispatch: revision 13

Revision 12 passed on the user's iPhone after a full offline reboot: two distinct
images, 192 cases with shared Cemu entry/exit stubs and explicit context arguments.
This is user-reported evidence, without simultaneous USB observation.

The revision 13 fixture replaces the single PPC9 program with two different
trusted programs in `OfflineDispatchPrograms.h`:

- A at 0x1000 saves guest LR in r10, adds r3+r4, calls B with `bl`, restores LR,
  adds three to B's result and returns. Its continuation at 0x100c is explicitly
  enterable, allowing B's `blr` to dispatch back into A.
- B at 0x2000 stores and loads big-endian RAM, adds five and returns through guest
  LR. The complete path has six caller instructions and four callee instructions.

Each function independently traverses Cemu's boundary tracker, decoder, optimizer,
register allocator and inert ARM64 emitter. A has two guest entry offsets; B has
one. Each image contains the shared real entry/exit stubs at the beginning and its
function body at offset 32768 in the existing trusted 64 KiB carrier. The normal
recompiler initialization and all game tables remain unchanged.

Swift signs and loads the images with distinct identities, then borrows all five
required entries simultaneously for the entire C++ check. The pointers never
escape those scopes. A private table with 2049 slots supports addresses through
0x2000; unused slots point to the selected signed exit. No full Wii U RAM, game
scheduler, recompiler worker or production session is initialized.

For each of 32 states and both signed exits, the checker performs three checks:

1. A calls B, B returns to A's continuation and A returns to the host.
2. B is withdrawn from the private table. A stops at B's address with guest LR
   pointing at the continuation, after three instructions and without writing RAM.
3. B is republished and execution resumes at B. It returns through A's continuation
   and reaches the same complete CPU/RAM result as the first check.

This totals 192 checks over 64 initial states: full execution, missing destination
and resumed execution. Checks include guest GPR/FPR/SPR values, CR/XER flags,
big-endian RAM, instruction pointer, LR and cycle counts (1000 to 997 to 990).
The withdrawal is a controlled private-table operation. It does not exercise
Cemu's global invalidation machinery or execute an interpreter fallback.

Native preflight uses the actual PowerPC words with an independent PPC32 ISA
emulator, checking 32 states and the exact ten-instruction call/return path. It
also compiles the actual new C++ image/check API and checks capacity/offset layout
with explicitly small test CPU/body substitutes. These do not compile or execute
the real production frontend; the full iOS build and physical test are required.
The actual boundary tracker is separately checked with both new PPC programs and
rejects any attempt to read global RAM.

Button: **Probar despacho entre funciones PowerPC**. Diagnostic: `SF-DISPATCH`,
or `SF-LOAD` if a signed image cannot load. The certificate remains transient in
memory; no new entitlement, signing code, key persistence, network operation or
debugger attach is introduced. This still does not boot a title, measure game
performance, implement production module/session ownership or renew installation.
