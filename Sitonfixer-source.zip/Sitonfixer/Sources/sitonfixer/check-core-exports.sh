#!/bin/bash
# Sitonfixer. SPDX-License-Identifier: GPL-3.0-only
set -euo pipefail
dump="${1:?Expected the completed nm -gU output file}"
names="$(mktemp "${TMPDIR:-/tmp}/sitonfixer-exports.XXXXXX")"
trap 'rm -f "$names"' EXIT
awk '{print $NF}' "$dump" > "$names"
for symbol in sitonfixer_backend_probe_prepare sitonfixer_backend_probe_check sitonfixer_frontend_probe_prepare sitonfixer_frontend_probe_check sitonfixer_interface_probe_prepare sitonfixer_interface_probe_check; do
  # Consume the entire file. grep -q in a pipe would close awk's stdout early,
  # making pipefail report a false missing symbol on a large Cemu symbol table.
  if ! grep -Fx "_$symbol" "$names" > /dev/null; then
    echo "::error::Missing $symbol; build with SITONFIXER_BUILD_CORE_FROM_SOURCE=1" >&2
    exit 1
  fi
done
echo 'All signed Cemu backend/frontend probe functions are defined and externally visible.'
