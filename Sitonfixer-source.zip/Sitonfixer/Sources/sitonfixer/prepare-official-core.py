"""Reuse only the unchanged Cemu framework from the pinned official build.

No games, pairing records, user data or modified emulator core are downloaded.
The optional source-core build remains available in build-macos.sh.
"""
import hashlib
import json
import urllib.request
import zipfile
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
URL = 'https://github.com/MuffinEMU/Muffin-EMU/releases/download/v11.2/MuffinEMU.ipa'
EXPECTED = '76d7f670b67f053bc021781255cdde8d388feebc94de9d61362743bf8ad945bf'
SIZE = 154431845
cache = ROOT/'.sitonfixer-downloads'
cache.mkdir(exist_ok=True)
archive = cache/'MuffinEMU-v11.2.ipa'
def digest(path):
    with path.open('rb') as stream:
        value = hashlib.sha256()
        for block in iter(lambda: stream.read(1024**2), b''): value.update(block)
        return value.hexdigest()
if not archive.exists():
    partial = archive.with_suffix('.partial')
    request = urllib.request.Request(URL, headers={'User-Agent': 'Sitonfixer-source-build'})
    count = 0
    with urllib.request.urlopen(request, timeout=60) as response, partial.open('wb') as stream:
        if not response.url.startswith('https://'): raise RuntimeError('Non-HTTPS download rejected')
        for block in iter(lambda: response.read(1024**2), b''):
            count += len(block)
            if count > SIZE: raise RuntimeError('Official asset exceeds expected size')
            stream.write(block)
    if partial.stat().st_size != SIZE or digest(partial) != EXPECTED:
        raise RuntimeError('Official release integrity check failed')
    partial.rename(archive)
if archive.stat().st_size != SIZE or digest(archive) != EXPECTED:
    raise RuntimeError('Cached release integrity check failed')
destination = ROOT/'build-ios/out/Cemu.framework'
if destination.exists(): raise RuntimeError('Existing core preserved; use a fresh build folder')
prefix = 'Payload/MuffinEMU.app/Frameworks/Cemu.framework/'
files = 0
with zipfile.ZipFile(archive) as zipped:
    for entry in zipped.infolist():
        if not entry.filename.startswith(prefix) or entry.is_dir(): continue
        relative = PurePosixPath(entry.filename[len(prefix):])
        if relative.is_absolute() or '..' in relative.parts:
            raise RuntimeError('Unsafe path in release asset')
        if ((entry.external_attr >> 16) & 0o170000) == 0o120000:
            raise RuntimeError('Symlinks in core framework are not supported')
        target = destination.joinpath(*relative.parts)
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(zipped.read(entry))
        files += 1
if not (destination/'Cemu').is_file(): raise RuntimeError('Core executable missing')
(destination/'Cemu').chmod(0o755)
(ROOT/'build-ios/out/Sitonfixer-core-receipt.json').write_text(json.dumps({
    'source': URL, 'release_sha256': EXPECTED, 'core_sha256': digest(destination/'Cemu'),
    'mode': 'official unchanged core reused; not rebuilt', 'files': files}, indent=2), encoding='utf-8')
print('Official unchanged Cemu.framework extracted and SHA-256 verified.')
