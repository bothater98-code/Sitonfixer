// Compile-time interfaces only. Not included in the application target.
import Foundation

@MainActor final class JITCoordinator {
    static let shared = JITCoordinator()
    func enableJIT() async throws -> String { "compile-time stub" }
}
enum JITStatus { static var isActive: Bool { false } }
enum JITPairing {
    static var isImported: Bool { false }
    static func store(_ data: Data) throws {}
}

@MainActor final class JITPillModel {
    static let shared = JITPillModel()
    func refresh() {}
}
