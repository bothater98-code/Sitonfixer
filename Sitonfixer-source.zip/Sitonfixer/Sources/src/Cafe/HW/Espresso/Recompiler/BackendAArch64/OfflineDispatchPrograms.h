// Sitonfixer. SPDX-License-Identifier: MPL-2.0
#pragma once
#include <array>
#include <cstdint>

namespace OfflineDispatchPrograms {
constexpr uint32_t callerAddress = 0x1000;
constexpr uint32_t continuationAddress = 0x100c;
constexpr uint32_t calleeAddress = 0x2000;
// mflr r10; add r6,r3,r4; bl 0x2000; mtlr r10; addi r9,r8,3; blr
constexpr std::array<uint32_t, 6> caller{
    0x7d4802a6, 0x7cc32214, 0x48000ff9, 0x7d4803a6, 0x39280003, 0x4e800020};
// stw r6,16(r5); lwz r7,16(r5); addi r8,r7,5; blr
constexpr std::array<uint32_t, 4> callee{
    0x90c50010, 0x80e50010, 0x39070005, 0x4e800020};
}
