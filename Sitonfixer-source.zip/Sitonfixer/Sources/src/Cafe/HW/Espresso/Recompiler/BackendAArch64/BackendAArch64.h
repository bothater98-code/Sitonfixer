#pragma once

#include <cstddef>
#include <cstdint>
#include <utility>
#include <vector>

#include "HW/Espresso/Recompiler/IML/IMLInstruction.h"
#include "../PPCRecompiler.h"

// Inert, process-local code bytes; never pass bytes.data() to executable-code cleanup.
// Absolute helper addresses make this unsuitable for a persistent cross-process cache.
// Entries map guest addresses to byte offsets, not executable pointers.
struct AArch64CodeBytes
{
    std::vector<uint8_t> bytes;
    std::vector<std::pair<uint32_t, size_t>> entries;
};

// Requires exclusive ownership of an optimized, register-allocated context.
// Mutates segment emission offsets, including on failure; output is empty on failure.
// Does not initialize the recompiler, publish code, or enable signed game execution.
bool PPCRecompiler_emitAArch64Bytes(ppcImlGenContext_t& context,
    AArch64CodeBytes& output, size_t maximumBytes);

bool PPCRecompiler_generateAArch64Code(struct PPCRecFunction_t* PPCRecFunction, struct ppcImlGenContext_t* ppcImlGenContext);
void PPCRecompiler_cleanupAArch64Code(void* code, size_t size);

void PPCRecompilerAArch64Gen_generateRecompilerInterfaceFunctions();

// architecture specific constants
namespace IMLArchAArch64
{
	static constexpr int PHYSREG_GPR_BASE = 0;
	static constexpr int PHYSREG_GPR_COUNT = 25;
	static constexpr int PHYSREG_FPR_BASE = PHYSREG_GPR_COUNT;
	static constexpr int PHYSREG_FPR_COUNT = 31;
}; // namespace IMLArchAArch64
