// Sitonfixer. SPDX-License-Identifier: MPL-2.0
#pragma once
#include <cstddef>
#include <cstdint>
#include <limits>
#include <stdexcept>

// Non-owning, aligned big-endian instruction words. No guest/global memory access.
class PPCInstructionWindow
{
    uint32_t m_base;
    const uint32_t* m_words;
    size_t m_count;
public:
    PPCInstructionWindow(uint32_t base, const uint32_t* words, size_t count)
        : m_base(base), m_words(words), m_count(count)
    {
        if (!words || !count || (base & 3) ||
            (reinterpret_cast<uintptr_t>(words) & 3) ||
            count > (uint64_t(std::numeric_limits<uint32_t>::max()) - base) / 4)
            throw std::invalid_argument("Invalid instruction window");
    }
    uint32_t end() const { return m_base + uint32_t(m_count * 4); }
    const uint32_t* pointer(uint32_t address) const
    {
        if ((address & 3) || address < m_base || address >= end())
            throw std::out_of_range("Instruction outside private window");
        return m_words + (address - m_base) / 4;
    }
    uint32_t read(uint32_t address) const
    {
        const auto* b = reinterpret_cast<const uint8_t*>(pointer(address));
        return uint32_t(b[0]) << 24 | uint32_t(b[1]) << 16 | uint32_t(b[2]) << 8 | b[3];
    }
};
