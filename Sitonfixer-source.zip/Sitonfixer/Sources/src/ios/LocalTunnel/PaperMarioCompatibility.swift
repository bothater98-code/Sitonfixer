// Independently generated ISO language table; no firmware or game assets included.
// SPDX-License-Identifier: GPL-3.0-only
import Foundation

enum PaperMarioCompatibility {
    static func preserveOrCreateTable() throws {
        let documents = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
        let path = documents.appendingPathComponent("mlc/mlc01/sys/title/0005001b/1005c000/content/language.txt")
        guard !FileManager.default.fileExists(atPath: path.path) else { return }
        let languages = ["ja", "en", "fr", "de", "it", "es", "zh", "ko", "nl", "pt", "ru", "zh", "", "", "", ""]
        let text = languages.map { "\"\($0)\"," }.joined(separator: "\n") + "\n"
        try FileManager.default.createDirectory(at: path.deletingLastPathComponent(), withIntermediateDirectories: true)
        try Data(text.utf8).write(to: path, options: .withoutOverwriting)
    }
}
