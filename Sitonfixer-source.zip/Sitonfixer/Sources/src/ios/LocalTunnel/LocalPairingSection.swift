// Sitonfixer experimental adaptation. SPDX-License-Identifier: GPL-3.0-only
import SwiftUI
import UniformTypeIdentifiers

struct LocalPairingSection: View {
    @State private var importing = false
    @State private var imported = JITPairing.isImported
    @State private var note: String?
    var body: some View {
        Section("Configuración inicial") {
            Text(imported ? "Emparejamiento importado" : "Falta importar el emparejamiento de este iPhone")
            Button("Importar emparejamiento desde Archivos") { importing = true }
            Text("Se guarda únicamente dentro de esta app. No se envía a ningún servidor.")
                .font(.footnote)
            if let note { Text(note).font(.footnote) }
        }
        .fileImporter(isPresented: $importing, allowedContentTypes: [.data]) { result in
            do {
                let url = try result.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let handle = try FileHandle(forReadingFrom: url)
                defer { try? handle.close() }
                let data = try handle.read(upToCount: 1_048_577) ?? Data()
                guard !data.isEmpty, data.count <= 1_048_576 else {
                    note = "El archivo no tiene un tamaño válido. No se ha sustituido el emparejamiento."
                    return
                }
                _ = try PropertyListSerialization.propertyList(from: data, options: [], format: nil)
                try JITPairing.store(data)
                imported = true
                note = "Archivo importado. Su validez se comprobará al preparar el juego."
            } catch {
                note = "No se pudo importar el archivo. Se conserva el emparejamiento anterior."
            }
        }
    }
}
