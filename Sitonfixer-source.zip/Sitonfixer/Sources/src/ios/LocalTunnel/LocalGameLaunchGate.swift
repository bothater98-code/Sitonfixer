// Sitonfixer: experimental adaptation based on MuffinEMU by Void.
// SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// The helper must attach BEFORE core initialization, but TXM memory preparation
/// happens DURING that initialization. Waiting for helper completion before starting
/// the core would deadlock. CS_DEBUGGED is only an attach signal, not JIT readiness.
@MainActor
final class LocalGameLaunchGate {
    static let shared = LocalGameLaunchGate()
    private var operation: Task<String, Error>?
    private var failure: Error?
    private(set) var protocolCompleted = false

    func beginCoreInitializationWhenAttached() async throws {
        if protocolCompleted { return }
        if operation == nil {
            failure = nil
            operation = Task { @MainActor in
                do {
                    let message = try await JITCoordinator.shared.enableJIT()
                    guard JITStatus.isActive else { throw GateFailure.noDebugFlag }
                    protocolCompleted = true
                    return message
                } catch {
                    failure = error
                    throw error
                }
            }
        }
        for _ in 0..<160 {
            if let failure { throw failure }
            if JITStatus.isActive { return } // Now the core can issue its region-preparation breakpoints.
            try await Task.sleep(nanoseconds: 250_000_000)
        }
        // The helper may already be attached to this process. Do not try an unsafe
        // fallback or a second attach; ask for a clean process restart after timeout.
        throw GateFailure.timeout
    }

    func waitForProtocolCompletion() async throws {
        guard let operation else { throw GateFailure.noOperation }
        _ = try await operation.value
        guard protocolCompleted else { throw GateFailure.noDebugFlag }
    }

    enum GateFailure: LocalizedError {
        case timeout, noDebugFlag, noOperation
        var errorDescription: String? {
            switch self {
            case .timeout: return "La depuración local no está lista. Cierra y vuelve a abrir Sitonfixer antes de reintentar."
            case .noDebugFlag: return "El auxiliar terminó sin confirmar el estado de depuración del proceso."
            case .noOperation: return "No existe una preparación JIT para esta ejecución."
            }
        }
    }
}
