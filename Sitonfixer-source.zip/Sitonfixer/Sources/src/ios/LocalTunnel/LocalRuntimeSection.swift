// Sitonfixer experimental adaptation. SPDX-License-Identifier: GPL-3.0-only
import SwiftUI

struct LocalRuntimeSection: View {
    @AppStorage("sitonfixer.allowOnlinePreparation") private var allowOnlinePreparation = false

    var body: some View {
        Section("Sitonfixer") {
            Text("JIT integrado; acceso mediante el túnel local instalado")
            Text("Al elegir un juego, Sitonfixer comprueba el servicio local y prepara JIT con su propio auxiliar. No necesita abrir StikDebug ni conectar un PC. Si el túnel local no responde, se detiene e informa del fallo.")
                .font(.footnote)
            Toggle("Permitir preparación inicial por Internet", isOn: $allowOnlinePreparation)
            Text("Desactivado: si falta la DDI, se mostrará el motivo sin descargarla ni pedir su personalización a Apple.")
                .font(.footnote)
            Text("Based on MuffinEMU by Void: https://github.com/MuffinEMU/Muffin-EMU")
                .font(.footnote)
            Text("Adaptación experimental Sitonfixer. No es una versión oficial de MuffinEMU.")
                .font(.footnote)
        }
    }
}
