//
//  CemuBridge.mm
//  MuffinEMU's Swift <-> engine bridge, running on the Cemu core.
//
//  Swift talks to the engine only through the C functions in CemuBridge.h. This file
//  implements them against the core and nothing else:
//    * src/main.cpp            - CemuInitialize / CemuRun / CemuShutdown
//    * src/gui/uikit/          - CemuUIKit_* (surfaces, window geometry, visible outputs)
//    * src/input/api/iOS/      - GCControllerBridge_* (controllers)
//    * Core/*.cpp next to this - title launch, decrypt, DLC/update import, graphic packs,
//                                pause - built only from functions the core already exports
//
//  It is compiled into Cemu.framework by CMake (see src/CMakeLists.txt), so it sees the
//  core's headers and precompiled header directly. The Xcode app only ever sees
//  CemuBridge.h, which is plain C.
//
#include "Common/precompiled.h"
#include "audio/IAudioAPI.h"
#include "audio/iOSAudioRecorder.h"
#include "IOSScreenRecorder.h"
#include <cxxabi.h>
#include <typeinfo>
#import "CemuBridge.h"
#import "IOSLiveLog.h"
#import "IOSMotion.h"
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <GameController/GameController.h>
#import <Metal/Metal.h>
#import <QuartzCore/CAMetalLayer.h>

#include <sys/sysctl.h>
#include <sys/proc.h>
#include <string>
#include <cstring>
#include <atomic>
#include <algorithm>
#include <thread>
#include <chrono>
#include <mutex>
#include <functional>
#include <cstdarg>
#include <signal.h>
#include <execinfo.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <exception>
#include <typeinfo>
#include <filesystem>
#include <set>
#include <mach/mach.h>
#include <os/proc.h>
#include <dlfcn.h>
#include <pthread.h>
#include <sys/ucontext.h>

#include "Cafe/CafeSystem.h"
#include "Cafe/HW/MMU/MMU.h"
#include "Cafe/HW/Espresso/PPCState.h"
#include "Common/SysAllocator.h"
#include "Cafe/OS/libs/coreinit/coreinit_Alarm.h"
#include "Cafe/OS/libs/nn_ac/nn_ac_reachability.h"
#include "Cafe/Filesystem/FST/KeyCache.h"
#include "Cafe/Filesystem/fsc.h"
#include "Cafe/HW/Latte/Core/Latte.h"
#include "Cafe/HW/Latte/Core/LatteTextureASTCCache.h"
#include "Cafe/HW/Latte/Core/LatteOverlay.h"
#include "Cafe/HW/Latte/Core/LatteShader.h"
#include "Cafe/HW/Latte/Core/LatteShaderCache.h"
#include "Cemu/FileCache/FileCache.h"
#include "Cafe/HW/Latte/Core/LatteWaitInfo.h"
#include "StallDetector.h"
#include "Cafe/HW/Latte/Core/PerfTelemetry.h"
#include "Cafe/GameProfile/GameProfile.h"
#include "util/Fiber/Fiber.h"
#include "Cafe/HW/Latte/Renderer/Renderer.h"
#include "Cemu/Logging/CemuLogging.h"
#include "config/ActiveSettings.h"
#include "config/CemuConfig.h"
#include "Common/version.h"
#include "Common/DeviceCapabilities.h"
#include "CemuDeviceCaps.h"
#include "gui/interface/WindowSystem.h"
#include "input/api/iOS/GCControllerProvider.h"
#include "input/emulated/EmulatedController.h"
#include "input/emulated/VPADController.h"
#include "input/InputManager.h"
#include "util/crypto/aes128.h"

// Library scans open encrypted game folders (title.tmd + title.tik + .app files) before
// the engine starts, and the AES routines are null until AES128_init() runs. Initialise
// them as soon as the framework loads; AES128_init() is safe to call again from
// CemuInitialize().
__attribute__((constructor)) static void ios_crypto_init_at_load() { AES128_init(); }

// Forward-declared here because coreinit_Thread.h pulls the whole scheduler surface into
// this ARC-compiled translation unit. Must stay OUTSIDE the extern "C" block: a namespace
// nested inside extern "C" keeps C linkage, so the reference would not match the mangled
// C++ definition and the framework would fail to link.
namespace coreinit { void OSSetThermalThrottleMicros(uint32 micros); }

// The core's C entry points. Defined inside extern "C" blocks in src/main.cpp and
// src/gui/uikit/WindowSystem.mm, and not declared in any header this
// bridge includes, so they are declared again here.
extern "C" {
bool CemuTakeRendererFallback(char* reasonOut, size_t capacity);
bool CemuIsInitialized();
void CemuInitialize(const char* execPath, const char* user_data_path, const char* config_path, const char* cache_path, const char* data_path);
void CemuRun(void);
void CemuPrepareRenderer(void);
void CemuShutdown(void);
void CemuUIKit_SetMainWindow(UIWindow* window);
void CemuUIKit_SetMainView(UIView* view);
void CemuUIKit_SetPadView(UIView* view);
void CemuUIKit_InitializeLayer(bool main);
void CemuUIKit_UpdateMainWindowSize(CGFloat width, CGFloat height, CGFloat scale);

void CemuUIKit_UpdatePadWindowSize(void);
void CemuUIKit_SetVisibleOutputs(bool tv, bool pad);
void CemuUIKit_SetOutputSources(bool mainShowsGamePad, bool padShowsTV);
void CemuUIKit_DescribeMainSurface(char* out, size_t outSize);
void CemuUIKit_SetPadTouch(CGFloat x, CGFloat y, bool down);
void* GCControllerBridge_add(const GCBridgeControllerDesc* desc);
void GCControllerBridge_remove(void* handle);
void GCControllerBridge_notifyChanged(void);
int csops(pid_t pid, unsigned int ops, void* useraddr, size_t usersize);
}

// Muffin's glue, in Core/. Plain C++ linkage: only this file calls them.
int IOSTitleLaunch_PrepareForegroundTitle(const char* path);
const char* IOSTitleLaunch_LastErrorDetail();
int IOSTitleLaunch_ReloadAndCountKeys();
int IOSTitleLaunch_PrepareForegroundTitleById(uint64_t titleId);
int IOSTitleDecrypt_ExtractToFolder(const char* srcPath, const char* destFolderPath,
    std::atomic_bool& cancelRequested,
    const std::function<void(uint64_t bytesWritten, uint32_t filesWritten)>& progressCallback);
int IOSTitleDecrypt_ExtractToWua(const char* srcPath, const char* destPath,
    std::atomic_bool& cancelRequested,
    const std::function<void(uint64_t bytesWritten, uint32_t filesWritten)>& progressCallback);
int IOSWuaContent_Build(const std::vector<std::string>& srcs, const char* destPath,
    std::atomic_bool& cancelRequested,
    const std::function<void(uint64_t bytesWritten, uint32_t filesWritten)>& progressCallback);
std::string IOSWuaContent_ListTitles(const char* wuaPath);
std::string IOSCoverArt_DeriveGameTdbId(const char* romPath);
std::string IOSCoverArt_GetTitleName(const char* romPath);
bool IOSDlcUpdateImport_DeriveTitleId(const char* romPath, uint64_t* titleIdOut);
bool IOSDlcUpdateImport_ReadTmdTitleId(const char* tmdPath, uint64_t* titleIdOut);
uint64_t IOSDlcUpdateImport_DeriveBaseTitleId(uint64_t titleId);
int IOSDlcUpdateImport_GetTitleType(uint64_t titleId);
void IOSDlcUpdateImport_GetMlcTitlePathComponents(uint64_t titleId, char* outUpperHex, char* outLowerHex);
bool IOSDlcUpdateImport_Inspect(const char* romPath, uint64_t* outTitleId, uint16_t* outVersion,
    int* outRegion, int* outInvalidReason);
uint64_t IOSDlcUpdateImport_DeriveContentTitleId(uint64_t baseTitleId, bool isUpdate);
int IOSEmulatedDevices_SlotCount(int device);
std::string IOSEmulatedDevices_SlotNames(int device);
std::string IOSEmulatedDevices_FigureList(int device, int slot);
std::string IOSEmulatedDevices_Load(int device, int slot, const char* path);
std::string IOSEmulatedDevices_Clear(int device, int slot);
std::string IOSEmulatedDevices_Create(int device, uint32_t figureId, uint16_t variant, const char* path);
std::string IOSEmulatedDevices_MoveDimensions(int fromSlot, int toSlot);
bool nnNfp_isInitialized();
bool nnNfp_touchNfcTagFromFile(const fs::path& filePath, uint32* nfcError);
std::string IOSGraphicPacks_List();
void IOSGraphicPacks_Refresh();
void IOSGraphicPacks_SetEnabled(int index, bool enabled);
void IOSAccounts_Refresh();
std::string IOSAccounts_List();
bool IOSAccounts_HasFreeSlot();
uint32_t IOSAccounts_NextPersistentId();
uint32_t IOSAccounts_MinPersistentId();
bool IOSAccounts_Locked();
bool IOSAccounts_Create(uint32_t persistentId, const char* miiName, uint16_t birthYear,
    uint8_t birthMonth, uint8_t birthDay, int gender, const char* email, int country);
bool IOSAccounts_Delete(uint32_t persistentId);
bool IOSAccounts_SetMiiName(uint32_t persistentId, const char* miiName);
bool IOSAccounts_SetGender(uint32_t persistentId, int gender);
bool IOSAccounts_SetEmail(uint32_t persistentId, const char* email);
bool IOSAccounts_SetCountry(uint32_t persistentId, int country);
bool IOSAccounts_SetBirthdate(uint32_t persistentId, uint16_t year, uint8_t month, uint8_t day);
uint32_t IOSAccounts_ActivePersistentId();
void IOSAccounts_SetActivePersistentId(uint32_t persistentId);
bool IOSAccounts_IsOnlineValid(uint32_t persistentId);
int IOSAccounts_OnlineError(uint32_t persistentId);
std::string IOSAccounts_OnlineHint();
std::string IOSAccounts_CountriesList();
int IOSAccounts_NetworkService(uint32_t persistentId);
void IOSAccounts_SetNetworkService(uint32_t persistentId, int service);
bool IOSAccounts_CustomNetworkServiceAvailable();
bool IOSAccounts_ReloadCustomNetworkService();
bool IOSAccounts_IsValidNetworkServicesXML(const char* path);
bool IOSTitlePause_Pause();
bool IOSTitlePause_Resume();
bool IOSTitlePause_IsPaused();
void IOSTitlePause_Forget();
bool IOSSaveState_Save(const char* path);
bool IOSSaveState_Load(const char* path);
void IOSSaveState_BeginSession();
int IOSSaveState_LastErrorCode();
const char* IOSSaveState_LastErrorMessage();
int IOSSaveState_InspectFile(const char* path);
void IOSSystemImplementation_Install();
bool IOSSystemImplementation_TitleExited(int* statusOut);
bool IOSSystemImplementation_TitleSwitchFailed();
bool IOSSystemImplementation_SystemAppletRequested();
void IOSSystemImplementation_ReportFatal(const char* reason);
const char* IOSSystemImplementation_FatalReason();
void IOSSystemImplementation_ResetExit();

// ---------------------------------------------------------------------------
// Crash trail
//
// A GPU driver panic or a jetsam kill is not delivered as a catchable signal, so the
// checkpoint trail below is what survives one: every line is a synchronous write() to
// Documents/CemuCrashLog.txt that is on disk before the next line of code runs. The
// signal and terminate handlers are installed from a constructor(101) so a crash in any
// engine static initializer, before main(), is still caught.
namespace {
    int g_crashLogFd = -1;
    char g_crashLogPath[1024] = {0};

    void cemu_crash_write(const char* s) {
        if (g_crashLogFd >= 0 && s) write(g_crashLogFd, s, strlen(s));
    }

    void crash_hex(uint64_t v) {
        char buf[18];
        buf[0] = '0'; buf[1] = 'x';
        for (int i = 0; i < 16; i++) {
            const int nibble = (int)((v >> ((15 - i) * 4)) & 0xF);
            buf[2 + i] = (char)(nibble < 10 ? '0' + nibble : 'a' + nibble - 10);
        }
        if (g_crashLogFd >= 0) write(g_crashLogFd, buf, sizeof(buf));
    }

    void crash_dec(int64_t v) {
        char digits[24];
        int i = 0;
        const bool negative = v < 0;
        uint64_t n = negative ? (uint64_t)(-v) : (uint64_t)v;
        if (n == 0) digits[i++] = '0';
        while (n > 0) { digits[i++] = (char)('0' + (n % 10)); n /= 10; }
        if (negative) digits[i++] = '-';
        char out[24];
        for (int j = 0; j < i; j++) out[j] = digits[i - 1 - j];
        if (g_crashLogFd >= 0) write(g_crashLogFd, out, (size_t)i);
    }

    const char* crash_vm_tag_name(unsigned tag) {
        switch (tag) {
            case 0: return "untagged (direct vm_allocate)";
            case 1: return "malloc";
            case 2: return "malloc small";
            case 3: return "malloc large";
            case 4: return "malloc huge";
            case 6: return "realloc";
            case 7: return "malloc tiny";
            case 11: return "malloc nano";
            case 21: return "IOKit";
            case 30: return "stack";
            case 31: return "guard";
            case 33: return "dylib";
            case 88: return "IOSurface";
            default: return "other";
        }
    }

    // Where the address space goes and where it is free. Written for the allocation-failure reports: a 32 MB
    // MTLBuffer and operator new failing while os_proc_available_memory() still shows gigabytes means the limit
    // being hit is not physical memory, and this names which one (a full map, a map of holes too small to use,
    // or one region type holding most of it). Stack memory and write() only, so it is safe with malloc failing.
    void cemu_vm_report(const char* why, uint64_t wantedBytes) {
        struct Top { uint64_t size; uint64_t addr; unsigned tag; };
        Top top[5] = {};
        uint64_t tagBytes[256] = {};
        uint64_t regions = 0, mapped = 0, gapTotal = 0, gapMax = 0, gapMaxAt = 0, gaps1M = 0, gaps32M = 0, highestEnd = 0, prevEnd = 0;
        vm_address_t addr = 0;
        natural_t depth = 0;
        for (int guard = 0; guard < 200000; guard++) {
            vm_size_t size = 0;
            vm_region_submap_info_data_64_t info;
            mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
            if (vm_region_recurse_64(mach_task_self(), &addr, &size, &depth, (vm_region_recurse_info_t)&info, &count) != KERN_SUCCESS)
                break;
            if (info.is_submap) {
                depth++;
                continue;
            }
            regions++;
            mapped += size;
            if (prevEnd != 0 && addr > prevEnd) {
                const uint64_t gap = (uint64_t)addr - prevEnd;
                gapTotal += gap;
                if (gap >= (1ull << 20)) gaps1M++;
                if (gap >= (32ull << 20)) gaps32M++;
                if (gap > gapMax) { gapMax = gap; gapMaxAt = prevEnd; }
            }
            prevEnd = (uint64_t)addr + size;
            highestEnd = prevEnd;
            const unsigned tag = info.user_tag & 0xFF;
            tagBytes[tag] += size;
            for (int i = 0; i < 5; i++) {
                if (size > top[i].size) {
                    for (int j = 4; j > i; j--) top[j] = top[j - 1];
                    top[i] = { (uint64_t)size, (uint64_t)addr, tag };
                    break;
                }
            }
            addr += size;
        }
        cemu_crash_write("\nADDRESS SPACE at "); cemu_crash_write(why ? why : "?");
        cemu_crash_write(" (wanted "); crash_dec((int64_t)(wantedBytes >> 10)); cemu_crash_write(" KB): ");
        crash_dec((int64_t)regions); cemu_crash_write(" regions, ");
        crash_dec((int64_t)(mapped >> 20)); cemu_crash_write(" MB mapped, highest end "); crash_hex(highestEnd);
        cemu_crash_write(", free holes below it ");  crash_dec((int64_t)(gapTotal >> 20)); cemu_crash_write(" MB in total, ");
        crash_dec((int64_t)gaps1M); cemu_crash_write(" holes of 1 MB or more, "); crash_dec((int64_t)gaps32M);
        cemu_crash_write(" of 32 MB or more, largest "); crash_dec((int64_t)(gapMax >> 20)); cemu_crash_write(" MB at "); crash_hex(gapMaxAt);
        cemu_crash_write("\n");
        for (int i = 0; i < 5 && top[i].size; i++) {
            cemu_crash_write("  region "); crash_hex(top[i].addr); cemu_crash_write(" "); crash_dec((int64_t)(top[i].size >> 20));
            cemu_crash_write(" MB tag "); crash_dec((int64_t)top[i].tag); cemu_crash_write(" "); cemu_crash_write(crash_vm_tag_name(top[i].tag)); cemu_crash_write("\n");
        }
        for (int round = 0; round < 4; round++) {
            unsigned best = 0; uint64_t bestBytes = 0;
            for (unsigned t = 0; t < 256; t++) if (tagBytes[t] > bestBytes) { bestBytes = tagBytes[t]; best = t; }
            if (!bestBytes) break;
            cemu_crash_write("  by type: tag "); crash_dec((int64_t)best); cemu_crash_write(" "); cemu_crash_write(crash_vm_tag_name(best));
            cemu_crash_write(" "); crash_dec((int64_t)(bestBytes >> 20)); cemu_crash_write(" MB\n");
            tagBytes[best] = 0;
        }
        task_vm_info_data_t vi{};
        mach_msg_type_number_t viCount = TASK_VM_INFO_COUNT;
        if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&vi, &viCount) == KERN_SUCCESS) {
            cemu_crash_write("  footprint "); crash_dec((int64_t)(vi.phys_footprint >> 20)); cemu_crash_write(" MB, resident "); crash_dec((int64_t)(vi.resident_size >> 20));
            cemu_crash_write(" MB, internal "); crash_dec((int64_t)(vi.internal >> 20)); cemu_crash_write(" MB, compressed "); crash_dec((int64_t)(vi.compressed >> 20));
            cemu_crash_write(" MB, virtual "); crash_dec((int64_t)(vi.virtual_size >> 20)); cemu_crash_write(" MB, os_proc_available_memory "); 
            crash_dec((int64_t)(os_proc_available_memory() >> 20)); cemu_crash_write(" MB\n");
        }
    }

    // "0x... Image +offset symbol +offset". The raw address always goes out first: dladdr takes dyld's lock,
    // and a crash inside dyld would otherwise leave the line empty.
    void crash_describe_address(uint64_t addr) {
        crash_hex(addr);
        Dl_info di;
        if (addr && dladdr((const void*)addr, &di) && di.dli_fname) {
            const char* base = strrchr(di.dli_fname, '/');
            base = base ? base + 1 : di.dli_fname;
            cemu_crash_write(" ");
            cemu_crash_write(base);
            cemu_crash_write(" +");
            crash_dec((int64_t)(addr - (uint64_t)di.dli_fbase));
            if (di.dli_sname) {
                cemu_crash_write(" ");
                cemu_crash_write(di.dli_sname);
                cemu_crash_write(" +");
                crash_dec((int64_t)(addr - (uint64_t)di.dli_saddr));
            }
        }
    }

    // vm_read_overwrite instead of a pointer dereference: a bad frame pointer must not fault inside the handler.
    bool crash_read(uint64_t addr, void* out, size_t n) {
        vm_size_t got = 0;
        return vm_read_overwrite(mach_task_self(), (vm_address_t)addr, (vm_size_t)n, (vm_address_t)out, &got) == KERN_SUCCESS && got == n;
    }

    // A thread's own frames from its registers, walking the frame-pointer chain.
    void crash_frames(uint64_t pc, uint64_t lr, uint64_t fp, uint64_t sp, int maxFrames) {
        constexpr uint64_t kAddressMask = 0x00007FFFFFFFFFFFull;
        cemu_crash_write("    #0 pc "); crash_describe_address(pc & kAddressMask); cemu_crash_write("\n");
        if (lr) { cemu_crash_write("    #1 lr "); crash_describe_address(lr & kAddressMask); cemu_crash_write("\n"); }
        uint64_t previous = sp;
        for (int i = 0; i < maxFrames && fp != 0 && (fp & 0xF) == 0 && fp >= previous; i++) {
            uint64_t record[2];
            if (!crash_read(fp, record, sizeof(record)))
                break;
            cemu_crash_write("    #"); crash_dec(i + 2); cemu_crash_write(" "); crash_describe_address(record[1] & kAddressMask); cemu_crash_write("\n");
            if (record[0] <= fp)
                break;
            previous = fp;
            fp = record[0];
        }
    }

    void crash_thread_name(pthread_t thread, char* out, size_t cap) {
        out[0] = '\0';
        if (thread)
            pthread_getname_np(thread, out, cap);
        if (out[0] == '\0')
            snprintf(out, cap, "(unnamed)");
    }

    // Every other thread's pc, so a trap on one thread is found even when the signal was delivered to another.
    // A brk instruction at a thread's pc is marked. The threads are left suspended: the process is about to die.
    void crash_dump_other_threads() {
#if defined(__arm64__)
        thread_act_array_t threads = nullptr;
        mach_msg_type_number_t count = 0;
        if (task_threads(mach_task_self(), &threads, &count) != KERN_SUCCESS)
            return;
        const mach_port_t self = mach_thread_self();
        cemu_crash_write("--- other threads ("); crash_dec((int64_t)count - 1); cemu_crash_write(") ---\n");
        for (mach_msg_type_number_t i = 0; i < count && i < 96; i++) {
            const thread_act_t t = threads[i];
            if (t == self)
                continue;
            thread_suspend(t);
            arm_thread_state64_t state;
            mach_msg_type_number_t stateCount = ARM_THREAD_STATE64_COUNT;
            if (thread_get_state(t, ARM_THREAD_STATE64, (thread_state_t)&state, &stateCount) != KERN_SUCCESS)
                continue;
            char name[64];
            crash_thread_name(pthread_from_mach_thread_np(t), name, sizeof(name));
            const uint64_t pc = __darwin_arm_thread_state64_get_pc(state);
            uint32_t insn = 0;
            const bool isBrk = crash_read(pc, &insn, sizeof(insn)) && (insn & 0xFFE0001Fu) == 0xD4200000u;
            cemu_crash_write("  thread '"); cemu_crash_write(name); cemu_crash_write("'");
            if (isBrk) { cemu_crash_write(" STOPPED AT brk #"); crash_dec((int64_t)((insn >> 5) & 0xFFFF)); }
            cemu_crash_write("\n");
            crash_frames(pc, __darwin_arm_thread_state64_get_lr(state), __darwin_arm_thread_state64_get_fp(state),
                         __darwin_arm_thread_state64_get_sp(state), isBrk ? 16 : 6);
        }
#endif
    }

    std::atomic<bool> g_crashInProgress{false};

    // Runs on the thread that received the signal. Not strictly async-signal-safe (dladdr, Mach calls), which is
    // the trade for naming the faulting thread and its own frames; alarm() below ends the process if anything hangs.
    void cemu_crash_signal_handler(int signum, siginfo_t* info, void* context) {
        if (g_crashInProgress.exchange(true)) {
            // Another thread is already writing the report (or this one faulted inside it): wait for the alarm
            for (;;) sleep(1);
        }
        alarm(5);
        cemu_crash_write("\n=== CEMU CRASH: signal ");
        crash_dec(signum);
        cemu_crash_write(" ===\n");

        pthread_t self = pthread_self();
        char name[64];
        crash_thread_name(self, name, sizeof(name));
        uint64_t tid = 0;
        pthread_threadid_np(nullptr, &tid);
        cemu_crash_write("received on thread '"); cemu_crash_write(name);
        cemu_crash_write("' tid "); crash_dec((int64_t)tid);
        cemu_crash_write(pthread_main_np() ? " (the main thread)\n" : " (not the main thread)\n");
        if (info) {
            cemu_crash_write("si_code "); crash_dec(info->si_code);
            cemu_crash_write(" si_addr "); crash_hex((uint64_t)info->si_addr);
            // si_pid is set when another process or thread sent the signal with kill()/pthread_kill(), not for a hardware trap
            cemu_crash_write(" si_pid "); crash_dec(info->si_pid);
            cemu_crash_write("\n");
        }

#if defined(__arm64__)
        if (context) {
            ucontext_t* uc = (ucontext_t*)context;
            const auto& ss = uc->uc_mcontext->__ss;
            const uint64_t pc = __darwin_arm_thread_state64_get_pc(ss);
            uint32_t insn = 0;
            if (crash_read(pc, &insn, sizeof(insn)) && (insn & 0xFFE0001Fu) == 0xD4200000u) {
                cemu_crash_write("the interrupted instruction is brk #"); crash_dec((int64_t)((insn >> 5) & 0xFFFF)); cemu_crash_write("\n");
            }
            cemu_crash_write("this thread's own frames:\n");
            crash_frames(pc, __darwin_arm_thread_state64_get_lr(ss), __darwin_arm_thread_state64_get_fp(ss),
                         __darwin_arm_thread_state64_get_sp(ss), 40);
        } else
#endif
        {
            void* frames[64];
            int count = backtrace(frames, 64);
            if (g_crashLogFd >= 0) backtrace_symbols_fd(frames, count, g_crashLogFd);
        }
        crash_dump_other_threads();
        cemu_crash_write("=== end of crash report ===\n");

        // Re-raise so iOS still writes its own report as well.
        signal(signum, SIG_DFL);
        raise(signum);
    }

    void cemu_crash_open_log() {
        if (g_crashLogFd >= 0)
            return;
        const char* home = getenv("HOME");
        if (!home)
            return;
        char path[1024];
        snprintf(path, sizeof(path), "%s/Documents/CemuCrashLog.txt", home);
        g_crashLogFd = open(path, O_WRONLY | O_CREAT | O_APPEND, 0644);
        // Recorded because under LiveContainer $HOME is redirected per hosted app, so the
        // file is not where it would be for a normal install. The app prints this path.
        snprintf(g_crashLogPath, sizeof(g_crashLogPath), "%s", path);
        // Pre-warm backtrace()'s lazy state outside signal context.
        void* warm[4];
        backtrace(warm, 4);
    }

    std::terminate_handler g_previousTerminateHandler = nullptr;

    // std::terminate is the one place an escaping exception's type and what() are still
    // recoverable. Write both, then chain so the signal handler still adds its backtrace.
    void cemu_terminate_handler() {
        cemu_crash_open_log();
        cemu_crash_write("\n=== CEMU TERMINATE ===\n");
        if (std::exception_ptr pending = std::current_exception())
        {
            try
            {
                std::rethrow_exception(pending);
            }
            catch (const std::exception& ex)
            {
                // Several threads can fail at once; one report is enough.
                static std::atomic_flag s_reportedOnce = ATOMIC_FLAG_INIT;
                if (dynamic_cast<const std::bad_alloc*>(&ex) && !s_reportedOnce.test_and_set())
                    cemu_vm_report("std::bad_alloc escaping a thread", 0);
                cemu_crash_write("uncaught C++ exception, type: ");
                cemu_crash_write(typeid(ex).name());
                cemu_crash_write("\nwhat(): ");
                cemu_crash_write(ex.what() ? ex.what() : "(none)");
                cemu_crash_write("\n");
            }
            catch (...)
            {
                cemu_crash_write("uncaught exception not derived from std::exception\n");
            }
        }
        else
        {
            cemu_crash_write("terminate called with no in-flight exception\n");
        }
        // The throw has not unwound anything yet when terminate runs, so this stack names the code that threw.
        {
            cemu_crash_write("terminate backtrace:\n");
            void* frames[40];
            const int frameCount = backtrace(frames, 40);
            if (g_crashLogFd >= 0)
                backtrace_symbols_fd(frames, frameCount, g_crashLogFd);
        }
        if (g_previousTerminateHandler && g_previousTerminateHandler != cemu_terminate_handler)
            g_previousTerminateHandler();
        abort();
    }
}

extern "C" __attribute__((constructor(101)))
void cemu_bridge_install_early_crash_handler() {
    cemu_crash_open_log();
    cemu_crash_write("=== Cemu process started (early constructor) ===\n");
    int sigs[] = {SIGSEGV, SIGBUS, SIGILL, SIGABRT, SIGTRAP, SIGFPE};
    for (int s : sigs) {
        struct sigaction action;
        memset(&action, 0, sizeof(action));
        action.sa_sigaction = cemu_crash_signal_handler;
        action.sa_flags = SA_SIGINFO;
        sigemptyset(&action.sa_mask);
        sigaction(s, &action, nullptr);
    }
    g_previousTerminateHandler = std::set_terminate(cemu_terminate_handler);
}

const char* cemu_bridge_crash_log_path(void) {
    cemu_crash_open_log();
    return g_crashLogPath;
}

void cemu_bridge_log_checkpoint(const char* message) {
    cemu_crash_open_log();
    cemu_crash_write(message);
    cemu_crash_write("\n");
    // Mirrored into the live ring so the on-screen launch log is one timeline.
    ios_live_log_push(message);
}

// A failed core assert (cemu_assert, assert_dbg, cemu_assert_error) used to raise SIGTRAP and end the app. On iOS
// DEBUG_BREAK calls this instead (Common/precompiled.h): the assert is logged with the calling thread's name and
// backtrace, and execution continues. Only the first few are logged in full, since an assert inside a loop can
// fire thousands of times a second.
extern "C" void cemu_ios_assert_hit(void) {
    static std::atomic<uint32_t> hits{0};
    const uint32_t n = ++hits;
    if (n > 20 && (n % 1000) != 0)
        return;
    cemu_crash_open_log();
    char name[64];
    name[0] = '\0';
    pthread_getname_np(pthread_self(), name, sizeof(name));
    char line[160];
    snprintf(line, sizeof(line), "CEMU ASSERT #%u on thread '%s' - continuing. Backtrace:", n, name[0] ? name : "(unnamed)");
    cemu_bridge_log_checkpoint(line);
    void* frames[24];
    const int count = backtrace(frames, 24);
    if (g_crashLogFd >= 0)
        backtrace_symbols_fd(frames, count, g_crashLogFd);
}

// ---------------------------------------------------------------------------
// Memory trail
//
// Jetsam delivers no signal and takes any buffered log with it, so these samples go
// through the synchronous checkpoint write, not cemuLog.
namespace {
    std::atomic<bool> g_memWatchRunning{false};

    // phys_footprint is what jetsam bills; resident_size undercounts.
    uint64_t cemu_mem_footprint_bytes() {
        task_vm_info_data_t info{};
        mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
        if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &count) != KERN_SUCCESS)
            return 0;
        return (uint64_t)info.phys_footprint;
    }

    // Total address space the process has mapped or reserved. On iOS this can run out long before RAM does
    // (the guest's 4 GB reservation and the JIT arena are all address space), so it is logged beside RAM.
    uint64_t cemu_mem_virtual_bytes() {
        task_vm_info_data_t info{};
        mach_msg_type_number_t count = TASK_VM_INFO_COUNT;
        if (task_info(mach_task_self(), TASK_VM_INFO, (task_info_t)&info, &count) != KERN_SUCCESS)
            return 0;
        return (uint64_t)info.virtual_size;
    }

    void cemu_mem_write_line(const char* tag, uint64_t availableBytes, uint64_t footprintBytes) {
        char line[720];
        int n = snprintf(line, sizeof(line),
                 "MEM %s: %llu MB still available to this process, %llu MB in use",
                 tag,
                 (unsigned long long)(availableBytes / (1024ull * 1024ull)),
                 (unsigned long long)(footprintBytes / (1024ull * 1024ull)));
        // Where the GPU side's memory is, as last published by the GPU thread (LatteWaitInfo.h), so one
        // line can name what grew. Absent until a Metal renderer has published once.
        if (n > 0 && n < (int)sizeof(line))
        {
            int m = snprintf(line + n, sizeof(line) - n, " | address space reserved %llu MB", (unsigned long long)(cemu_mem_virtual_bytes() / (1024ull * 1024ull)));
            if (m > 0) n += m;
        }
        auto& w = LatteWait::Get();
        if (n > 0 && n < (int)sizeof(line) && w.memStatsValid.load())
        {
            snprintf(line + n, sizeof(line) - n,
                     " | GPU: device %u MB (host-mapped %u MB), textures %u = %u MB, staging %u MB, index %u MB, snapshots %u MB, "
                     "buffer cache %u MB, streamout %u MB, readback %u MB, command buffers in flight %u, textures evicted %u",
                     (unsigned)w.memDeviceMB.load(), (unsigned)w.memHostMappedMB.load(), (unsigned)w.memTextureCount.load(), (unsigned)w.memTextureMB.load(),
                     (unsigned)w.memStagingMB.load(), (unsigned)w.memIndexMB.load(), (unsigned)w.memSnapshotMB.load(), (unsigned)w.memBufferCacheMB.load(),
                     (unsigned)w.memXfbMB.load(), (unsigned)w.memReadbackMB.load(), (unsigned)w.executingCommandBuffers.load(), (unsigned)w.texturesEvicted.load());
        }
        cemu_bridge_log_checkpoint(line);
    }
}

static std::string cemu_sysctl_string(const char* name)
{
    size_t len = 0;
    if (sysctlbyname(name, nullptr, &len, nullptr, 0) != 0 || len == 0)
        return std::string();
    std::string out(len, '\0');
    if (sysctlbyname(name, out.data(), &len, nullptr, 0) != 0)
        return std::string();
    if (!out.empty() && out.back() == '\0') out.pop_back();
    return out;
}

static uint64_t cemu_sysctl_u64(const char* name)
{
    uint64_t v = 0; size_t len = sizeof(v);
    if (sysctlbyname(name, &v, &len, nullptr, 0) == 0) return v;
    uint32_t v32 = 0; len = sizeof(v32);
    if (sysctlbyname(name, &v32, &len, nullptr, 0) == 0) return v32;
    return 0;
}

// The raw model identifier rather than a marketing name: a lookup table is out of date
// the day a device ships, and a wrong name is worse than an identifier.
// Built once, under the thread-safe static initialiser, so concurrent first callers can't
// observe a half-built string; the returned pointer stays valid for the process lifetime.
// Describes the exception currently being handled. Call only from inside a catch block.
static std::string cemu_describe_current_exception(void)
{
    try { throw; }
    catch (const std::exception& ex) { return std::string(typeid(ex).name()) + ": " + ex.what(); }
    catch (...)
    {
        const std::type_info* type = abi::__cxa_current_exception_type();
        return std::string("non-standard exception ") + (type ? type->name() : "of unknown type");
    }
}

static std::string cemu_build_device_report(void)
{
    std::string report;
    const std::string model = cemu_sysctl_string("hw.machine");
    const uint64_t memBytes = cemu_sysctl_u64("hw.memsize");
    const uint64_t cores    = cemu_sysctl_u64("hw.ncpu");
    const uint64_t pcores   = cemu_sysctl_u64("hw.perflevel0.logicalcpu");
    const uint64_t ecores   = cemu_sysctl_u64("hw.perflevel1.logicalcpu");

    unsigned long long avail = 0, foot = 0;
    cemu_bridge_memory_status(&avail, &foot);

    char buf[1024];
    snprintf(buf, sizeof(buf),
        "device: %s | iOS %s | RAM %llu MB | cores %llu",
        model.empty() ? "unknown" : model.c_str(),
        [[[NSProcessInfo processInfo] operatingSystemVersionString] UTF8String],
        (unsigned long long)(memBytes / (1024ull * 1024ull)),
        (unsigned long long)cores);
    // The capability line leads every device report, so reports from different devices compare line for line.
    report = std::string(cemu_device_caps_line()) + "\n" + buf;

    if (pcores && ecores)
    {
        snprintf(buf, sizeof(buf), " (%llu perf + %llu eff)",
                 (unsigned long long)pcores, (unsigned long long)ecores);
        report += buf;
    }
    if (avail)
    {
        snprintf(buf, sizeof(buf), " | %llu MB available to this app before iOS kills it",
                 (unsigned long long)(avail / (1024ull * 1024ull)));
        report += buf;
    }
    // BUILD_VERSION_STRING is a parenthesised expression, not a bare literal.
    report += " | build ";
    report += BUILD_VERSION_STRING;
    return report;
}

extern "C" const char* cemu_bridge_device_report(void)
{
    static const std::string report = cemu_build_device_report();
    return report.c_str();
}

// Declared here rather than in a header: PPCRecompiler.h is a core header the bridge does
// not otherwise pull in, and this is one symbol.
size_t PPCRecompiler_getJitArenaSize();
size_t PPCRecompiler_getJitArenaUsed();

const char* cemu_bridge_memory_headroom_summary(void) {
    static thread_local std::string summary;
    const uint64_t avail = (uint64_t)os_proc_available_memory();
    const uint64_t arena = (uint64_t)PPCRecompiler_getJitArenaSize();

    // Reports what iOS actually granted, not which entitlements were requested; the JIT
    // arena size shows whether the recompiler got room to work.
    char buf[256];
    if (arena == 0) {
        snprintf(buf, sizeof(buf),
            "%llu MB headroom - no JIT arena, so this launch is running the interpreter",
            (unsigned long long)(avail / (1024ull * 1024ull)));
    } else {
        // Reserved address space costs almost nothing; "in use" is what the process holds.
        const uint64_t used = (uint64_t)PPCRecompiler_getJitArenaUsed();
        snprintf(buf, sizeof(buf), "%llu MB headroom - JIT arena %llu MB reserved, %llu MB in use%s",
            (unsigned long long)(avail / (1024ull * 1024ull)),
            (unsigned long long)(arena / (1024ull * 1024ull)),
            (unsigned long long)(used / (1024ull * 1024ull)),
            arena < ((uint64_t)DeviceCaps::GetBudgets().jitArenaStartMB << 20) ? " (reduced - less room than the JIT asked for)" : "");
    }
    summary = buf;
    return summary.c_str();
}

bool cemu_bridge_memory_status(unsigned long long* availableBytes, unsigned long long* footprintBytes) {
    const uint64_t avail = (uint64_t)os_proc_available_memory();
    const uint64_t foot = cemu_mem_footprint_bytes();
    if (availableBytes) *availableBytes = (unsigned long long)avail;
    if (footprintBytes) *footprintBytes = (unsigned long long)foot;
    return avail != 0 || foot != 0;
}

void cemu_bridge_memory_note(const char* tag) {
    unsigned long long avail = 0, foot = 0;
    cemu_bridge_memory_status(&avail, &foot);
    cemu_mem_write_line(tag && tag[0] ? tag : "checkpoint", avail, foot);
}

bool MetalPipelineCache_FlushArchive(uint32_t timeoutMs);

void cemu_bridge_flush_pipeline_cache(void) {
    if (!MetalPipelineCache_FlushArchive(4000))
        cemu_bridge_log_checkpoint("pipeline cache flush did not finish in 4 s");
}

void cemu_bridge_start_memory_watchdog(void) {
    if (g_memWatchRunning.exchange(true))
        return;

    [[NSNotificationCenter defaultCenter]
        addObserverForName:UIApplicationDidReceiveMemoryWarningNotification
                    object:nil
                     queue:nil
                usingBlock:^(NSNotification* note) {
                    (void)note;
                    unsigned long long avail = 0, foot = 0;
                    cemu_bridge_memory_status(&avail, &foot);
                    cemu_mem_write_line("WARNING - iOS is asking for memory back", avail, foot);
                }];

    cemu_bridge_memory_note("baseline at startup");

    std::thread([] {
        // Bucketed so a steady footprint writes nothing; once a minute otherwise, to show
        // the sampler is alive without burying the log.
        uint64_t lastFootBucket = 0;
        uint64_t lastAvailBucket = UINT64_MAX;
        bool criticalAnnounced = false;
        auto lastForced = std::chrono::steady_clock::now();
        auto lastWritten = lastForced;
        while (g_memWatchRunning.load())
        {
            std::this_thread::sleep_for(std::chrono::milliseconds(100));
            unsigned long long avail = 0, foot = 0;
            if (!cemu_bridge_memory_status(&avail, &foot))
                continue;

            const uint64_t footBucket = foot / (32ull << 20);
            const uint64_t availBucket = avail / (64ull << 20);
            const auto now = std::chrono::steady_clock::now();

            // A footprint that wobbles across a bucket edge used to write a line every tick (8,000 lines in one session). A change
            // is written at most once every 5 seconds, and the buckets only advance when a line is written, so a real climb still shows.
            bool report = (footBucket > lastFootBucket || availBucket < lastAvailBucket) && now - lastWritten >= std::chrono::seconds(5);
            if (now - lastForced >= std::chrono::seconds(60)) report = true;

            if (report)
            {
                lastFootBucket = footBucket;
                lastAvailBucket = availBucket;
                cemu_mem_write_line("sample", avail, foot);
                lastForced = now;
                lastWritten = now;
            }

            if (!criticalAnnounced && avail > 0 && avail < (128ull << 20))
            {
                criticalAnnounced = true;
                cemu_mem_write_line("CRITICAL - a kill by iOS is likely imminent", avail, foot);
            }
        }
    }).detach();
}

// ---------------------------------------------------------------------------
// Bridge state
namespace {
    std::atomic<bool> g_initialized{false};
    // Unlike g_initialized (an entry latch), this is published only after every
    // bridge initialization step has returned. Research must not confuse them.
    std::atomic<bool> g_initializationComplete{false};

    // One status string for the whole bridge, not one per thread: the boot runs on a
    // background task and the UI reads it from the main thread.
    std::mutex g_statusMutex;
    std::string g_statusText;

    void setStatus(const char* s) {
        std::lock_guard<std::mutex> lock(g_statusMutex);
        g_statusText = s ? s : "";
    }

    bool statusIsEmpty() {
        std::lock_guard<std::mutex> lock(g_statusMutex);
        return g_statusText.empty();
    }

    // Copied under the lock into a per-thread snapshot; String(cString:) copies at once.
    const char* getStatus() {
        static thread_local std::string snapshot;
        {
            std::lock_guard<std::mutex> lock(g_statusMutex);
            snapshot = g_statusText;
        }
        return snapshot.c_str();
    }

    // 0 = not decided yet, 1 = interpreter, 2 = recompiler. 0 is not 1: "nothing has
    // looked" is a different claim from "the interpreter".
    constexpr int kCpuModeUndecided   = 0;
    constexpr int kCpuModeInterpreter = 1;
    constexpr int kCpuModeRecompiler  = 2;

    std::atomic<int> g_cpuMode{kCpuModeUndecided};
    std::atomic<bool> g_recompilerRequested{false};
    std::atomic<bool> g_favourAccuracy{false};
    // Favour performance: the opposite trade to Favour accuracy, applied in
    // ios_apply_render_profile(). Ignored while Favour accuracy is on.
    std::atomic<bool> g_favourPerformance{false};
    // Full speed renders: on/off and its shader choice (0 wait for a new shader, 1 keep going).
    // Applied in ios_apply_render_profile(), after both Favour switches, so it has the last word.
    std::atomic<bool> g_fullSpeedRenders{false};
    std::atomic<int> g_fullSpeedShaderMode{0};
    // One-core mode. Separate from Favour accuracy on purpose: both end up asking for
    // one emulated CPU core, but for opposite reasons and with different side effects.
    // Favour accuracy also forces synchronous shader compilation, accurate Vulkan
    // barriers and GX2DrawDone sync - all of which cost MORE work, not less, and are the
    // last thing a device that is already too hot needs. One-core mode wants the core count
    // down and nothing else changed.
    std::atomic<bool> g_lowPowerMode{false};
    // Core count choice from Settings (or this game's override): 0 Auto, 1 one core, 2 three
    // cores, 3 two host threads. Auto decides per title in ios_decide_core_count(); see there for why it leans
    // to one core.
    constexpr int kCoreModeAuto   = 0;
    constexpr int kCoreModeSingle = 1;
    constexpr int kCoreModeMulti  = 2;
    constexpr int kCoreModeTwo    = 3;
    std::atomic<int> g_coreModeSetting{kCoreModeAuto};
    // Set by the app when an earlier three-core run of this title crashed or hung (Auto only).
    std::atomic<bool> g_autoDemoted{false};
    // What the last boot actually used, for the app: host threads for the emulated cores, and
    // whether Auto (not the user) is what picked three.
    std::atomic<int> g_coresRunning{1};
    std::atomic<bool> g_autoPickedMulti{false};
    std::mutex g_cpuModeDetailMutex;
    std::string g_cpuModeDetail;

    void setCpuModeDetail(std::string detail) {
        std::lock_guard<std::mutex> lock(g_cpuModeDetailMutex);
        g_cpuModeDetail = std::move(detail);
    }

    const char* getCpuModeDetail() {
        static thread_local std::string snapshot;
        {
            std::lock_guard<std::mutex> lock(g_cpuModeDetailMutex);
            snapshot = g_cpuModeDetail;
        }
        return snapshot.c_str();
    }

    std::atomic<bool> g_titleRunning{false};
    std::atomic<bool> g_padRegistered{false};
    // The MoltenVK build selected for this launch, "" before initialize.
    std::string g_activeMoltenVK;
}

static void ios_timebase_ladder_start();
static void ios_timebase_ladder_stop();
static void ios_two_core_watch_start();
static void ios_two_core_watch_stop();

// ---------------------------------------------------------------------------
// JIT environment
//
// Launch-time checks for the JIT (dual-mapped memory and TXM detection), because the
// recompiler reads the answers from the environment:
// DUAL_MAPPED_JIT selects the dual-mapped arena that iOS 26 needs, and HAS_TXM tells it
// whether the Trusted Execution Monitor is enforcing, which changes how that arena has
// to be mapped. Set before CemuInitialize(), and never changed afterwards.
namespace {

NSString* ios_first_entry_with_length(NSString* dir, NSUInteger length)
{
    NSArray<NSString*>* entries = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:dir error:nil];
    for (NSString* entry in entries)
        if (entry.length == length)
            return [dir stringByAppendingPathComponent:entry];
    return nil;
}

bool ios_has_txm_classic()
{
    if ([NSProcessInfo processInfo].isiOSAppOnMac)
        return false;
    static NSString* const kImg4 = @"usr/standalone/firmware/FUD/Ap,TrustedExecutionMonitor.img4";
    if (NSString* boot = ios_first_entry_with_length(@"/System/Volumes/Preboot", 36))
    {
        if (NSString* file = ios_first_entry_with_length([boot stringByAppendingPathComponent:@"boot"], 96))
            return access([[file stringByAppendingPathComponent:kImg4] fileSystemRepresentation], F_OK) == 0;
    }
    if (NSString* preboot = ios_first_entry_with_length(@"/private/preboot", 96))
        return access([[preboot stringByAppendingPathComponent:kImg4] fileSystemRepresentation], F_OK) == 0;
    return false;
}

// "Apple M2" -> ('M', 2), "Apple A17 Pro GPU" -> ('A', 17).
bool ios_chip(char& series, int& number)
{
    id<MTLDevice> device = MTLCreateSystemDefaultDevice();
    if (!device)
        return false;
    NSString* name = device.name.uppercaseString;
    NSRegularExpression* re = [NSRegularExpression regularExpressionWithPattern:@"APPLE\\s+([MA])(\\d+)" options:0 error:nil];
    NSTextCheckingResult* m = [re firstMatchInString:name options:0 range:NSMakeRange(0, name.length)];
    if (!m)
        return false;
    series = (char)[[name substringWithRange:[m rangeAtIndex:1]] characterAtIndex:0];
    number = [[name substringWithRange:[m rangeAtIndex:2]] intValue];
    return true;
}

bool ios_os_at_least(NSInteger major, NSInteger minor)
{
    return [[NSProcessInfo processInfo] isOperatingSystemAtLeastVersion:(NSOperatingSystemVersion){major, minor, 0}];
}

bool ios_has_txm()
{
    char series = 0;
    int number = 0;
    const bool known = ios_chip(series, number);
    if (ios_os_at_least(27, 0))
    {
        // A12 is the last A-series chip without TXM.
        if (known && series == 'A')
            return number > 12;
        return true;
    }
    if (ios_os_at_least(26, 6) && !ios_has_txm_classic())
    {
        if (!known)
            return false;
        return series == 'M' ? number >= 2 : number >= 15;
    }
    return ios_has_txm_classic();
}

void ios_configure_jit_environment()
{
    if (ios_os_at_least(19, 0))
    {
        const bool txm = ![NSProcessInfo processInfo].isiOSAppOnMac && ios_has_txm();
        setenv("DUAL_MAPPED_JIT", "1", 1);
        setenv("HAS_TXM", txm ? "1" : "0", 1);
    }
    else
    {
        setenv("HAS_TXM", "0", 1);
    }
    cemu_bridge_log_checkpoint((std::string("JIT environment: DUAL_MAPPED_JIT=") + (getenv("DUAL_MAPPED_JIT") ? getenv("DUAL_MAPPED_JIT") : "unset") +
        " HAS_TXM=" + (getenv("HAS_TXM") ? getenv("HAS_TXM") : "unset")).c_str());
}

// CS_DEBUGGED waives the signature check at instruction fetch. It is what every JIT
// enabler (StikJIT, SideStore, LiveContainer, a debugger) produces, and it is the same
// flag the core's recompiler checks before it generates code.
bool ios_process_is_debugged(uint32_t& flagsOut)
{
    flagsOut = 0;
    return csops(getpid(), 0 /* CS_OPS_STATUS */, &flagsOut, sizeof(flagsOut)) == 0 && (flagsOut & 0x10000000u) != 0;
}

// What the running device is, read once. Used to decide the core count and written to the
// performance log so reports from different devices can be compared.
namespace {
    struct IosDeviceFacts
    {
        std::string model;
        std::string gpuName;
        uint64_t perfCores = 0;
        uint64_t effCores = 0;
        uint64_t totalCores = 0;
        uint64_t memoryMB = 0;
    };

    const IosDeviceFacts& ios_device_facts()
    {
        static const IosDeviceFacts facts = [] {
            IosDeviceFacts f;
            f.model = cemu_sysctl_string("hw.machine");
            f.totalCores = cemu_sysctl_u64("hw.ncpu");
            f.perfCores = cemu_sysctl_u64("hw.perflevel0.physicalcpu");
            if (!f.perfCores)
                f.perfCores = cemu_sysctl_u64("hw.perflevel0.logicalcpu");
            f.effCores = cemu_sysctl_u64("hw.perflevel1.physicalcpu");
            if (!f.effCores)
                f.effCores = cemu_sysctl_u64("hw.perflevel1.logicalcpu");
            if (!f.perfCores)
                f.perfCores = f.totalCores; // no performance levels reported: treat every core alike
            f.memoryMB = cemu_sysctl_u64("hw.memsize") / (1024ull * 1024ull);
            id<MTLDevice> device = MTLCreateSystemDefaultDevice();
            if (device && device.name)
                f.gpuName = [device.name UTF8String];
            return f;
        }();
        return facts;
    }

    // ProcessInfo.ThermalState: 0 nominal, 1 fair, 2 serious, 3 critical
    int ios_thermal_state() { return (int)[[NSProcessInfo processInfo] thermalState]; }

    const char* ios_thermal_name(int state)
    {
        switch (state)
        {
        case 0: return "nominal";
        case 1: return "fair";
        case 2: return "serious";
        case 3: return "critical";
        default: return "unknown";
        }
    }

    // Auto may use three host threads only on a device with the cores, the memory tier and the
    // thermal room for them: at least four performance cores, Tier High or above, and a nominal
    // thermal state right now. Every input is read from the running device. Parts that fall short
    // (fewer performance cores, less memory, already warm) stay on one core.
    bool ios_auto_multicore_viable(const IosDeviceFacts& device, int thermalState)
    {
        return device.perfCores >= 4
            && DeviceCaps::Get().tier() >= DeviceCaps::Tier::High
            && thermalState == 0;
    }

    NSString* ios_two_core_hang_key() { return @"muffin.cpu.twoCoreHung"; }

    NSString* ios_title_key(uint64_t titleId) { return [NSString stringWithFormat:@"%016llx", (unsigned long long)titleId]; }

    bool ios_two_core_hang_recorded(uint64_t titleId)
    {
        return [[[NSUserDefaults standardUserDefaults] stringArrayForKey:ios_two_core_hang_key()] containsObject:ios_title_key(titleId)];
    }

    void ios_two_core_hang_set(uint64_t titleId, bool hung)
    {
        NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
        NSMutableArray<NSString*>* list = [([defaults stringArrayForKey:ios_two_core_hang_key()] ?: @[]) mutableCopy];
        NSString* key = ios_title_key(titleId);
        if (hung && ![list containsObject:key])
            [list addObject:key];
        else if (!hung && [list containsObject:key])
            [list removeObject:key];
        else
            return;
        [defaults setObject:list forKey:ios_two_core_hang_key()];
    }

    struct CoreDecision
    {
        bool singleCore = true;
        bool twoCores = false;
        bool autoPickedMulti = false;
        std::string reason;
    };

    // The emulated console has three cores. Running them on three host threads only pays off
    // when the device has spare performance cores AND the thermal room to power them: three
    // threads draw about three times the power of one, and a part that throttles loses more than
    // it gains. Auto therefore picks three only when the title's game profile asks for it, or when
    // the device itself qualifies (ios_auto_multicore_viable: four or more performance cores, Tier
    // High or above, nominal thermal state), and never after an earlier three-core run of the same
    // title crashed or hung. The thermal and stall fallbacks (ThermalMonitor, StallDetector) drop a
    // running three-core session back to one core. Every other device stays on one core.
    CoreDecision ios_decide_core_count(uint64_t titleId)
    {
        const IosDeviceFacts& device = ios_device_facts();
        const int setting = g_coreModeSetting.load();
        const int thermal = ios_thermal_state();
        char deviceText[96];
        snprintf(deviceText, sizeof(deviceText), "%llu performance core(s), tier %s, thermal %s",
            (unsigned long long)device.perfCores, DeviceCaps::TierName(DeviceCaps::Get().tier()), ios_thermal_name(thermal));
        CoreDecision d;

        if (g_favourAccuracy.load())
        {
            d.reason = "one core because Favour accuracy is on";
            return d;
        }
        if (g_lowPowerMode.load())
        {
            d.reason = "one core because One-core mode is on";
            return d;
        }
        if (setting == kCoreModeSingle)
        {
            d.reason = "one core, chosen in Settings";
            return d;
        }
        // Auto never exceeds the device: under 4.5 GB of RAM, or with fewer than three performance cores, three host
        // threads starve the GPU and heat the part (DeviceCapabilities.h). A manual Two or Three cores here came from an
        // Advanced choice (Basic resolves an unavailable one to Auto in Swift), so it is attempted, and the GX2Init guard
        // drops a stuck title to one core on its next launch.
        const uint32_t maxThreads = DeviceCaps::GetBudgets().maxHostThreads;
        if (setting == kCoreModeAuto && maxThreads < 3)
        {
            d.reason = std::string("one core: this device has too little memory or too few performance cores to run three at once (") + deviceText + ")";
            return d;
        }
        if (setting != kCoreModeAuto && maxThreads < (setting == kCoreModeTwo ? 2u : 3u))
            cemu_bridge_log_line((std::string("CPU cores: ") + (setting == kCoreModeTwo ? "two" : "three") + " cores chosen in Advanced settings, more than this device can run (up to " + std::to_string(maxThreads) + " host thread(s); " + deviceText + "). Attempting it anyway").c_str());
        if (setting == kCoreModeTwo)
        {
            if (titleId != 0 && ios_two_core_hang_recorded(titleId))
            {
                d.reason = std::string("one core: a two-core run of this title never reached GX2Init before (") + deviceText + ")";
                return d;
            }
            d.singleCore = false;
            d.twoCores = true;
            d.reason = std::string("two cores, chosen in Settings (experimental; ") + deviceText + ")";
            if (device.perfCores < 2)
                d.reason += ". This device has fewer than two performance cores, so expect it to run slower than one core";
            return d;
        }
        if (setting == kCoreModeMulti)
        {
            d.singleCore = false;
            d.reason = std::string("three cores, chosen in Settings (experimental; ") + deviceText + ")";
            if (device.perfCores < 3)
                d.reason += ". This device has fewer than three performance cores, so expect it to run slower than one core";
            return d;
        }

        // Auto
        if (g_autoDemoted.load())
        {
            d.reason = "Auto picked one core: a three-core run of this title crashed or hung before";
            return d;
        }
        if (thermal >= 2)
        {
            d.reason = std::string("Auto picked one core: the device is already hot (") + deviceText + ")";
            return d;
        }
        if (device.perfCores < 3)
        {
            d.reason = std::string("Auto picked one core: too few performance cores (") + deviceText + ")";
            return d;
        }
        std::optional<CPUMode> profileMode;
        if (titleId != 0)
        {
            GameProfile probe;
            if (probe.Load(titleId))
                profileMode = probe.GetCPUMode();
        }
        if (profileMode && (*profileMode == CPUMode::SinglecoreInterpreter || *profileMode == CPUMode::SinglecoreRecompiler))
        {
            d.reason = std::string("Auto picked one core: this title's game profile asks for single-core (") + deviceText + ")";
            return d;
        }
        if (profileMode && *profileMode == CPUMode::MulticoreRecompiler)
        {
            d.singleCore = false;
            d.autoPickedMulti = true;
            d.reason = std::string("Auto picked three cores: this title's game profile asks for multi-core (") + deviceText + ")";
            return d;
        }
        if (ios_auto_multicore_viable(device, thermal))
        {
            d.singleCore = false;
            d.autoPickedMulti = true;
            d.reason = std::string("Auto picked three cores: this device has the performance cores, memory and thermal room (") + deviceText + ")";
            return d;
        }
        d.reason = std::string("Auto picked one core: this device does not meet the cores, memory tier and thermal state needed for three (") + deviceText + ")";
        return d;
    }
}

// Decides the CPU path for the next boot from the core-count choice, the two Settings
// toggles and what the process can actually do, and records both the answer and the reason.
// Written into the engine's own config, which is what the core's CafeSystem reads when a
// title starts.
//
// Always an explicit mode, never the core's Auto. On iOS the core's GetCPUMode() returns the
// config value unresolved, and _LaunchTitleThread() only starts the three emulated cores on
// their own host threads for the two Multicore modes, so the core's Auto ran every title on
// one thread and ignored the game profile. The decision lives in ios_decide_core_count().
void ios_apply_cpu_mode(bool announce = false)
{
    uint32_t csFlags = 0;
    const bool debugged = ios_process_is_debugged(csFlags);
    uint64_t titleId = 0;
    if (announce)
        titleId = CafeSystem::GetForegroundTitleId();
    const CoreDecision cores = ios_decide_core_count(titleId);
    const bool singleCore = cores.singleCore;
    auto& config = GetConfig();
    char detail[768];

    if (announce)
        cemuLog_log(LogType::Force, "CPU cores: {}", cores.reason);
    const char* coreWord = singleCore ? "single-core" : (cores.twoCores ? "two-core" : "multi-core");
    g_coresRunning.store(singleCore ? 1 : (cores.twoCores ? 2 : 3));
    g_autoPickedMulti.store(cores.autoPickedMulti);

    if (!g_recompilerRequested.load() || !debugged)
    {
        if (announce)
        {
            if (!g_recompilerRequested.load())
                cemuLog_log(LogType::Force, "Recompiler not used: the recompiler (JIT) setting is off");
            else
                cemuLog_log(LogType::Force, "Recompiler not used: the recompiler is on in Settings but no JIT enabler is attached to this process (cs_flags 0x{:08x}, CS_DEBUGGED not set)", csFlags);
        }
        // Without CS_DEBUGGED the interpreter is the only option, not a preference: the
        // kernel kills the process the moment it runs generated code, and an explicit
        // recompiler mode skips the debugger check the core applies to Auto.
        config.cpu_mode = singleCore ? CPUMode::SinglecoreInterpreter : (cores.twoCores ? CPUMode::TwocoreInterpreter : CPUMode::MulticoreInterpreter);
        g_cpuMode.store(kCpuModeInterpreter);
        if (!g_recompilerRequested.load())
            snprintf(detail, sizeof(detail), "The recompiler is off in Settings, so the %s interpreter is running. Cores: %s.",
                coreWord, cores.reason.c_str());
        else
            snprintf(detail, sizeof(detail), "The recompiler is on in Settings, but no JIT enabler is attached (cs_flags 0x%08x), "
                "so the %s interpreter is running. Launch through StikJIT, SideStore or LiveContainer to use the recompiler. Cores: %s.",
                csFlags, coreWord, cores.reason.c_str());
        setCpuModeDetail(detail);
        return;
    }
    config.cpu_mode = singleCore ? CPUMode::SinglecoreRecompiler : (cores.twoCores ? CPUMode::TwocoreRecompiler : CPUMode::MulticoreRecompiler);
    g_cpuMode.store(kCpuModeRecompiler);
    snprintf(detail, sizeof(detail), "A JIT enabler is attached, so the AArch64 recompiler runs this launch. Cores: %s.",
        cores.reason.c_str());
    setCpuModeDetail(detail);
}

// The GPU half of Favour accuracy. Off, the accuracy-only work is skipped and shader
// compilation is left to the Swift side's per-game choice; on, every shader is built
// before the frame that needs it, Vulkan barriers are placed exactly, and the CPU waits
// for the GPU at GX2DrawDone the way the console does.
void ios_apply_render_profile()
{
    auto& config = GetConfig();
    const bool accuracy = g_favourAccuracy.load();
    const bool performance = g_favourPerformance.load() && !accuracy;
    config.vk_accurate_barriers = accuracy;
    config.gx2drawdone_sync = accuracy;
    if (accuracy)
        config.async_compile = false;
    // Favour performance goes past the default speed path: a missing shader never stalls the
    // frame, multiplies skip the console's 0*anything=0 rule, and draws skip the breadcrumbs that
    // only a crash report reads. Set on every title start so turning it off restores all three.
    if (performance)
        config.async_compile = true;
    g_latteRelaxShaderMul.store(performance, std::memory_order_relaxed);
    // Settings > Shaders > Smaller texture cache: 512 MB per pack instead of 1 GB, for devices short on storage.
    LatteTextureASTCCache_SetPackLimitMB([[NSUserDefaults standardUserDefaults] boolForKey:@"muffin.textureCache.smaller"] ? 512 : 1024);
    const bool fullSpeed = g_fullSpeedRenders.load();
    if (fullSpeed)
        config.async_compile = g_fullSpeedShaderMode.load() == 1;
    g_latteFullSpeedRenders.store(fullSpeed, std::memory_order_relaxed);
    PerfTelemetry::DrawBreadcrumbsEnabled().store(!(performance || fullSpeed), std::memory_order_relaxed);
    if (fullSpeed)
        cemuLog_log(LogType::Force, "iOS: full speed renders - GPU thread user-interactive, presents paced to the game, new shaders {}",
            g_fullSpeedShaderMode.load() == 1 ? "in the background" : "waited for");
    cemuLog_log(LogType::Force, "iOS: {} - async shaders {}, accurate barriers {}, GX2DrawDone sync {}, strict shader mul {}",
        accuracy ? "favouring accuracy" : (performance ? "favouring performance" : "favouring speed"),
        config.async_compile.GetValue(), config.vk_accurate_barriers.GetValue(), config.gx2drawdone_sync.GetValue(),
        performance ? "off" : "per game profile");
}

}  // namespace

// ---------------------------------------------------------------------------
// Live launch log
//
// The core's logger writes log.txt and nothing else, so the engine's own lines reach the
// on-screen launch log by tailing that file. Checkpoints and bridge lines are pushed into
// the same ring directly, so the two interleave in the order they were written.
namespace {
    std::atomic<bool> g_logTailRunning{false};

    void ios_log_tail_start()
    {
        if (g_logTailRunning.exchange(true))
            return;
        const std::string path = _pathToUtf8(ActiveSettings::GetUserDataPath("log.txt"));
        std::thread([path] {
            long offset = 0;
            std::string partial;
            char chunk[4096];
            while (g_logTailRunning.load())
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(250));
                FILE* f = fopen(path.c_str(), "rb");
                if (!f)
                    continue;
                fseek(f, 0, SEEK_END);
                const long size = ftell(f);
                // A smaller file is a new log (the core truncates at start); read it from the top.
                if (size < offset)
                {
                    offset = 0;
                    partial.clear();
                }
                fseek(f, offset, SEEK_SET);
                size_t n;
                while ((n = fread(chunk, 1, sizeof(chunk), f)) > 0)
                {
                    offset += (long)n;
                    partial.append(chunk, n);
                    size_t nl;
                    while ((nl = partial.find('\n')) != std::string::npos)
                    {
                        std::string line = partial.substr(0, nl);
                        if (!line.empty() && line.back() == '\r')
                            line.pop_back();
                        ios_live_log_push(line.c_str());
                        partial.erase(0, nl + 1);
                    }
                }
                fclose(f);
            }
        }).detach();
    }
}

// ---------------------------------------------------------------------------
// Frame statistics
//
// The core's window system discards the FPS the performance monitor reports, so the rate
// is measured here from the GPU state the core already keeps: LatteGPUState.frameCounter
// is incremented once per frame the emulated GPU finishes. Fractional on purpose - a
// title rendering at 0.4 frames per second is slow, not stopped.
namespace {
    std::atomic<double> g_framesPerSecond{0.0};
    std::atomic<bool> g_statsRunning{false};

    void ios_stats_start()
    {
        if (g_statsRunning.exchange(true))
            return;
        std::thread([] {
            uint32 lastFrames = 0;
            auto lastTime = std::chrono::steady_clock::now();
            bool haveBaseline = false;
            while (g_statsRunning.load())
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                if (!g_titleRunning.load() || IOSTitlePause_IsPaused())
                {
                    g_framesPerSecond.store(0.0);
                    haveBaseline = false;
                    continue;
                }
                const uint32 frames = LatteGPUState.frameCounter;
                const auto now = std::chrono::steady_clock::now();
                if (haveBaseline && frames >= lastFrames)
                {
                    const double dt = std::chrono::duration<double>(now - lastTime).count();
                    if (dt > 0.0)
                        g_framesPerSecond.store((double)(frames - lastFrames) / dt);
                }
                lastFrames = frames;
                lastTime = now;
                haveBaseline = true;
            }
        }).detach();
    }
}

// ---------------------------------------------------------------------------
// Performance line
//
// About every five seconds while a title runs, one line says where the time went in that window
// and which resource the numbers point at. The counters are cumulative relaxed atomics kept by the
// core (PerfTelemetry.h); this only subtracts two snapshots, so the cost while running is the
// counters themselves, a few nanoseconds at the points that already wait or compile.
namespace {
    std::mutex g_perfLineMutex;
    std::string g_perfLine;

    struct PerfSnapshot
    {
        std::chrono::steady_clock::time_point at;
        uint32_t frames = 0, flips = 0;
        uint64_t ppcIdleNs = 0, gpuIdleNs = 0, gpuSyncNs = 0, drawableWaitNs = 0, mtlGpuNs = 0;
        uint32_t mtlCommandBuffers = 0, tvPresents = 0, padPresents = 0;
        uint32_t shaderCompiles = 0, pipelineCompiles = 0, pipelineSyncCompiles = 0;
        uint64_t shaderCompileNs = 0, pipelineCompileNs = 0;
        uint32_t textureDecodes = 0;
        uint64_t textureDecodeNs = 0;
        uint32_t textureTranscodes = 0, textureTranscodeCacheHits = 0, textureTranscodeDirect = 0;
        uint64_t textureTranscodeNs = 0;
        uint32_t jitBlocks = 0, jitInvalidations = 0, jitArenaReleases = 0, jitArenaAllocFails = 0;
        uint64_t jitCompileNs = 0;
        // GPU thread breakdown (see PerfTelemetry::Counters)
        uint32_t gpuDraws = 0, gpuTexHashes = 0;
        uint64_t gpuBeginNs = 0, gpuTexUpdateNs = 0, gpuTexHashNs = 0, gpuTexHashBytes = 0;
        uint64_t gpuExecNs = 0, gpuIndexNs = 0, gpuFlushNs = 0, gpuBufferNs = 0, gpuSnapshotCompareBytes = 0, gpuSnapshotCopyBytes = 0;
        uint64_t gpuPassNs = 0, gpuPipelineNs = 0, gpuBindNs = 0, gpuEndNs = 0;
        uint32_t gpuUseResourceCalls = 0, gpuUseResourceSkips = 0, gpuArgEncodes = 0, gpuArgReuses = 0, gpuSamplerLookups = 0, gpuTexViewLookups = 0;
        uint64_t gpuUseResourceNs = 0, gpuArgEncodeNs = 0, gpuArgReuseNs = 0, gpuSamplerLookupNs = 0, gpuTexViewLookupNs = 0;
        uint32_t gpuArgMissNoBase = 0, gpuArgMissSupport = 0, gpuArgMissSupportOnly = 0, gpuArgMissUniform = 0, gpuArgMissTexture = 0;
        uint32_t gpuArgMissSampler = 0, gpuArgMissVertexIndex = 0, gpuArgMissConstant = 0, gpuArgDeltaEncodes = 0;
        uint64_t gpuArgDeltaSlots = 0;
        uint64_t gpuArgEncAllocNs = 0, gpuArgEncCopyNs = 0, gpuArgEncSetNs = 0, gpuArgEncFlushNs = 0;
        uint64_t gpuBindTextureLoopNs = 0, gpuBindResidencyNs = 0, gpuBindSupportPrepNs = 0, gpuBindRemappedNs = 0, gpuBindSnapshotNs = 0;
        uint64_t gpuBindUniformLoopNs = 0, gpuBindTrackNs = 0, gpuBindCrumbNs = 0, gpuBindVertexNs = 0, gpuBindFinalNs = 0;
    };

    PerfSnapshot ios_perf_take()
    {
        auto& c = PerfTelemetry::Get();
        PerfSnapshot s;
        s.at = std::chrono::steady_clock::now();
        s.frames = LatteGPUState.frameCounter;
        s.flips = LatteGPUState.flipCounter;
        s.ppcIdleNs = c.ppcIdleNs.load(std::memory_order_relaxed);
        s.gpuIdleNs = c.gpuIdleNs.load(std::memory_order_relaxed);
        s.gpuSyncNs = c.gpuSyncNs.load(std::memory_order_relaxed);
        s.drawableWaitNs = c.drawableWaitNs.load(std::memory_order_relaxed);
        s.mtlGpuNs = c.mtlGpuNs.load(std::memory_order_relaxed);
        s.mtlCommandBuffers = c.mtlCommandBuffers.load(std::memory_order_relaxed);
        s.tvPresents = c.tvPresents.load(std::memory_order_relaxed);
        s.padPresents = c.padPresents.load(std::memory_order_relaxed);
        s.shaderCompiles = c.shaderCompiles.load(std::memory_order_relaxed);
        s.shaderCompileNs = c.shaderCompileNs.load(std::memory_order_relaxed);
        s.pipelineCompiles = c.pipelineCompiles.load(std::memory_order_relaxed);
        s.pipelineCompileNs = c.pipelineCompileNs.load(std::memory_order_relaxed);
        s.pipelineSyncCompiles = c.pipelineSyncCompiles.load(std::memory_order_relaxed);
        s.textureDecodes = c.textureDecodes.load(std::memory_order_relaxed);
        s.textureDecodeNs = c.textureDecodeNs.load(std::memory_order_relaxed);
        s.textureTranscodes = c.textureTranscodes.load(std::memory_order_relaxed);
        s.textureTranscodeNs = c.textureTranscodeNs.load(std::memory_order_relaxed);
        s.textureTranscodeCacheHits = c.textureTranscodeCacheHits.load(std::memory_order_relaxed);
        s.textureTranscodeDirect = c.textureTranscodeDirect.load(std::memory_order_relaxed);
        s.jitBlocks = c.jitBlocks.load(std::memory_order_relaxed);
        s.jitCompileNs = c.jitCompileNs.load(std::memory_order_relaxed);
        s.jitInvalidations = c.jitInvalidations.load(std::memory_order_relaxed);
        s.jitArenaReleases = c.jitArenaReleases.load(std::memory_order_relaxed);
        s.jitArenaAllocFails = c.jitArenaAllocFails.load(std::memory_order_relaxed);
        s.gpuDraws = c.gpuDraws.load(std::memory_order_relaxed);
        s.gpuTexHashes = c.gpuTexHashes.load(std::memory_order_relaxed);
        s.gpuBeginNs = c.gpuBeginNs.load(std::memory_order_relaxed);
        s.gpuTexUpdateNs = c.gpuTexUpdateNs.load(std::memory_order_relaxed);
        s.gpuTexHashNs = c.gpuTexHashNs.load(std::memory_order_relaxed);
        s.gpuTexHashBytes = c.gpuTexHashBytes.load(std::memory_order_relaxed);
        s.gpuExecNs = c.gpuExecNs.load(std::memory_order_relaxed);
        s.gpuIndexNs = c.gpuIndexNs.load(std::memory_order_relaxed);
        s.gpuFlushNs = c.gpuFlushNs.load(std::memory_order_relaxed);
        s.gpuBufferNs = c.gpuBufferNs.load(std::memory_order_relaxed);
        s.gpuSnapshotCompareBytes = c.gpuSnapshotCompareBytes.load(std::memory_order_relaxed);
        s.gpuSnapshotCopyBytes = c.gpuSnapshotCopyBytes.load(std::memory_order_relaxed);
        s.gpuPassNs = c.gpuPassNs.load(std::memory_order_relaxed);
        s.gpuPipelineNs = c.gpuPipelineNs.load(std::memory_order_relaxed);
        s.gpuBindNs = c.gpuBindNs.load(std::memory_order_relaxed);
        s.gpuEndNs = c.gpuEndNs.load(std::memory_order_relaxed);
        s.gpuUseResourceCalls = c.gpuUseResourceCalls.load(std::memory_order_relaxed);
        s.gpuUseResourceSkips = c.gpuUseResourceSkips.load(std::memory_order_relaxed);
        s.gpuArgEncodes = c.gpuArgEncodes.load(std::memory_order_relaxed);
        s.gpuArgReuses = c.gpuArgReuses.load(std::memory_order_relaxed);
        s.gpuSamplerLookups = c.gpuSamplerLookups.load(std::memory_order_relaxed);
        s.gpuTexViewLookups = c.gpuTexViewLookups.load(std::memory_order_relaxed);
        s.gpuUseResourceNs = c.gpuUseResourceNs.load(std::memory_order_relaxed);
        s.gpuArgEncodeNs = c.gpuArgEncodeNs.load(std::memory_order_relaxed);
        s.gpuArgReuseNs = c.gpuArgReuseNs.load(std::memory_order_relaxed);
        s.gpuSamplerLookupNs = c.gpuSamplerLookupNs.load(std::memory_order_relaxed);
        s.gpuTexViewLookupNs = c.gpuTexViewLookupNs.load(std::memory_order_relaxed);
        s.gpuArgMissNoBase = c.gpuArgMissNoBase.load(std::memory_order_relaxed);
        s.gpuArgMissSupport = c.gpuArgMissSupport.load(std::memory_order_relaxed);
        s.gpuArgMissSupportOnly = c.gpuArgMissSupportOnly.load(std::memory_order_relaxed);
        s.gpuArgMissUniform = c.gpuArgMissUniform.load(std::memory_order_relaxed);
        s.gpuArgMissTexture = c.gpuArgMissTexture.load(std::memory_order_relaxed);
        s.gpuArgMissSampler = c.gpuArgMissSampler.load(std::memory_order_relaxed);
        s.gpuArgMissVertexIndex = c.gpuArgMissVertexIndex.load(std::memory_order_relaxed);
        s.gpuArgMissConstant = c.gpuArgMissConstant.load(std::memory_order_relaxed);
        s.gpuArgDeltaEncodes = c.gpuArgDeltaEncodes.load(std::memory_order_relaxed);
        s.gpuArgDeltaSlots = c.gpuArgDeltaSlots.load(std::memory_order_relaxed);
        s.gpuArgEncAllocNs = c.gpuArgEncAllocNs.load(std::memory_order_relaxed);
        s.gpuArgEncCopyNs = c.gpuArgEncCopyNs.load(std::memory_order_relaxed);
        s.gpuArgEncSetNs = c.gpuArgEncSetNs.load(std::memory_order_relaxed);
        s.gpuArgEncFlushNs = c.gpuArgEncFlushNs.load(std::memory_order_relaxed);
        s.gpuBindTextureLoopNs = c.gpuBindTextureLoopNs.load(std::memory_order_relaxed);
        s.gpuBindResidencyNs = c.gpuBindResidencyNs.load(std::memory_order_relaxed);
        s.gpuBindSupportPrepNs = c.gpuBindSupportPrepNs.load(std::memory_order_relaxed);
        s.gpuBindRemappedNs = c.gpuBindRemappedNs.load(std::memory_order_relaxed);
        s.gpuBindSnapshotNs = c.gpuBindSnapshotNs.load(std::memory_order_relaxed);
        s.gpuBindUniformLoopNs = c.gpuBindUniformLoopNs.load(std::memory_order_relaxed);
        s.gpuBindTrackNs = c.gpuBindTrackNs.load(std::memory_order_relaxed);
        s.gpuBindCrumbNs = c.gpuBindCrumbNs.load(std::memory_order_relaxed);
        s.gpuBindVertexNs = c.gpuBindVertexNs.load(std::memory_order_relaxed);
        s.gpuBindFinalNs = c.gpuBindFinalNs.load(std::memory_order_relaxed);
        return s;
    }

    double ios_clamp01(double v) { return v < 0.0 ? 0.0 : (v > 1.0 ? 1.0 : v); }

    // Whether the game's own frame rate sits on one of the rates a vsync-locked title runs at
    // (60, 30, 20), which is the normal way to be at full speed.
    bool ios_fps_on_a_cap(double fps)
    {
        for (int divisor = 1; divisor <= 3; divisor++)
        {
            const double target = 60.0 / divisor;
            if (fps >= target * 0.95 && fps <= target * 1.05)
                return true;
        }
        return false;
    }

    void ios_perf_log_window(const PerfSnapshot& a, const PerfSnapshot& b, bool logHeader)
    {
        const double dt = std::chrono::duration<double>(b.at - a.at).count();
        if (dt <= 0.0)
            return;
        const double wallNs = dt * 1e9;
        const double frames = (double)(uint32_t)(b.frames - a.frames);
        const double flips = (double)(uint32_t)(b.flips - a.flips);
        const double hostPresents = std::max<double>((double)(uint32_t)(b.tvPresents - a.tvPresents), (double)(uint32_t)(b.padPresents - a.padPresents));
        const double hostThreads = std::max<double>(1.0, PerfTelemetry::Get().ppcHostThreads.load(std::memory_order_relaxed));

        const double hostFps = hostPresents / dt;
        const double guestFps = frames / dt;
        const double vsyncRate = flips / dt;
        // The emulated console's vsync is 60 Hz of emulated time; below 60 per real second the
        // emulation as a whole is running slower than the console.
        const double speedPct = vsyncRate / 60.0 * 100.0;
        const double ppcWait = ios_clamp01((double)(b.ppcIdleNs - a.ppcIdleNs) / (wallNs * hostThreads));
        const double ppcRun = 1.0 - ppcWait;
        const double gpuIdle = ios_clamp01((double)(b.gpuIdleNs - a.gpuIdleNs) / wallNs);
        const double gpuSync = ios_clamp01((double)(b.gpuSyncNs - a.gpuSyncNs) / wallNs);
        const double gpuThreadBusy = ios_clamp01(1.0 - gpuIdle - gpuSync);
        const double mtlBusy = ios_clamp01((double)(b.mtlGpuNs - a.mtlGpuNs) / wallNs);
        const double mtlMsPerFrame = frames > 0.0 ? (double)(b.mtlGpuNs - a.mtlGpuNs) / 1e6 / frames : 0.0;
        const double cbPerFrame = frames > 0.0 ? (double)(b.mtlCommandBuffers - a.mtlCommandBuffers) / frames : 0.0;
        const uint32_t shaders = b.shaderCompiles - a.shaderCompiles;
        const uint32_t pipelines = b.pipelineCompiles - a.pipelineCompiles;
        const uint32_t pipelinesOnGpuThread = b.pipelineSyncCompiles - a.pipelineSyncCompiles;
        const double shaderMs = (double)(b.shaderCompileNs - a.shaderCompileNs) / 1e6;
        const double pipelineMs = (double)(b.pipelineCompileNs - a.pipelineCompileNs) / 1e6;
        const uint32_t textureDecodes = b.textureDecodes - a.textureDecodes;
        const double textureDecodeMs = (double)(b.textureDecodeNs - a.textureDecodeNs) / 1e6;
        const uint32_t textureTranscodes = b.textureTranscodes - a.textureTranscodes;
        const double textureTranscodeMs = (double)(b.textureTranscodeNs - a.textureTranscodeNs) / 1e6;
        const uint32_t textureTranscodeCacheHits = b.textureTranscodeCacheHits - a.textureTranscodeCacheHits;
        const uint32_t textureTranscodeDirect = b.textureTranscodeDirect - a.textureTranscodeDirect;
        const uint32_t jitBlocks = b.jitBlocks - a.jitBlocks;
        const double jitMs = (double)(b.jitCompileNs - a.jitCompileNs) / 1e6;
        const int thermal = ios_thermal_state();

        // Which resource the window points at, in the order the checks are trustworthy: no frames
        // at all, then the title simply being at a frame cap at full speed, then the GPU (its own
        // reported busy time), then the two host threads that feed it, and last waiting.
        int verdict;
        if (frames < 1.0)
            verdict = 7;
        else if (pipelinesOnGpuThread > 0 && pipelineMs > wallNs / 1e6 * 0.2)
            verdict = 6;
        else if (speedPct >= 97.0 && ios_fps_on_a_cap(guestFps))
            verdict = 1;
        else if (mtlBusy >= 0.85)
            verdict = 2;
        else if (ppcRun >= 0.85)
            verdict = 3;
        else if (gpuThreadBusy >= 0.85)
            verdict = 4;
        else
            verdict = 5;

        auto& summary = PerfTelemetry::GetSummary();
        summary.hostFps.store((float)hostFps, std::memory_order_relaxed);
        summary.guestFps.store((float)guestFps, std::memory_order_relaxed);
        summary.vsyncRate.store((float)vsyncRate, std::memory_order_relaxed);
        summary.ppcExecPct.store((float)(ppcRun * 100.0), std::memory_order_relaxed);
        summary.gpuThreadBusyPct.store((float)(gpuThreadBusy * 100.0), std::memory_order_relaxed);
        summary.mtlGpuMsPerFrame.store((float)mtlMsPerFrame, std::memory_order_relaxed);
        summary.mtlGpuBusyPct.store((float)(mtlBusy * 100.0), std::memory_order_relaxed);
        summary.bottleneck.store(verdict, std::memory_order_relaxed);
        summary.valid.store(true, std::memory_order_relaxed);

        if (logHeader)
        {
            cemuLog_log(LogType::Force, "perf: device {} | emulated cores on {} host thread(s) | async shaders {} | recompiler arena {} MB",
                cemu_bridge_device_summary(), (uint32_t)hostThreads, GetConfig().async_compile.GetValue() ? "on" : "off",
                (uint64_t)(PPCRecompiler_getJitArenaSize() / (1024 * 1024)));
        }
        if (logHeader)
        {
            // Said once per title, next to the arena size, so a log that shows "arena 0 MB" also says why
            std::string cpuDetail = getCpuModeDetail();
            cemuLog_log(LogType::Force, "perf: cpu path {} | {}", g_cpuMode.load() == kCpuModeRecompiler ? "recompiler" : "interpreter", cpuDetail);
        }
        cemuLog_log(LogType::Force,
            "perf {:.0f}s: fps host {:.1f} game {:.1f} vsync {:.1f} (speed {:.0f}%) | ppc thread run {:.0f}% wait {:.0f}% | "
            "gpu thread busy {:.0f}% idle {:.0f}% sync {:.0f}% (drawable {:.0f} ms) | metal gpu {:.1f} ms/frame ({:.0f}% busy, {:.1f} cb/frame) | "
            "compiled shaders {} ({:.0f} ms) pipelines {} ({:.0f} ms, {} on the gpu thread) | texture decodes {} ({:.0f} ms, BC->ASTC {} = {:.0f} ms, {} from cache, {} direct) | "
            "jit blocks {} ({:.0f} ms) invalidated {} arena released {} alloc-failed {} used {}/{} MB | thermal {} | limit: {}",
            dt, hostFps, guestFps, vsyncRate, speedPct, ppcRun * 100.0, ppcWait * 100.0,
            gpuThreadBusy * 100.0, gpuIdle * 100.0, gpuSync * 100.0, (double)(b.drawableWaitNs - a.drawableWaitNs) / 1e6,
            mtlMsPerFrame, mtlBusy * 100.0, cbPerFrame,
            shaders, shaderMs, pipelines, pipelineMs, pipelinesOnGpuThread, textureDecodes, textureDecodeMs, textureTranscodes, textureTranscodeMs, textureTranscodeCacheHits, textureTranscodeDirect,
            jitBlocks, jitMs, b.jitInvalidations - a.jitInvalidations, b.jitArenaReleases - a.jitArenaReleases, b.jitArenaAllocFails - a.jitArenaAllocFails,
            (uint64_t)(PPCRecompiler_getJitArenaUsed() / (1024 * 1024)), (uint64_t)(PPCRecompiler_getJitArenaSize() / (1024 * 1024)),
            ios_thermal_name(thermal), PerfTelemetry::BottleneckName(verdict));

        // Where the GPU thread's busy time went, per emulated frame. begin, execute and end/commit are
        // disjoint; the indented parts are inside execute (textures and hashing inside begin). "other" is
        // the busy time none of them covers (command decoding, register state, shader lookup outside a draw).
        {
            const double perFrame = frames > 0.0 ? 1.0 / (frames * 1e6) : 0.0;
            auto ms = [&](uint64_t x, uint64_t y) { return (double)(x - y) * perFrame; };
            // counts per emulated frame
            auto n = [&](uint32_t x, uint32_t y) { return frames > 0.0 ? (double)(x - y) / frames : 0.0; };
            const double busyMs = gpuThreadBusy * wallNs * perFrame;
            const double beginMs = ms(b.gpuBeginNs, a.gpuBeginNs);
            const double execMs = ms(b.gpuExecNs, a.gpuExecNs);
            const double endMs = ms(b.gpuEndNs, a.gpuEndNs);
            const double otherMs = std::max(0.0, busyMs - beginMs - execMs - endMs);
            const uint32_t draws = b.gpuDraws - a.gpuDraws;
            const double mbPerFrame = frames > 0.0 ? 1.0 / (frames * 1048576.0) : 0.0;
            cemuLog_log(LogType::Force,
                "perf gpu thread ms/frame {:.1f}: draws {:.0f}/frame | begin {:.1f} (textures {:.1f}, hashing {:.1f} = {} textures {:.1f} MB/frame) | "
                "execute {:.1f} (index {:.1f}, flush queue {:.1f}, buffers {:.1f} [compared {:.1f} MB/frame, copied {:.1f} MB/frame], render pass {:.1f}, pipeline {:.1f}, resource bind {:.1f} [sampled 1/8: useResource {:.0f} calls/frame {:.1f} ms, {:.0f} skipped; argument buffers {:.0f} encoded {:.1f} ms, {:.0f} reused {:.1f} ms; sampler lookups {:.0f} {:.1f} ms; texture views {:.0f} {:.1f} ms]) | "
                "arg misses/frame {:.0f} [no base {:.0f}; differing vs latest: support {:.0f} (only {:.0f}), uniform {:.0f}, texture {:.0f}, sampler {:.0f}, vertex/index {:.0f}, constant {:.0f}; delta encodes {:.0f} writing {:.1f} slots each; encode parts ms/frame: alloc {:.1f}, copy+retain+slot {:.1f}, encoder calls {:.1f}, flush {:.1f}] | "
                "bind parts (sampled 1/8) ms/frame [texture loop {:.1f}, support prep {:.1f}, remapped uniforms {:.1f}, support snapshot {:.1f}, uniform loop {:.1f} (shared cache track {:.1f}, breadcrumbs {:.1f}), vertex/index {:.1f}, arg buffer bind {:.1f}, residency lookups {:.1f}, rest {:.1f}] | "
                "end/commit {:.1f} | other {:.1f}",
                busyMs, frames > 0.0 ? draws / frames : 0.0, beginMs, ms(b.gpuTexUpdateNs, a.gpuTexUpdateNs), ms(b.gpuTexHashNs, a.gpuTexHashNs),
                frames > 0.0 ? (uint32_t)((b.gpuTexHashes - a.gpuTexHashes) / frames) : 0u, (double)(b.gpuTexHashBytes - a.gpuTexHashBytes) * mbPerFrame,
                execMs, ms(b.gpuIndexNs, a.gpuIndexNs), ms(b.gpuFlushNs, a.gpuFlushNs), ms(b.gpuBufferNs, a.gpuBufferNs),
                (double)(b.gpuSnapshotCompareBytes - a.gpuSnapshotCompareBytes) * mbPerFrame, (double)(b.gpuSnapshotCopyBytes - a.gpuSnapshotCopyBytes) * mbPerFrame,
                ms(b.gpuPassNs, a.gpuPassNs), ms(b.gpuPipelineNs, a.gpuPipelineNs), ms(b.gpuBindNs, a.gpuBindNs),
                n(b.gpuUseResourceCalls, a.gpuUseResourceCalls), ms(b.gpuUseResourceNs, a.gpuUseResourceNs), n(b.gpuUseResourceSkips, a.gpuUseResourceSkips),
                n(b.gpuArgEncodes, a.gpuArgEncodes), ms(b.gpuArgEncodeNs, a.gpuArgEncodeNs), n(b.gpuArgReuses, a.gpuArgReuses), ms(b.gpuArgReuseNs, a.gpuArgReuseNs),
                n(b.gpuSamplerLookups, a.gpuSamplerLookups), ms(b.gpuSamplerLookupNs, a.gpuSamplerLookupNs),
                n(b.gpuTexViewLookups, a.gpuTexViewLookups), ms(b.gpuTexViewLookupNs, a.gpuTexViewLookupNs),
                n(b.gpuArgEncodes, a.gpuArgEncodes),
                n(b.gpuArgMissNoBase, a.gpuArgMissNoBase), n(b.gpuArgMissSupport, a.gpuArgMissSupport), n(b.gpuArgMissSupportOnly, a.gpuArgMissSupportOnly),
                n(b.gpuArgMissUniform, a.gpuArgMissUniform), n(b.gpuArgMissTexture, a.gpuArgMissTexture), n(b.gpuArgMissSampler, a.gpuArgMissSampler),
                n(b.gpuArgMissVertexIndex, a.gpuArgMissVertexIndex), n(b.gpuArgMissConstant, a.gpuArgMissConstant),
                n(b.gpuArgDeltaEncodes, a.gpuArgDeltaEncodes),
                b.gpuArgDeltaEncodes != a.gpuArgDeltaEncodes ? (double)(b.gpuArgDeltaSlots - a.gpuArgDeltaSlots) / (double)(b.gpuArgDeltaEncodes - a.gpuArgDeltaEncodes) : 0.0,
                ms(b.gpuArgEncAllocNs, a.gpuArgEncAllocNs), ms(b.gpuArgEncCopyNs, a.gpuArgEncCopyNs), ms(b.gpuArgEncSetNs, a.gpuArgEncSetNs), ms(b.gpuArgEncFlushNs, a.gpuArgEncFlushNs),
                ms(b.gpuBindTextureLoopNs, a.gpuBindTextureLoopNs), ms(b.gpuBindSupportPrepNs, a.gpuBindSupportPrepNs), ms(b.gpuBindRemappedNs, a.gpuBindRemappedNs),
                ms(b.gpuBindSnapshotNs, a.gpuBindSnapshotNs), ms(b.gpuBindUniformLoopNs, a.gpuBindUniformLoopNs), ms(b.gpuBindTrackNs, a.gpuBindTrackNs),
                ms(b.gpuBindCrumbNs, a.gpuBindCrumbNs), ms(b.gpuBindVertexNs, a.gpuBindVertexNs), ms(b.gpuBindFinalNs, a.gpuBindFinalNs),
                ms(b.gpuBindResidencyNs, a.gpuBindResidencyNs),
                std::max(0.0, ms(b.gpuBindNs, a.gpuBindNs) - ms(b.gpuBindTextureLoopNs, a.gpuBindTextureLoopNs) - ms(b.gpuBindSupportPrepNs, a.gpuBindSupportPrepNs) -
                    ms(b.gpuBindRemappedNs, a.gpuBindRemappedNs) - ms(b.gpuBindSnapshotNs, a.gpuBindSnapshotNs) - ms(b.gpuBindUniformLoopNs, a.gpuBindUniformLoopNs) -
                    ms(b.gpuBindVertexNs, a.gpuBindVertexNs) - ms(b.gpuBindFinalNs, a.gpuBindFinalNs)),
                endMs, otherMs);
        }

        char line[200];
        snprintf(line, sizeof(line), "host %.1f game %.1f fps | ppc %.0f%% gpu thread %.0f%% metal %.1f ms | %s%s",
            hostFps, guestFps, ppcRun * 100.0, gpuThreadBusy * 100.0, mtlMsPerFrame, PerfTelemetry::BottleneckName(verdict),
            g_cpuMode.load() == kCpuModeRecompiler ? "" : (g_recompilerRequested.load() ? " | interpreter (no JIT enabler)" : " | interpreter (recompiler off)"));
        std::lock_guard<std::mutex> lock(g_perfLineMutex);
        g_perfLine = line;
    }

    std::atomic<bool> g_perfRunning{false};

    void ios_perf_start()
    {
        if (g_perfRunning.exchange(true))
            return;
        std::thread([] {
            constexpr double kWindowSeconds = 5.0;
            PerfSnapshot baseline;
            bool haveBaseline = false;
            bool headerLogged = false;
            while (g_perfRunning.load())
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(500));
                if (!g_titleRunning.load() || IOSTitlePause_IsPaused())
                {
                    haveBaseline = false;
                    headerLogged = false;
                    PerfTelemetry::GetSummary().valid.store(false, std::memory_order_relaxed);
                    continue;
                }
                if (!haveBaseline)
                {
                    baseline = ios_perf_take();
                    haveBaseline = true;
                    continue;
                }
                const PerfSnapshot now = ios_perf_take();
                if (std::chrono::duration<double>(now.at - baseline.at).count() < kWindowSeconds)
                    continue;
                ios_perf_log_window(baseline, now, !headerLogged);
                headerLogged = true;
                baseline = now;
            }
        }).detach();
    }
}

// ---------------------------------------------------------------------------
// Render-stall watchdog
//
// The game's audio and input run on the guest CPU, the picture on the GPU thread, and the
// two are not tied together (the speed setting "Full sync at GX2DrawDone" is off), so the
// GPU side can stop while everything else carries on. Whether the picture is really frozen
// is decided by StallDetector.h (pure logic, unit tested in ci/stall-detector-test.cpp); this
// file only reads the live counters into a Sample every 250 ms and acts on the answer.
//
// In short: a command buffer error that iOS answers by ignoring this app's GPU work is shown at
// once; anything heuristic (the GPU not finishing work, the screen not taking frames, a GPU
// thread with no progress) has to hold for a whole window and survive a second look; a game
// that simply stops sending GPU work (loading, a game-side hang) is logged and never shown as
// a video freeze; and a raised card is dismissed by itself when progress resumes. Every log
// line names the rule, the measured values and the thresholds (see StallDetector.h).
namespace {
    std::atomic<bool> g_videoStalled{false};
    // 0 none, 1 GPU stopped finishing frames, 2 GPU fault, 3 screen out of memory, 4 low memory
    // warning, 5 screen stopped taking frames (StallDetect::Kind)
    std::atomic<int> g_videoStallKind{0};
    std::atomic<bool> g_stallWatchRunning{false};
    std::atomic<bool> g_appIsActive{true};
    // Bumped whenever a title starts, ends or is replaced; the watchdog thread then starts judging afresh.
    std::atomic<uint32_t> g_stallResetGen{0};

    // Set when something makes starting another title in this process unsafe: a GPU that stopped doing this app's work, or
    // emulator state that the check at the end of every title stop found still alive. Nothing clears it except an app
    // restart (iOS does not let an app relaunch itself), so the UI shows "close and reopen" on the next launch attempt
    // instead of starting a game that is likely to fault. It is never set routinely: a normal stop leaves it alone.
    std::atomic<bool> g_cleanStartRequired{false};
    std::mutex g_cleanStartMutex;
    std::string g_cleanStartReason;

    void ios_require_clean_start(const std::string& reason)
    {
        std::lock_guard<std::mutex> lock(g_cleanStartMutex);
        if (g_cleanStartRequired.load())
            return; // the first reason is the one worth showing
        g_cleanStartReason = reason;
        g_cleanStartRequired.store(true);
        cemuLog_log(LogType::Force, "clean slate: a clean start is needed before the next title: {}", reason);
    }

    // The GPU-fault latches describe the renderer that is about to be replaced and are cleared right after, so they are
    // read first. A latched fault is the kind iOS answers by ignoring this app's GPU work: a new renderer gets a new command
    // queue, but nothing proves the device accepts it, and a game started on top of that shows nothing or faults again.
    void ios_note_gpu_fault_before_reset()
    {
        auto& w = LatteWait::Get();
        if (w.gpuError.load())
            ios_require_clean_start("the GPU stopped running this app's work (error code " + std::to_string((int)w.gpuErrorCode.load()) + ") during the last game");
        else if (w.gpuPresumedLost.load())
            ios_require_clean_start("the GPU stopped responding during the last game");
    }

    // Runs after every title stop (the stop button, a game that exits, the Wii U Menu switching to a game): if the check in
    // CafeSystem::ShutdownTitle() found anything that is unsafe to start another title on, a clean start is needed.
    void ios_check_clean_slate_after_stop()
    {
        if (!CafeSystem::CleanSlateHasDangerousLeftover())
            return;
        const std::vector<std::string> leftovers = CafeSystem::GetCleanSlateLeftovers();
        std::string reason = "the emulator could not fully reset after the last game";
        if (!leftovers.empty())
        {
            reason += " (" + leftovers.front();
            if (leftovers.size() > 1)
                reason += " and " + std::to_string(leftovers.size() - 1) + " more";
            reason += ")";
        }
        ios_require_clean_start(reason);
    }

    // Clears the stall flag, the stall kind and the GPU-fault state (a failed command buffer, a
    // presumed-lost GPU, the drawable-failure count). Used when a title starts or ends and when a
    // title switch replaces the renderer: those flags describe the renderer that is being thrown
    // away, and left set they would make the watchdog report the new title as stalled, or as
    // GPU-faulted, before it has drawn a frame.
    void ios_reset_video_stall_state()
    {
        ios_note_gpu_fault_before_reset();
        g_videoStalled.store(false);
        g_videoStallKind.store(0);
        auto& w = LatteWait::Get();
        w.gpuError.store(false);
        w.gpuErrorCode.store(0);
        w.gpuPresumedLost.store(false);
        w.memStatsValid.store(false);
        w.drawableFailuresInARow.store(0);
        w.cbErrorStreak.store(0);
        g_stallResetGen.fetch_add(1);
    }

    // Windows get longer when iOS is throttling the device: a hot device legitimately runs slowly.
    double ios_stall_thermal_scale(int* stateOut)
    {
        const NSInteger state = [[NSProcessInfo processInfo] thermalState];
        if (stateOut)
            *stateOut = (int)state;
        switch (state)
        {
        case NSProcessInfoThermalStateSerious: return 1.5;
        case NSProcessInfoThermalStateCritical: return 2.0;
        default: return 1.0;
        }
    }

    StallDetect::Sample ios_stall_make_sample(int* thermalState)
    {
        auto& w = LatteWait::Get();
        auto& info = WindowSystem::GetWindowInfo();
        StallDetect::Sample s;
        s.nowMs = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();
        s.titleRunning = g_titleRunning.load() && CafeSystem::IsTitleRunning() && !CafeSystem::IsTitleSwitchInProgress();
        s.gx2Init = LatteGPUState.gx2InitCalled > 0;
        s.paused = IOSTitlePause_IsPaused();
        s.appActive = g_appIsActive.load();
        uint32_t stamp = 17;
        for (uint32_t v : { (uint32_t)(int)info.width, (uint32_t)(int)info.height, (uint32_t)(int)info.phys_width, (uint32_t)(int)info.phys_height,
                            (uint32_t)((double)info.dpi_scale.load() * 100.0), (uint32_t)info.visible_outputs.load() })
            stamp = stamp * 31u + v;
        s.layoutStamp = stamp;
        s.windowScale = ios_stall_thermal_scale(thermalState);
        s.frames = LatteGPUState.frameCounter;
        s.presented = w.presentedFrames.load();
        s.drawableFailures = w.drawableFailures.load();
        s.drawableFailuresInARow = w.drawableFailuresInARow.load();
        s.cbRetired = w.cbRetired.load();
        s.cbErrorStreak = w.cbErrorStreak.load();
        s.pm4 = w.pm4Count.load();
        s.draws = (uint32_t)LatteGPUState.drawCallCounter;
        s.flipRequests = (uint32_t)LatteGPUState.flipRequestCount.load();
        s.evictionPasses = w.evictionPasses.load();
        s.gpuError = w.gpuError.load();
        s.gpuErrorCode = w.gpuErrorCode.load();
        s.lastCbErrorCode = w.cbLastErrorCode.load();
        s.gpuPresumedLost = w.gpuPresumedLost.load();
        s.waitClass = w.reason.load() ? (StallDetect::WaitClass)w.reasonKind.load() : StallDetect::WaitClass::None;
        // The limit jetsam enforces on this process, from what it has left plus what it holds, capped by the
        // device's RAM. Memory thresholds are fractions of it, so they fit a 3 GB iPhone and a 6 GB iPad alike.
        static uint64_t s_memLimitBytes = 0;
        const uint64_t availBytes = (uint64_t)os_proc_available_memory();
        if (availBytes != 0)
        {
            uint64_t limit = availBytes + cemu_mem_footprint_bytes();
            static const uint64_t physBytes = cemu_sysctl_u64("hw.memsize");
            if (physBytes != 0 && limit > physBytes)
                limit = physBytes;
            if (limit > s_memLimitBytes)
                s_memLimitBytes = limit;
        }
        s.availMemMB = (uint32_t)(availBytes >> 20);
        s.memLimitMB = availBytes != 0 ? (uint32_t)(s_memLimitBytes >> 20) : 0;
        return s;
    }

    void ios_stall_log_snapshot(const StallDetect::Sample& s, int thermalState)
    {
        auto& w = LatteWait::Get();
        const char* reason = w.reason.load();
        const int64_t reasonMs = reason ? (LatteWait::NowMs() - w.reasonSinceMs.load()) : 0;
        const char* lastTimeout = w.lastTimeoutReason.load();
        auto& info = WindowSystem::GetWindowInfo();

        char surface[640];
        CemuUIKit_DescribeMainSurface(surface, sizeof(surface));

        if (reason)
            cemuLog_log(LogType::Force, "VIDEO STALL: GPU thread is blocked: {} (for {} ms, class {})", reason, reasonMs, StallDetect::WaitName(s.waitClass));
        else
            cemuLog_log(LogType::Force, "VIDEO STALL: GPU thread is not in a known wait (it is running, or stuck somewhere without a breadcrumb)");
        cemuLog_log(LogType::Force, "VIDEO STALL: frame {}, flips {}, draw calls {}, last PM4 opcode 0x{:02x}, GPU packets {}, guest flip requests {}, GX2Init calls {}",
            (uint32)LatteGPUState.frameCounter, (uint32)LatteGPUState.flipCounter, (uint32)LatteGPUState.drawCallCounter,
            w.lastPM4Opcode.load(), w.pm4Count.load(), (uint64)LatteGPUState.flipRequestCount.load(), (uint32)LatteGPUState.gx2InitCalled);
        cemuLog_log(LogType::Force, "VIDEO STALL: pending: {} occlusion queries, {} texture readbacks, {} command buffers on the GPU (submitted {}, finished {}, failed {}, failing in a row {}, last error code {})",
            w.queriesInFlight.load(), w.readbacksPending.load(), w.executingCommandBuffers.load(), w.cbSubmitted.load(), w.cbRetired.load(),
            w.erroredCommandBuffers.load(), w.cbErrorStreak.load(), w.cbLastErrorCode.load());
        cemuLog_log(LogType::Force, "VIDEO STALL: waits that gave up: {} (last: {}), GPU presumed lost: {}",
            w.timeouts.load(), lastTimeout ? lastTimeout : "none", w.gpuPresumedLost.load() ? "yes" : "no");
        cemuLog_log(LogType::Force, "VIDEO STALL: presented frames {}, TV drawable held: {}, drawable failures {} ({} in a row), TV drawable size {}x{}, layer device {}",
            w.presentedFrames.load(), w.tvDrawableHeld.load() ? "yes" : "no", w.drawableFailures.load(), w.drawableFailuresInARow.load(),
            w.tvDrawableWidth.load(), w.tvDrawableHeight.load(), w.tvLayerHasDevice.load() ? "set" : "unknown/missing");
        cemuLog_log(LogType::Force, "VIDEO STALL: free memory {} MB of a {} MB process limit, thermal state {} (x{:.1f}), app active {}, paused {}",
            s.availMemMB, s.memLimitMB, thermalState, s.windowScale, s.appActive ? "yes" : "no", s.paused ? "yes" : "no");
        cemuLog_log(LogType::Force, "VIDEO STALL: window {}x{} points at {:.2f}x scale ({}x{} px), visible outputs mask {}",
            (int)info.width, (int)info.height, (double)info.dpi_scale.load(), (int)info.phys_width, (int)info.phys_height, (uint32)info.visible_outputs.load());
        cemuLog_log(LogType::Force, "VIDEO STALL: TV view: {}", surface);
    }

    void ios_stall_log_decision(const StallDetect::Decision& d, const StallDetect::Sample& s, int thermalState)
    {
        using StallDetect::Action;
        switch (d.action)
        {
        case Action::Suspect:
            cemuLog_log(LogType::Force, "VIDEO STALL: suspected (not shown yet) - {}", d.text);
            break;
        case Action::SuspectDropped:
            cemuLog_log(LogType::Force, "VIDEO STALL: suspicion dropped - {}", d.text);
            break;
        case Action::Raise:
            cemuLog_log(LogType::Force, "VIDEO STALL: card shown (kind {}) - {}", (int)d.kind, d.text);
            ios_stall_log_snapshot(s, thermalState);
            break;
        case Action::Clear:
            cemuLog_log(LogType::Force, "VIDEO STALL: card dismissed - {}", d.text);
            break;
        case Action::GuestNote:
            cemuLog_log(LogType::Force, "VIDEO STALL: not a video freeze - {}", d.text);
            break;
        default:
            break;
        }
    }

    void ios_stall_watchdog_start()
    {
        if (g_stallWatchRunning.exchange(true))
            return;

        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidEnterBackgroundNotification object:nil queue:nil
            usingBlock:^(NSNotification*) { g_appIsActive.store(false); PerfTelemetry::AppInBackground().store(true); }];
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillResignActiveNotification object:nil queue:nil
            usingBlock:^(NSNotification*) { g_appIsActive.store(false); }];
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationDidBecomeActiveNotification object:nil queue:nil
            usingBlock:^(NSNotification*) { g_appIsActive.store(true); PerfTelemetry::AppInBackground().store(false); }];
        [[NSNotificationCenter defaultCenter] addObserverForName:UIApplicationWillEnterForegroundNotification object:nil queue:nil
            usingBlock:^(NSNotification*) { PerfTelemetry::AppInBackground().store(false); }];

        std::thread([] {
            StallDetect::Detector detector;
            uint32_t seenResetGen = g_stallResetGen.load();
            int64_t lastStillLogMs = 0;
            while (g_stallWatchRunning.load())
            {
                std::this_thread::sleep_for(std::chrono::milliseconds(250));

                int thermalState = 0;
                const StallDetect::Sample sample = ios_stall_make_sample(&thermalState);
                const uint32_t resetGen = g_stallResetGen.load();
                if (resetGen != seenResetGen)
                {
                    seenResetGen = resetGen;
                    detector.Reset(sample.nowMs, true);
                }

                const StallDetect::Decision stallDecision = detector.Update(sample);
                ios_stall_log_decision(stallDecision, sample, thermalState);
                const StallDetect::Decision memoryDecision = detector.UpdateMemory(sample);
                ios_stall_log_decision(memoryDecision, sample, thermalState);

                const int kind = (int)detector.kind();
                g_videoStallKind.store(kind);
                g_videoStalled.store(kind != 0);

                if (detector.stallRaised())
                {
                    if (lastStillLogMs == 0 || stallDecision.action == StallDetect::Action::Raise)
                        lastStillLogMs = sample.nowMs;
                    else if (sample.nowMs - lastStillLogMs >= 15000)
                    {
                        lastStillLogMs = sample.nowMs;
                        const char* reason = LatteWait::Get().reason.load();
                        cemuLog_log(LogType::Force, "VIDEO STALL: rule={} still in effect after {:.0f} s ({})", StallDetect::RuleName(detector.rule()),
                            (double)(sample.nowMs - detector.raisedAtMs()) / 1000.0, reason ? reason : "no known wait");
                    }
                }
                else
                {
                    lastStillLogMs = 0;
                }
            }
        }).detach();
    }
}

bool cemu_bridge_video_stalled(void) {
    return g_videoStalled.load();
}

int cemu_bridge_video_stall_kind(void) {
    return g_videoStalled.load() ? g_videoStallKind.load() : 0;
}

// ---------------------------------------------------------------------------
// Input
//
// One emulated GamePad fed from two sources at once: the on-screen pad (set from Swift)
// and the first physical GameController. Both are merged inside one GCBridge controller
// registered with the core's input manager, so the touch pad and an MFi controller work
// together and neither cancels the other. A button is down if either source holds it; a
// stick follows the touch pad while it is deflected and hands back to the physical stick
// at centre.
//
// Bit layout is the core's (src/input/api/iOS/GCController.mm), which its default VPAD
// mapping in InputManager.cpp binds to the GamePad buttons.
namespace {
    constexpr int kBitA = 0, kBitB = 1, kBitX = 2, kBitY = 3;
    constexpr int kBitL = 4, kBitR = 5, kBitZL = 6, kBitZR = 7;
    constexpr int kBitMinus = 8, kBitPlus = 9, kBitStickL = 10, kBitStickR = 11;
    constexpr int kBitUp = 16, kBitDown = 17, kBitLeft = 18, kBitRight = 19;

    std::mutex g_inputMutex;
    uint32_t g_touchButtons = 0;

    // Press latching for the on-screen pad. The core only looks at g_touchButtons when the
    // title calls VPADRead, which on a slow-running title can be 100ms or more apart in real
    // time - longer than an ordinary tap. A tap that went down and up between two reads was
    // never seen, which is why presses only registered when the finger was dragged (and so
    // held for longer). A released button now stays down until at least one read has seen
    // it AND kMinTouchHold has passed, then the release is applied on a later read.
    //
    // A second press that lands while the first is still being held back (mashing a
    // button) must not merge into one long press, or the title sees one press instead of
    // two. If a read has already seen the first press, the second is queued: the release
    // goes out on one read and the new press on the next.
    constexpr auto kMinTouchHold = std::chrono::milliseconds(50);
    uint32_t g_touchSeen = 0;            // pressed bits a poll has reported since the press
    uint32_t g_touchPendingRelease = 0;  // released by the finger, not yet by the latch
    uint32_t g_touchRepress = 0;         // pressed again while a release was pending
    uint32_t g_touchRepressQueued = 0;   // re-presses to apply at the next poll
    uint32_t g_touchRepressReleased = 0; // re-presses whose finger has already lifted
    std::chrono::steady_clock::time_point g_touchPressedAt[32] = {};

    bool ios_touch_release_due(int bit, std::chrono::steady_clock::time_point now)
    {
        return (g_touchSeen & (1u << bit)) && now - g_touchPressedAt[bit] >= kMinTouchHold;
    }
    GCBridgeVec2 g_touchSticks[2] = {};
    uint32_t g_physicalButtons = 0;
    GCBridgeVec2 g_physicalSticks[2] = {};
    float g_physicalTriggers[2] = {};

    void* g_inputHandle = nullptr;
    GCController* g_boundController = nil;
    bool g_homeWarned = false;

    // The controller's own HOME / guide button and the app's menus. HOME never reaches the game (the core's GamePad
    // mapping has no HOME bit); it is reported to the app instead. While menu capture is on, the same controller also
    // drives the app's menu: the game sees nothing and four more events (up, down, A, B) are reported.
    std::atomic<CemuMenuInputCallback> g_menuCallback{nullptr};
    std::atomic<bool> g_menuCapture{false};
    // Bits held when capture ended (or while it is on), still ignored by the game until let go. Under g_inputMutex.
    uint32_t g_physicalSuppress = 0;
    // Main thread only, in ios_update_physical: what was held at the last update, to find the new presses.
    constexpr uint32_t kMenuUp = 1u << 0, kMenuDown = 1u << 1, kMenuConfirm = 1u << 2, kMenuBack = 1u << 3;
    constexpr float kMenuStickThreshold = 0.6f;
    uint32_t g_menuHeld = 0;
    bool g_homeHeld = false;

    int ios_button_bit(CemuBridgeButton button)
    {
        switch (button)
        {
        case CEMU_BRIDGE_BUTTON_A: return kBitA;
        case CEMU_BRIDGE_BUTTON_B: return kBitB;
        case CEMU_BRIDGE_BUTTON_X: return kBitX;
        case CEMU_BRIDGE_BUTTON_Y: return kBitY;
        case CEMU_BRIDGE_BUTTON_L: return kBitL;
        case CEMU_BRIDGE_BUTTON_R: return kBitR;
        case CEMU_BRIDGE_BUTTON_ZL: return kBitZL;
        case CEMU_BRIDGE_BUTTON_ZR: return kBitZR;
        case CEMU_BRIDGE_BUTTON_PLUS: return kBitPlus;
        case CEMU_BRIDGE_BUTTON_MINUS: return kBitMinus;
        case CEMU_BRIDGE_BUTTON_UP: return kBitUp;
        case CEMU_BRIDGE_BUTTON_DOWN: return kBitDown;
        case CEMU_BRIDGE_BUTTON_LEFT: return kBitLeft;
        case CEMU_BRIDGE_BUTTON_RIGHT: return kBitRight;
        case CEMU_BRIDGE_BUTTON_STICK_L: return kBitStickL;
        case CEMU_BRIDGE_BUTTON_STICK_R: return kBitStickR;
        default: return -1;
        }
    }

    GCBridgeControllerState ios_poll_state(void* context)
    {
        (void)context;
        std::lock_guard lock(g_inputMutex);
        const auto now = std::chrono::steady_clock::now();
        // Re-presses queued by the previous poll, which reported their release.
        if (g_touchRepressQueued)
        {
            for (int bit = 0; bit < 32; ++bit)
                if (g_touchRepressQueued & (1u << bit))
                    g_touchPressedAt[bit] = now;
            g_touchButtons |= g_touchRepressQueued;
            g_touchSeen &= ~g_touchRepressQueued;
            g_touchPendingRelease |= g_touchRepressReleased & g_touchRepressQueued;
            g_touchRepressReleased &= ~g_touchRepressQueued;
            g_touchRepressQueued = 0;
        }
        // Apply releases the latch was holding back, but only ones an EARLIER poll already
        // reported, so the poll that first sees a press still reports it.
        if (g_touchPendingRelease)
        {
            for (int bit = 0; bit < 32; ++bit)
            {
                const uint32_t mask = 1u << bit;
                if ((g_touchPendingRelease & mask) && ios_touch_release_due(bit, now))
                {
                    g_touchButtons &= ~mask;
                    g_touchPendingRelease &= ~mask;
                    g_touchSeen &= ~mask;
                    if (g_touchRepress & mask)
                    {
                        g_touchRepress &= ~mask;
                        g_touchRepressQueued |= mask;
                    }
                }
            }
        }
        GCBridgeControllerState s{};
        s.buttons = g_touchButtons | g_physicalButtons;
        g_touchSeen |= g_touchButtons;
        for (int i = 0; i < 2; i++)
        {
            const GCBridgeVec2& touch = g_touchSticks[i];
            const GCBridgeVec2 chosen = (touch.x != 0.0f || touch.y != 0.0f) ? touch : g_physicalSticks[i];
            (i == 0 ? s.leftStick : s.rightStick) = chosen;
        }
        s.leftTrigger = std::max(g_physicalTriggers[0], (g_touchButtons & (1u << kBitZL)) ? 1.0f : 0.0f);
        s.rightTrigger = std::max(g_physicalTriggers[1], (g_touchButtons & (1u << kBitZR)) ? 1.0f : 0.0f);
        return s;
    }

    // The GamePad's motion: the device's own sensors (or a controller's), see IOSMotion.mm. The sample is
    // already in the convention the core's motion handler expects, so it passes straight through.
    GCBridgeMotionState ios_poll_motion(void* context)
    {
        (void)context;
        IOSMotionSample sample;
        IOSMotion_Poll(&sample);
        GCBridgeMotionState s{};
        s.accelerometer = GCBridgeVec3{sample.accelerometer[0], sample.accelerometer[1], sample.accelerometer[2]};
        s.gyroscope = GCBridgeVec3{sample.gyroscope[0], sample.gyroscope[1], sample.gyroscope[2]};
        s.timestamp = sample.timestamp;
        s.recenterCount = sample.recenterCount;
        return s;
    }

    void ios_update_physical(GCExtendedGamepad* pad)
    {
        uint32_t buttons = 0;
        auto bit = [&](BOOL pressed, int b) { if (pressed) buttons |= (1u << b); };
        bit(pad.buttonA.isPressed, kBitA);
        bit(pad.buttonB.isPressed, kBitB);
        bit(pad.buttonX.isPressed, kBitX);
        bit(pad.buttonY.isPressed, kBitY);
        bit(pad.leftShoulder.isPressed, kBitL);
        bit(pad.rightShoulder.isPressed, kBitR);
        bit(pad.leftTrigger.isPressed, kBitZL);
        bit(pad.rightTrigger.isPressed, kBitZR);
        bit(pad.buttonOptions ? pad.buttonOptions.isPressed : NO, kBitMinus);
        bit(pad.buttonMenu.isPressed, kBitPlus);
        bit(pad.leftThumbstickButton ? pad.leftThumbstickButton.isPressed : NO, kBitStickL);
        bit(pad.rightThumbstickButton ? pad.rightThumbstickButton.isPressed : NO, kBitStickR);
        bit(pad.dpad.up.isPressed, kBitUp);
        bit(pad.dpad.down.isPressed, kBitDown);
        bit(pad.dpad.left.isPressed, kBitLeft);
        bit(pad.dpad.right.isPressed, kBitRight);

        // What the app's menus see. Tracked on every update, capture or not, so turning capture on while a button is
        // held does not report that button as a fresh press.
        const bool capture = g_menuCapture.load();
        const float stickY = pad.leftThumbstick.yAxis.value;
        uint32_t menuNow = 0;
        if (pad.dpad.up.isPressed || stickY > kMenuStickThreshold) menuNow |= kMenuUp;
        if (pad.dpad.down.isPressed || stickY < -kMenuStickThreshold) menuNow |= kMenuDown;
        if (pad.buttonA.isPressed) menuNow |= kMenuConfirm;
        if (pad.buttonB.isPressed) menuNow |= kMenuBack;
        const uint32_t menuNew = menuNow & ~g_menuHeld;
        g_menuHeld = menuNow;
        const bool homeNow = pad.buttonHome ? pad.buttonHome.isPressed : NO;
        const bool homeNew = homeNow && !g_homeHeld;
        g_homeHeld = homeNow;

        {
            std::lock_guard lock(g_inputMutex);
            if (capture)
            {
                g_physicalSuppress = buttons;
                g_physicalButtons = 0;
                g_physicalSticks[0] = g_physicalSticks[1] = GCBridgeVec2{};
                g_physicalTriggers[0] = g_physicalTriggers[1] = 0.0f;
            }
            else
            {
                g_physicalSuppress &= buttons;
                g_physicalButtons = buttons & ~g_physicalSuppress;
                g_physicalSticks[0] = GCBridgeVec2{pad.leftThumbstick.xAxis.value, pad.leftThumbstick.yAxis.value};
                g_physicalSticks[1] = GCBridgeVec2{pad.rightThumbstick.xAxis.value, pad.rightThumbstick.yAxis.value};
                g_physicalTriggers[0] = (g_physicalSuppress & (1u << kBitZL)) ? 0.0f : pad.leftTrigger.value;
                g_physicalTriggers[1] = (g_physicalSuppress & (1u << kBitZR)) ? 0.0f : pad.rightTrigger.value;
            }
        }

        if (CemuMenuInputCallback callback = g_menuCallback.load())
        {
            if (homeNew)
                callback(CEMU_BRIDGE_MENU_HOME);
            if (capture)
            {
                if (menuNew & kMenuUp) callback(CEMU_BRIDGE_MENU_UP);
                if (menuNew & kMenuDown) callback(CEMU_BRIDGE_MENU_DOWN);
                if (menuNew & kMenuConfirm) callback(CEMU_BRIDGE_MENU_CONFIRM);
                if (menuNew & kMenuBack) callback(CEMU_BRIDGE_MENU_BACK);
            }
        }
    }

    void ios_clear_physical()
    {
        g_menuHeld = 0;
        g_homeHeld = false;
        std::lock_guard lock(g_inputMutex);
        g_physicalButtons = 0;
        g_physicalSuppress = 0;
        g_physicalSticks[0] = g_physicalSticks[1] = GCBridgeVec2{};
        g_physicalTriggers[0] = g_physicalTriggers[1] = 0.0f;
    }

    // Main thread only - GameController objects are not thread-safe.
    void ios_bind_first_controller()
    {
        if (g_boundController)
            return;
        for (GCController* controller in [GCController controllers])
        {
            GCExtendedGamepad* pad = controller.extendedGamepad;
            if (!pad)
                continue;
            g_boundController = controller;
            // HOME is the app's while a game is up (it opens the in-game menu). Left alone, iOS keeps the button for
            // itself and the app never hears it.
            if (pad.buttonHome)
                pad.buttonHome.preferredSystemGestureState = GCSystemGestureStateDisabled;
            pad.valueChangedHandler = ^(GCExtendedGamepad* gamepad, GCControllerElement* element) {
                (void)element;
                ios_update_physical(gamepad);
            };
            ios_update_physical(pad);
            cemuLog_log(LogType::Force, "iOS input: physical controller bound to the GamePad: {}",
                controller.vendorName ? controller.vendorName.UTF8String : "MFi controller");
            return;
        }
    }

    void ios_input_start()
    {
        if (g_inputHandle)
            return;
        GCBridgeControllerDesc desc{};
        desc.context = nullptr;
        desc.display_name = "Muffin GamePad";
        desc.controllerType = (uint8)EmulatedController::Type::VPAD;
        desc.poll_state = ios_poll_state;
        desc.poll_motion = ios_poll_motion;
        desc.rumble = nullptr;
        desc.release = nullptr;
        g_inputHandle = GCControllerBridge_add(&desc);
        if (!g_inputHandle)
        {
            cemu_bridge_log_checkpoint("iOS input: the core's GameController provider refused the GamePad - no input will reach titles");
            return;
        }
        GCControllerBridge_notifyChanged();
        IOSMotion_Start();
        cemu_bridge_log_checkpoint("iOS input: GamePad registered with the core (on-screen pad + first physical controller)");

        dispatch_async(dispatch_get_main_queue(), ^{
            NSNotificationCenter* center = [NSNotificationCenter defaultCenter];
            [center addObserverForName:GCControllerDidConnectNotification object:nil queue:[NSOperationQueue mainQueue]
                            usingBlock:^(NSNotification* note) { (void)note; ios_bind_first_controller(); }];
            [center addObserverForName:GCControllerDidDisconnectNotification object:nil queue:[NSOperationQueue mainQueue]
                            usingBlock:^(NSNotification* note) {
                                if (note.object == g_boundController)
                                {
                                    g_boundController = nil;
                                    ios_clear_physical();
                                    ios_bind_first_controller();
                                }
                            }];
            ios_bind_first_controller();
        });
    }

    UIWindow* ios_key_window()
    {
        for (UIScene* scene in [UIApplication sharedApplication].connectedScenes)
        {
            if (![scene isKindOfClass:[UIWindowScene class]])
                continue;
            for (UIWindow* window in ((UIWindowScene*)scene).windows)
                if (window.isKeyWindow)
                    return window;
        }
        return nil;
    }
}

// ---------------------------------------------------------------------------
// Shader cache maintenance
namespace {

// Both caches name files with the title id as 16 lowercase hex digits.
bool IOSShaderCacheFileMatches(const std::filesystem::path& file, unsigned long long titleId)
{
    if (titleId == 0)
        return true;
    char prefix[32];
    snprintf(prefix, sizeof(prefix), "%016llx", titleId);
    return file.filename().string().rfind(prefix, 0) == 0;
}

long long IOSShaderCacheSweep(const std::filesystem::path& dir, unsigned long long titleId, bool deleteThem)
{
    namespace sfs = std::filesystem;
    std::error_code ec;
    if (!sfs::exists(dir, ec))
        return 0;
    long long bytes = 0;
    for (auto& entry : sfs::directory_iterator(dir, ec))
    {
        if (ec)
            break;
        if (!entry.is_regular_file(ec))
            continue;
        if (!IOSShaderCacheFileMatches(entry.path(), titleId))
            continue;
        std::error_code sizeEc;
        const auto size = sfs::file_size(entry.path(), sizeEc);
        if (sizeEc)
            continue;
        if (deleteThem)
        {
            std::error_code rmEc;
            if (!sfs::remove(entry.path(), rmEc) || rmEc)
                continue;
        }
        bytes += (long long)size;
    }
    return bytes;
}

} // namespace

long long cemu_bridge_clear_shader_cache(unsigned long long titleId, bool includeLearned) {
    // Refused while a title runs: both caches are open and would be rewritten on close.
    if (cemu_bridge_is_title_running()) {
        cemuLog_log(LogType::Force, "Shader cache: refusing to clear while a title is running");
        return -1;
    }
    long long freed = IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/precompiled"), titleId, true);
    // the Vulkan driver's own pipeline cache is compiled output too (VulkanRenderer::PipelineCacheSaveThread)
    freed += IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/driver/vk"), titleId, true);
    if (includeLearned)
    {
        freed += IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/transferable"), titleId, true);
        // and the guard's backups of them (LatteShaderCache.cpp), or the next start would restore what was just cleared
        freed += IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/backup"), titleId, true);
    }
    cemuLog_log(LogType::Force, "Shader cache: cleared {} bytes ({})", freed, includeLearned ? "compiled and learned" : "compiled only");
    return freed;
}

int cemu_bridge_shader_cache_stats(unsigned long long titleId, long long* outLearnedBytes, long long* outCompiledBytes) {
    if (outLearnedBytes)
        *outLearnedBytes = IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/transferable"), titleId, false);
    if (outCompiledBytes)
        *outCompiledBytes = IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/precompiled"), titleId, false)
            + IOSShaderCacheSweep(ActiveSettings::GetCachePath("shaderCache/driver/vk"), titleId, false);
    return 0;
}

// ---------------------------------------------------------------------------
// Importing learned-shader and pipeline cache files
namespace {

constexpr uint32_t kLegacyShaderCacheStamp = 2; // SHADER_CACHE_GENERIC_EXTRA_VERSION, used by caches before the title-derived stamp

// A learned-shader entry starts with one byte holding the entry version (1) and the shader type (0 vertex,
// 1 geometry, 2 pixel) in the high nibble, then the base hash and aux hash (see LatteShaderCache.cpp). Desktop
// Cemu's pre-1.16 caches (keyed by the RPX hash) start with 0x08 instead.
bool IOSCacheEntryIsShader(const std::vector<uint8>& data)
{
    return data.size() >= 17 && (data[0] & 0xF) == 1 && (data[0] >> 4) <= 2;
}

void IOSCacheInspect(unsigned long long titleId, const char* path, CemuCacheFileInfo* info)
{
    *info = CemuCacheFileInfo{};
    info->status = CEMU_CACHE_STATUS_NOT_A_CACHE;
    if (!path)
        return;
    // FileCache reads the V3 format and the older V2 header, and skips the checksum bit when an entry has none.
    // Read-only: the file is the player's, so a damaged entry is not repaired or deleted and nothing is restored
    // from MuffinEMU's backup even when the file carries the same name as the title's own cache.
    FileCache* cache = FileCache::OpenReadOnly(std::filesystem::path(path));
    if (!cache)
        return;
    info->stamp = cache->GetExtraVersion();
    const uint32_t shaderStamp = LatteShaderCache_getShaderCacheExtraVersion(titleId);
    const uint32_t pipelineStamp = LatteShaderCache_getPipelineCacheExtraVersion(titleId);
    if (info->stamp == shaderStamp || info->stamp == kLegacyShaderCacheStamp)
        info->kind = CEMU_CACHE_FILE_SHADERS;
    else if (info->stamp == pipelineStamp)
        info->kind = CEMU_CACHE_FILE_PIPELINE;
    else
    {
        info->status = CEMU_CACHE_STATUS_OTHER_GAME;
        delete cache;
        return;
    }
    int legacyFormat = 0;
    std::vector<uint8> data;
    const int maxIndex = cache->GetMaximumFileIndex();
    for (int i = 0; i < maxIndex; i++)
    {
        uint64 name1 = 0, name2 = 0;
        if (!cache->GetFileByIndex(i, &name1, &name2, data))
            continue;
        info->entryCount++;
        if (info->kind == CEMU_CACHE_FILE_PIPELINE)
            info->usableCount++;
        else if (IOSCacheEntryIsShader(data))
            info->usableCount++;
        else if (!data.empty() && data[0] == 0x08)
            legacyFormat++;
    }
    // GetFileByIndex only hands back good entries; ones that failed their check are counted here
    info->damagedCount = (int)cache->GetDamagedEntryCount();
    if (info->usableCount > 0)
        info->status = CEMU_CACHE_STATUS_OK;
    else
        info->status = legacyFormat > 0 ? CEMU_CACHE_STATUS_OLD_FORMAT : CEMU_CACHE_STATUS_NOTHING_USABLE;
    delete cache;
}

} // namespace

void cemu_bridge_cache_file_inspect(unsigned long long titleId, const char* path, CemuCacheFileInfo* outInfo) {
    if (!outInfo)
        return;
    IOSCacheInspect(titleId, path, outInfo);
}

int cemu_bridge_cache_stamp_kind(unsigned long long titleId, unsigned int stamp) {
    if (stamp == LatteShaderCache_getShaderCacheExtraVersion(titleId))
        return CEMU_CACHE_FILE_SHADERS;
    if (stamp == LatteShaderCache_getPipelineCacheExtraVersion(titleId))
        return CEMU_CACHE_FILE_PIPELINE;
    return CEMU_CACHE_FILE_UNKNOWN;
}

int cemu_bridge_cache_file_import(unsigned long long titleId, const char* path, int kind, int renderer, bool pipelineIsVulkan,
                                  int* outAdded, int* outAlreadyThere, int* outSkipped) {
    if (outAdded) *outAdded = 0;
    if (outAlreadyThere) *outAlreadyThere = 0;
    if (outSkipped) *outSkipped = 0;
    // Both files are open in the running game and would be rewritten on close.
    if (cemu_bridge_is_title_running()) {
        cemuLog_log(LogType::Force, "Cache import: refusing while a title is running");
        return CEMU_CACHE_STATUS_TITLE_RUNNING;
    }
    CemuCacheFileInfo info;
    IOSCacheInspect(titleId, path, &info);
    if (info.status != CEMU_CACHE_STATUS_OK)
        return info.status;
    if (info.kind != kind)
        return CEMU_CACHE_STATUS_NOT_A_CACHE;

    // where it goes
    std::filesystem::path destPath;
    uint32_t destStamp;
    if (kind == CEMU_CACHE_FILE_SHADERS) {
        destPath = renderer == 1 ? ActiveSettings::GetCachePath("shaderCache/transferable/{:016x}_shaders.bin", titleId)
                                 : ActiveSettings::GetCachePath("shaderCache/transferable/{:016x}_mtlshaders.bin", titleId);
        destStamp = LatteShaderCache_getShaderCacheExtraVersion(titleId);
    } else {
        destPath = pipelineIsVulkan ? ActiveSettings::GetCachePath("shaderCache/transferable/{:016x}_vkpipeline.bin", titleId)
                                    : ActiveSettings::GetCachePath("shaderCache/transferable/{:016x}_mtlpipeline.bin", titleId);
        destStamp = LatteShaderCache_getPipelineCacheExtraVersion(titleId);
    }
    std::error_code ec;
    std::filesystem::create_directories(destPath.parent_path(), ec);

    // The title's own file is opened as it is, or created when there is none; a file that exists but won't
    // open is left alone (opening it with the create option would move it aside).
    FileCache* dest = nullptr;
    if (std::filesystem::exists(destPath, ec)) {
        dest = FileCache::Open(destPath);
        if (!dest) {
            cemuLog_log(LogType::Force, "Cache import: \"{}\" can't be opened, leaving it as it is", destPath.filename().string());
            return -1;
        }
        const uint32_t have = dest->GetExtraVersion();
        const bool ok = have == destStamp || (kind == CEMU_CACHE_FILE_SHADERS && have == kLegacyShaderCacheStamp);
        if (!ok) {
            delete dest;
            return -2;
        }
    } else {
        dest = FileCache::Create(destPath, destStamp);
        if (!dest)
            return -1;
    }
    dest->UseCompression(false);

    FileCache* source = FileCache::OpenReadOnly(std::filesystem::path(path)); // never modified, see IOSCacheInspect
    if (!source) {
        delete dest;
        return CEMU_CACHE_STATUS_NOT_A_CACHE;
    }
    int added = 0, already = 0, skipped = 0;
    std::vector<uint8> data;
    const int maxIndex = source->GetMaximumFileIndex();
    for (int i = 0; i < maxIndex; i++) {
        uint64 name1 = 0, name2 = 0;
        if (!source->GetFileByIndex(i, &name1, &name2, data))
            continue;
        if (kind == CEMU_CACHE_FILE_SHADERS && !IOSCacheEntryIsShader(data)) {
            skipped++;
            continue;
        }
        if (dest->HasFile({ name1, name2 })) {
            already++; // the title's own entry wins
            continue;
        }
        if (!dest->AddFile({ name1, name2 }, data.data(), (sint32)data.size())) {
            skipped++; // not written (storage full); the title's file is unchanged by this entry
            continue;
        }
        added++;
    }
    skipped += (int)source->GetDamagedEntryCount() + info.damagedCount;
    delete source;
    delete dest; // closes and flushes
    cemuLog_log(LogType::Force, "Cache import: {} added, {} already there, {} skipped ({})", added, already, skipped, destPath.filename().string());
    if (outAdded) *outAdded = added;
    if (outAlreadyThere) *outAlreadyThere = already;
    if (outSkipped) *outSkipped = skipped;
    return CEMU_CACHE_STATUS_OK;
}

// ---------------------------------------------------------------------------
// Settings pushed from Swift. Each writes the engine's own config value, which the core
// reads when a title starts (or, for scaling, every time the output blit is sized).

void cemu_bridge_set_async_shader_compile(bool enabled) {
    GetConfig().async_compile = enabled;
}

bool cemu_bridge_async_shader_compile(void) {
    return GetConfig().async_compile.GetValue();
}

void cemu_bridge_set_stretch_to_fill(bool enabled) {
    GetConfig().fullscreen_scaling = enabled ? (sint32)kStretch : (sint32)kKeepAspectRatio;
}

// A one-line message for the player about how this launch differed from what was asked for (Vulkan not
// available, so Metal). Read and cleared by cemu_bridge_take_launch_notice().
static std::mutex g_launchNoticeMutex;
static std::string g_launchNotice;

static void ios_set_launch_notice(const std::string& notice) {
    std::lock_guard<std::mutex> lock(g_launchNoticeMutex);
    g_launchNotice = notice;
}

const char* cemu_bridge_take_launch_notice(void) {
    static thread_local std::string snapshot;
    std::lock_guard<std::mutex> lock(g_launchNoticeMutex);
    snapshot = g_launchNotice;
    g_launchNotice.clear();
    return snapshot.c_str();
}

// Vulkan (MoltenVK) that failed to start is remembered with the MoltenVK build it failed on. Settings > Graphics
// clears it when the player picks Vulkan again, and switching MoltenVK builds makes it stop applying.
static NSString* const kVulkanFailedBuildKey = @"muffin.render.vulkanFailedBuild";
static NSString* const kGraphicsAPIKey = @"muffin.render.graphicsAPI";
// Why Vulkan last failed, shown under the renderer picker in Settings > Graphics (cleared when the player picks Vulkan again).
static NSString* const kVulkanFailureReasonKey = @"muffin.render.vulkanFailureReason";

static void ios_migrate_renderer_setting_to_metal() {
    [[NSUserDefaults standardUserDefaults] setInteger:(NSInteger)kMetal forKey:kGraphicsAPIKey];
}

// Called after a renderer was built. When Vulkan could not start and Metal was used instead, tells the player and
// turns the saved Vulkan choice into Metal, so the same failure is not repeated on every launch.
static void ios_report_renderer_fallback() {
    char why[256];
    if (!CemuTakeRendererFallback(why, sizeof(why)))
        return;
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[NSString stringWithUTF8String:g_activeMoltenVK.c_str()] forKey:kVulkanFailedBuildKey];
    [defaults setObject:[NSString stringWithFormat:@"could not start: %s", why] forKey:kVulkanFailureReasonKey];
    ios_migrate_renderer_setting_to_metal();
    cemu_bridge_log_checkpoint((std::string("Renderer: Vulkan could not start (") + why + "). This launch uses Metal, and the saved renderer is now Metal.").c_str());
    ios_set_launch_notice("Vulkan couldn't start on this iPad, so this game is using Metal. The renderer setting is back on Metal.");
}

void cemu_bridge_set_graphics_api(int api) {
    if (api == (int)kVulkan) {
        NSString* failedBuild = [[NSUserDefaults standardUserDefaults] stringForKey:kVulkanFailedBuildKey];
        if (failedBuild.length > 0 && failedBuild.UTF8String && g_activeMoltenVK == failedBuild.UTF8String) {
            cemu_bridge_log_checkpoint(("Renderer: Vulkan failed to start on this device with MoltenVK " + g_activeMoltenVK
                + " earlier, so the saved Vulkan choice is replaced with Metal").c_str());
            ios_migrate_renderer_setting_to_metal();
            ios_set_launch_notice("Vulkan didn't start on this iPad last time, so MuffinEMU is using Metal. You can try Vulkan again in Settings > Graphics.");
            api = (int)kMetal;
        }
    }
    GetConfig().graphic_api = (api == (int)kVulkan) ? kVulkan : kMetal;
}

int cemu_bridge_graphics_api(void) {
    return (int)GetConfig().graphic_api.GetValue();
}

void cemu_bridge_set_upscale_filter(int filter) {
    if (filter >= kLinearFilter && filter <= kNearestNeighborFilter)
        GetConfig().upscale_filter = (sint32)filter;
}

void cemu_bridge_set_downscale_filter(int filter) {
    if (filter >= kLinearFilter && filter <= kNearestNeighborFilter)
        GetConfig().downscale_filter = (sint32)filter;
}

void cemu_bridge_set_framebuffer_fetch(bool enabled) {
    GetConfig().framebuffer_fetch = enabled;
}

bool cemu_bridge_framebuffer_fetch(void) {
    return GetConfig().framebuffer_fetch.GetValue();
}

void cemu_bridge_set_emulate_missing_effects(bool enabled) {
    GetConfig().emulate_missing_effects = enabled;
}

bool cemu_bridge_emulate_missing_effects(void) {
    return GetConfig().emulate_missing_effects.GetValue();
}

// ---------------------------------------------------------------------------
// Screen orientation, gamma and the on-screen performance overlay. See the doc comments
// on the declarations in CemuBridge.h for what each one does and why the gamma range is
// 1.0-3.0. overlay.* are plain (non-ConfigValue) fields, same as the audio block below.

void cemu_bridge_set_render_upside_down(bool enabled) {
    GetConfig().render_upside_down = enabled;
}

bool cemu_bridge_render_upside_down(void) {
    return GetConfig().render_upside_down.GetValue();
}

void cemu_bridge_set_display_gamma(float gamma) {
    if (gamma <= 0.0f) {
        GetConfig().userDisplayGamma = 0.0f; // sRGB
        return;
    }
    if (gamma < 1.0f)
        gamma = 1.0f;
    else if (gamma > 3.0f)
        gamma = 3.0f;
    GetConfig().userDisplayGamma = gamma;
}

float cemu_bridge_display_gamma(void) {
    return GetConfig().userDisplayGamma.GetValue();
}

void cemu_bridge_set_override_app_gamma(bool enabled) {
    GetConfig().overrideAppGammaPreference = enabled;
}

bool cemu_bridge_override_app_gamma(void) {
    return GetConfig().overrideAppGammaPreference.GetValue();
}

void cemu_bridge_set_override_gamma_value(float gamma) {
    // Mirrors CemuConfig::Load()'s own graphic.xml clamp for this field (a negative value
    // means the XML predates it or was hand-edited wrong, not "as low as possible") rather
    // than cemu_bridge_set_display_gamma()'s 1.0-3.0 clamp - this field has no 0-means-sRGB
    // special case to preserve, so out-of-range here only ever means "reset to default".
    if (gamma < 0.0f)
        gamma = 2.2f;
    GetConfig().overrideGammaValue = gamma;
}

float cemu_bridge_override_gamma_value(void) {
    return GetConfig().overrideGammaValue.GetValue();
}

void cemu_bridge_set_overlay_position(int position) {
    if (position >= (int)ScreenPosition::kDisabled && position <= (int)ScreenPosition::kBottomRight)
        GetConfig().overlay.position = (ScreenPosition)position;
}

int cemu_bridge_overlay_position(void) {
    return (int)GetConfig().overlay.position;
}

void cemu_bridge_set_overlay_fps(bool enabled) {
    GetConfig().overlay.fps = enabled;
}

bool cemu_bridge_overlay_fps(void) {
    return GetConfig().overlay.fps;
}

void cemu_bridge_set_overlay_cpu_usage(bool enabled) {
    GetConfig().overlay.cpu_usage = enabled;
}

bool cemu_bridge_overlay_cpu_usage(void) {
    return GetConfig().overlay.cpu_usage;
}

void cemu_bridge_set_overlay_ram_usage(bool enabled) {
    GetConfig().overlay.ram_usage = enabled;
}

bool cemu_bridge_overlay_ram_usage(void) {
    return GetConfig().overlay.ram_usage;
}

void cemu_bridge_set_overlay_text_color(uint32_t color) {
    GetConfig().overlay.text_color = color;
}

uint32_t cemu_bridge_overlay_text_color(void) {
    return GetConfig().overlay.text_color;
}

void cemu_bridge_set_overlay_text_scale(int scale) {
    GetConfig().overlay.text_scale = (sint32)std::clamp(scale, 50, 200);
}

int cemu_bridge_overlay_text_scale(void) {
    return GetConfig().overlay.text_scale;
}

void cemu_bridge_set_overlay_cpu_mode(bool enabled) {
    GetConfig().overlay.cpu_mode = enabled;
}

bool cemu_bridge_overlay_cpu_mode(void) {
    return GetConfig().overlay.cpu_mode;
}

void cemu_bridge_set_overlay_drawcalls(bool enabled) {
    GetConfig().overlay.drawcalls = enabled;
}

bool cemu_bridge_overlay_drawcalls(void) {
    return GetConfig().overlay.drawcalls;
}

void cemu_bridge_set_overlay_cpu_per_core_usage(bool enabled) {
    GetConfig().overlay.cpu_per_core_usage = enabled;
}

bool cemu_bridge_overlay_cpu_per_core_usage(void) {
    return GetConfig().overlay.cpu_per_core_usage;
}

void cemu_bridge_set_overlay_vram_usage(bool enabled) {
    GetConfig().overlay.vram_usage = enabled;
}

bool cemu_bridge_overlay_vram_usage(void) {
    return GetConfig().overlay.vram_usage;
}

void cemu_bridge_set_overlay_debug(bool enabled) {
    GetConfig().overlay.debug = enabled;
}

bool cemu_bridge_overlay_debug(void) {
    return GetConfig().overlay.debug;
}

void cemu_bridge_set_notification_position(int position) {
    if (position >= (int)ScreenPosition::kDisabled && position <= (int)ScreenPosition::kBottomRight)
        GetConfig().notification.position = (ScreenPosition)position;
}

int cemu_bridge_notification_position(void) {
    return (int)GetConfig().notification.position;
}

void cemu_bridge_set_notification_text_color(uint32_t color) {
    GetConfig().notification.text_color = color;
}

uint32_t cemu_bridge_notification_text_color(void) {
    return GetConfig().notification.text_color;
}

void cemu_bridge_set_notification_text_scale(int scale) {
    GetConfig().notification.text_scale = (sint32)std::clamp(scale, 50, 200);
}

int cemu_bridge_notification_text_scale(void) {
    return GetConfig().notification.text_scale;
}

void cemu_bridge_set_notification_controller_profiles(bool enabled) {
    GetConfig().notification.controller_profiles = enabled;
}

bool cemu_bridge_notification_controller_profiles(void) {
    return GetConfig().notification.controller_profiles;
}

void cemu_bridge_set_notification_controller_battery(bool enabled) {
    GetConfig().notification.controller_battery = enabled;
}

bool cemu_bridge_notification_controller_battery(void) {
    return GetConfig().notification.controller_battery;
}

void cemu_bridge_set_notification_shader_compiling(bool enabled) {
    GetConfig().notification.shader_compiling = enabled;
}

bool cemu_bridge_notification_shader_compiling(void) {
    return GetConfig().notification.shader_compiling;
}

void cemu_bridge_set_notification_friends(bool enabled) {
    GetConfig().notification.friends = enabled;
}

bool cemu_bridge_notification_friends(void) {
    return GetConfig().notification.friends;
}

void cemu_bridge_set_native_overlay(bool enabled) {
    g_overlayNativeOnIOS.store(enabled, std::memory_order_relaxed);
}

bool cemu_bridge_native_overlay(void) {
    return g_overlayNativeOnIOS.load(std::memory_order_relaxed);
}

const char* cemu_bridge_native_overlay_text(void) {
    static thread_local std::string text;
    text.clear();
    if (!g_overlayNativeOnIOS.load(std::memory_order_relaxed))
        return text.c_str();

    std::vector<std::string> stats;
    std::vector<std::string> notifications;
    LatteOverlay_CollectNativeText(stats, notifications);

    for (size_t i = 0; i < stats.size(); ++i) {
        if (i != 0)
            text += '\n';
        text += stats[i];
    }
    for (const std::string& notification : notifications) {
        text += '\x1e';
        text += notification;
    }
    return text.c_str();
}

int32_t cemu_bridge_cache_loading(uint32_t* loaded, uint32_t* total) {
    uint32 loadedCount = 0;
    uint32 totalCount = 0;
    const uint32 phase = LatteShaderCache_GetNativeProgress(loadedCount, totalCount);
    if (loaded)
        *loaded = loadedCount;
    if (total)
        *total = totalCount;
    return (int32_t)phase;
}

// Native dialogs (software keyboard, error viewer). See NativeDialogs.h.
#include "gui/uikit/NativeDialogs.h"

void cemu_bridge_set_native_dialogs(bool enabled) {
    NativeDialogs::SetEnabled(enabled);
}

const char* cemu_bridge_native_dialog_request(void) {
    static thread_local std::string request;
    request = NativeDialogs::Describe();
    return request.c_str();
}

void cemu_bridge_native_keyboard_answer(uint64_t id, const char* text, int answer) {
    NativeDialogs::KeyboardAnswer kind = NativeDialogs::KeyboardAnswer::Update;
    if (answer == 1)
        kind = NativeDialogs::KeyboardAnswer::Accept;
    else if (answer == 2)
        kind = NativeDialogs::KeyboardAnswer::Cancel;
    NativeDialogs::AnswerKeyboard(id, NativeDialogs::FromUtf8(text), kind);
}

void cemu_bridge_native_error_answer(uint64_t id, int button) {
    NativeDialogs::AnswerError(id, button);
}

// MARK: - Audio
//
// tv_audio_enabled/pad_audio_enabled/tv_channels/pad_channels/tv_volume/pad_volume/
// microphone_enabled/input_volume are all plain fields on CemuConfig, not ConfigValue-wrapped,
// so they're read and written directly rather than through .GetValue(). See CemuBridge.h's
// Audio section for what's deliberately left out (audio_delay, input_channels, every
// *_device) and why.

void cemu_bridge_set_tv_audio_enabled(bool enabled) {
    GetConfig().tv_audio_enabled = enabled;
}

bool cemu_bridge_tv_audio_enabled(void) {
    return GetConfig().tv_audio_enabled;
}

void cemu_bridge_set_tv_volume(int volume) {
    GetConfig().tv_volume = std::clamp(volume, 0, 100);
    // apply to a running title too; the device reads it on every render callback
    std::shared_lock lock(g_audioMutex);
    if (g_tvAudio)
        g_tvAudio->SetVolume(GetConfig().tv_volume);
}

int cemu_bridge_tv_volume(void) {
    return GetConfig().tv_volume;
}

void cemu_bridge_set_tv_channels(int channels) {
    if (channels >= kMono && channels <= kSurround)
        GetConfig().tv_channels = (AudioChannels)channels;
}

int cemu_bridge_tv_channels(void) {
    return (int)GetConfig().tv_channels;
}

// "Record audio" (HOME menu). See audio/iOSAudioRecorder.mm.
bool cemu_bridge_audio_record_start(const char* path) {
    return IOSAudioRecorder::Start(path);
}

void cemu_bridge_audio_record_stop(void) {
    IOSAudioRecorder::Stop();
}

bool cemu_bridge_audio_record_active(void) {
    return IOSAudioRecorder::IsActive();
}

double cemu_bridge_audio_record_seconds(void) {
    return IOSAudioRecorder::Seconds();
}

// "Record screen" (HOME menu). See IOSScreenRecorder.mm.
bool cemu_bridge_screen_record_start(const char* path) {
    return IOSScreenRecorder::Start(path);
}

bool cemu_bridge_screen_record_stop(void) {
    return IOSScreenRecorder::Stop();
}

bool cemu_bridge_screen_record_active(void) {
    return IOSScreenRecorder::g_active.load(std::memory_order_relaxed);
}

double cemu_bridge_screen_record_seconds(void) {
    return IOSScreenRecorder::Seconds();
}

bool cemu_bridge_screen_record_failed(void) {
    return IOSScreenRecorder::Failed();
}

void cemu_bridge_set_pad_audio_enabled(bool enabled) {
    GetConfig().pad_audio_enabled = enabled;
}

bool cemu_bridge_pad_audio_enabled(void) {
    return GetConfig().pad_audio_enabled;
}

void cemu_bridge_set_pad_volume(int volume) {
    GetConfig().pad_volume = std::clamp(volume, 0, 100);
    // apply to a running title too; the device reads it on every render callback
    std::shared_lock lock(g_audioMutex);
    if (g_padAudio)
        g_padAudio->SetVolume(GetConfig().pad_volume);
}

int cemu_bridge_pad_volume(void) {
    return GetConfig().pad_volume;
}

void cemu_bridge_set_pad_channels(int channels) {
    if (channels >= kMono && channels <= kSurround)
        GetConfig().pad_channels = (AudioChannels)channels;
}

int cemu_bridge_pad_channels(void) {
    return (int)GetConfig().pad_channels;
}

void cemu_bridge_set_microphone_enabled(bool enabled) {
    GetConfig().microphone_enabled = enabled;
}

bool cemu_bridge_microphone_enabled(void) {
    return GetConfig().microphone_enabled;
}

void cemu_bridge_set_input_volume(int volume) {
    GetConfig().input_volume = std::clamp(volume, 0, 100);
}

int cemu_bridge_input_volume(void) {
    return GetConfig().input_volume;
}

// Simulated mic blow (see CemuBridge.h). The flag itself is a relaxed atomic in mic.cpp, read
// by the AX thread that feeds the game's mic buffer.
void mic_setBlow(bool isBlowing);
bool mic_isBlowing();

void cemu_bridge_set_mic_blow(bool blowing) {
    mic_setBlow(blowing);
}

bool cemu_bridge_mic_blow(void) {
    return mic_isBlowing();
}

void cemu_bridge_set_vsync_enabled(bool enabled) {
    GetConfig().vsync = enabled ? 1 : 0;
}

bool cemu_bridge_vsync_enabled(void) {
    return GetConfig().vsync.GetValue() != 0;
}

void cemu_bridge_set_recompiler_enabled(bool enabled) {
    g_recompilerRequested.store(enabled);
    // Before initialize the config is not loaded yet; cemu_bridge_initialize() applies it.
    if (g_initialized.load())
        ios_apply_cpu_mode();
}

bool cemu_bridge_recompiler_enabled(void) {
    return g_recompilerRequested.load();
}

void cemu_bridge_set_favour_accuracy(bool enabled) {
    g_favourAccuracy.store(enabled);
    if (g_initialized.load())
        ios_apply_cpu_mode();
}

bool cemu_bridge_favour_accuracy(void) {
    return g_favourAccuracy.load();
}

void cemu_bridge_set_favour_performance(bool enabled) {
    // Nothing to recompute now: everything it changes is applied by ios_apply_render_profile()
    // when the next title starts.
    g_favourPerformance.store(enabled);
}

bool cemu_bridge_favour_performance(void) {
    return g_favourPerformance.load();
}

void cemu_bridge_set_full_speed_renders(bool enabled, int shaderMode) {
    // Applied by ios_apply_render_profile() and Latte_Start() when the next title starts.
    g_fullSpeedRenders.store(enabled);
    g_fullSpeedShaderMode.store(shaderMode == 1 ? 1 : 0);
}

bool cemu_bridge_full_speed_renders(void) {
    return g_fullSpeedRenders.load();
}

// Best-effort real device temperature, in degrees Celsius. NaN when unavailable.
//
// iOS does NOT publish a device temperature to apps. There is no public API for it at
// all - ProcessInfo.thermalState is a four-level signal and that is the whole of the
// supported surface. So this reaches for the battery's own sensor through IOKit, which
// is a PRIVATE framework on iOS, and it is written to fail cleanly rather than to
// succeed:
//
//   - Everything is resolved with dlopen/dlsym rather than linked. IOKit is not in the
//     iOS SDK, so linking it would not build; and a symbol that moves or disappears in a
//     future iOS turns into a nil pointer here instead of a launch-time crash.
//   - The sandbox blocks IOKit user-client access to power services for a normally
//     sideloaded app. This is expected to return NaN on a SideStore/AltStore install and
//     has a real chance of working on TrollStore or jailbroken, where the process is not
//     confined the same way.
//   - On failure it returns NaN. It never estimates, never derives a number from
//     thermalState, and never returns a plausible-looking value it did not read. A made-up
//     temperature presented in degrees is worse than no temperature at all, because it
//     looks authoritative.
//
// It is also the BATTERY's temperature, not the SoC's. The battery is what has a sensor
// anything outside the kernel can reach; it lags the chip and reads lower under a short
// burst. Useful as a trend, not as a CPU die temperature, and the UI says so.
double cemu_bridge_device_temperature_celsius(void) {
    static dispatch_once_t once;
    static void* ioKitHandle = nullptr;
    static uint32_t (*fnServiceGetMatchingService)(uint32_t, CFDictionaryRef) = nullptr;
    static CFMutableDictionaryRef (*fnServiceMatching)(const char*) = nullptr;
    static CFTypeRef (*fnRegistryEntryCreateCFProperty)(uint32_t, CFStringRef, CFAllocatorRef, uint32_t) = nullptr;
    static int (*fnObjectRelease)(uint32_t) = nullptr;

    dispatch_once(&once, ^{
        ioKitHandle = dlopen("/System/Library/Frameworks/IOKit.framework/IOKit", RTLD_LAZY);
        if (!ioKitHandle)
            return;
        fnServiceGetMatchingService = (uint32_t (*)(uint32_t, CFDictionaryRef))dlsym(ioKitHandle, "IOServiceGetMatchingService");
        fnServiceMatching = (CFMutableDictionaryRef (*)(const char*))dlsym(ioKitHandle, "IOServiceMatching");
        fnRegistryEntryCreateCFProperty = (CFTypeRef (*)(uint32_t, CFStringRef, CFAllocatorRef, uint32_t))dlsym(ioKitHandle, "IORegistryEntryCreateCFProperty");
        fnObjectRelease = (int (*)(uint32_t))dlsym(ioKitHandle, "IOObjectRelease");
    });

    if (!fnServiceGetMatchingService || !fnServiceMatching || !fnRegistryEntryCreateCFProperty)
        return NAN;

    // Two service names, because which one carries the sensor differs by device and OS.
    static const char* kServices[] = { "AppleSmartBattery", "IOPMPowerSource" };
    for (const char* service : kServices)
    {
        CFMutableDictionaryRef match = fnServiceMatching(service);
        if (!match)
            continue;
        // IOServiceGetMatchingService CONSUMES the matching dictionary, so it must not be
        // released here on either path.
        uint32_t entry = fnServiceGetMatchingService(0 /* kIOMainPortDefault */, match);
        if (!entry)
            continue;
        CFTypeRef value = fnRegistryEntryCreateCFProperty(entry, CFSTR("Temperature"), kCFAllocatorDefault, 0);
        if (fnObjectRelease)
            fnObjectRelease(entry);
        if (!value)
            continue;
        double celsius = NAN;
        if (CFGetTypeID(value) == CFNumberGetTypeID())
        {
            int32_t raw = 0;
            if (CFNumberGetValue((CFNumberRef)value, kCFNumberSInt32Type, &raw))
            {
                // Reported in hundredths of a degree on some devices and tenths on
                // others. Pick by magnitude rather than by device table: a battery is
                // never at 300 C, and never at 3 C inside a running iPad either, so the
                // scale is unambiguous from the value itself.
                if (raw > 1000)      celsius = raw / 100.0;
                else if (raw > 100)  celsius = raw / 10.0;
                else                 celsius = (double)raw;
            }
        }
        CFRelease(value);
        // Sanity-gate the result. A sensor that reports something physically impossible
        // is a misread, and passing it through as a temperature would be exactly the
        // fabrication this function exists to avoid.
        if (!std::isnan(celsius) && celsius > -20.0 && celsius < 120.0)
            return celsius;
    }
    return NAN;
}

void cemu_bridge_set_thermal_throttle_micros(uint32_t micros) {
    // Straight through to the core. No g_initialized guard and no stored copy: the atomic
    // lives in coreinit and defaults to 0, so setting it before a title exists is
    // harmless, and the host thread loop picks it up on its very next reschedule.
    coreinit::OSSetThermalThrottleMicros(micros);
}

void cemu_bridge_set_multicore_enabled(bool enabled) {
    g_coreModeSetting.store(enabled ? kCoreModeMulti : kCoreModeSingle);
}

void cemu_bridge_set_cpu_core_mode(int mode) {
    g_coreModeSetting.store(mode == 1 ? kCoreModeSingle : (mode == 2 ? kCoreModeMulti : (mode == 3 ? kCoreModeTwo : kCoreModeAuto)));
    if (g_initialized.load())
        ios_apply_cpu_mode();
}

void cemu_bridge_set_cpu_auto_demoted(bool demoted) {
    g_autoDemoted.store(demoted);
}

int cemu_bridge_cpu_cores_running(void) {
    return g_coresRunning.load();
}

bool cemu_bridge_cpu_auto_picked_multicore(void) {
    return g_autoPickedMulti.load();
}

void cemu_bridge_set_draw_breadcrumbs(bool enabled) {
    PerfTelemetry::DrawBreadcrumbsEnabled().store(enabled, std::memory_order_relaxed);
}

const char* cemu_bridge_perf_line(void) {
    static thread_local std::string snapshot;
    {
        std::lock_guard<std::mutex> lock(g_perfLineMutex);
        snapshot = g_perfLine;
    }
    return snapshot.c_str();
}

const char* cemu_bridge_device_summary(void) {
    static const std::string summary = [] {
        const IosDeviceFacts& d = ios_device_facts();
        char buf[320];
        snprintf(buf, sizeof(buf), "%s, %s, %llu performance + %llu efficiency cores, %llu MB RAM",
            d.model.empty() ? "unknown device" : d.model.c_str(),
            d.gpuName.empty() ? "unknown GPU" : d.gpuName.c_str(),
            (unsigned long long)d.perfCores, (unsigned long long)d.effCores, (unsigned long long)d.memoryMB);
        return std::string(buf);
    }();
    return summary.c_str();
}

void cemu_bridge_set_low_power_mode(bool enabled) {
    g_lowPowerMode.store(enabled);
    // Same shape as Favour accuracy above: recompute the mode now so Settings reports
    // the truth immediately, but the core count itself only changes on the next launch -
    // _LaunchTitleThread() has already started however many host threads it started.
    if (g_initialized.load())
        ios_apply_cpu_mode();
}

bool cemu_bridge_low_power_mode(void) {
    return g_lowPowerMode.load();
}

int cemu_bridge_cpu_mode(void) {
    return g_cpuMode.load();
}

const char* cemu_bridge_cpu_mode_detail(void) {
    const char* detail = getCpuModeDetail();
    if (detail[0] == '\0')
        return "Not decided yet - the CPU path is chosen when the engine initializes, on the first launch.";
    return detail;
}

const char* cemu_bridge_active_moltenvk(void) {
    return g_activeMoltenVK.c_str();
}

bool cemu_bridge_core_available(void) {
    return true;
}

// ---------------------------------------------------------------------------
// Lifecycle

void cemu_bridge_initialize(const char* mlcPath) {
    if (g_initialized.exchange(true))
        return;
    {
        std::string where = "Crash log and checkpoints are being written to: ";
        const char* crashPath = cemu_bridge_crash_log_path();
        where += (crashPath && crashPath[0]) ? crashPath : "(nowhere - $HOME was not set, so no file could be opened)";
        cemu_bridge_log_checkpoint(where.c_str());
    }
    // The capability snapshot, taken before the memory watchdog, the JIT setup or the renderer read it.
    cemu_device_caps_initialize();
    cemu_bridge_log_checkpoint(cemu_device_caps_line());
    cemu_bridge_start_memory_watchdog();
    ios_configure_jit_environment();
    // MoltenVK reads these once, when CemuInitialize() loads it for the Vulkan backend.
    // Asynchronous queue submits, so Cemu's pipeline compiles do not stall the frame.
    setenv("MVK_CONFIG_SYNCHRONOUS_QUEUE_SUBMITS", "0", 1);
    setenv("MVK_CONFIG_DEBUG", "0", 1);
    setenv("MVK_CONFIG_MAX_ACTIVE_METAL_COMMAND_BUFFERS_PER_QUEUE", "128", 1);
    // Test mitigations for the Vulkan GPU page fault (kIOGPUCommandBufferCallbackErrorPageFault). All ON by default; the core
    // (VulkanAPI.cpp / VulkanRenderer.cpp) reads the MUFFIN_VK_* variables and logs what was active. overwrite=0, so a variable
    // set in the environment wins over UserDefaults. Flip one with e.g.
    //   defaults write <bundle id> muffin.vk.hostMapped -bool YES   (host-mapped buffers back ON)
    //   defaults write <bundle id> muffin.vk.argumentBuffers -bool YES
    //   defaults write <bundle id> muffin.vk.delayedFreeFrames -int 0   (0 = no extra delay, max 15)
    {
        NSUserDefaults* vkDefaults = [NSUserDefaults standardUserDefaults];
        const bool hostMapped = [vkDefaults objectForKey:@"muffin.vk.hostMapped"] ? [vkDefaults boolForKey:@"muffin.vk.hostMapped"] : false;
        const bool argBuffers = [vkDefaults objectForKey:@"muffin.vk.argumentBuffers"] ? [vkDefaults boolForKey:@"muffin.vk.argumentBuffers"] : false;
        NSInteger delayFrames = [vkDefaults objectForKey:@"muffin.vk.delayedFreeFrames"] ? [vkDefaults integerForKey:@"muffin.vk.delayedFreeFrames"] : 3;
        if (delayFrames < 0) delayFrames = 0;
        if (delayFrames > 15) delayFrames = 15;
        setenv("MUFFIN_VK_HOST_MAPPED", hostMapped ? "1" : "0", 0);
        setenv("MUFFIN_VK_ARGUMENT_BUFFERS", argBuffers ? "1" : "0", 0);
        setenv("MUFFIN_VK_DELAYED_FREE_FRAMES", std::to_string((int)delayFrames).c_str(), 0);
        // MoltenVK reads this once at load; set it here too so it is in the environment before anything loads MoltenVK.
        setenv("MVK_CONFIG_USE_METAL_ARGUMENT_BUFFERS", argBuffers ? "1" : "0", 0);
    }

    // User data, config and mlc under Documents/mlc (writable, visible in Files); the
    // data path is the read-only CemuData directory the build copies into the bundle
    // (shared fonts, game profiles). CemuData rather than the bundle root, because a
    // top-level directory named `resources` makes CFBundle misread the whole bundle.
    fs::path userDataPath = (mlcPath && mlcPath[0] != '\0') ? fs::path(mlcPath) : fs::path(".");
    std::error_code ec;
    fs::create_directories(userDataPath / "cache", ec);
    fs::path dataPath = userDataPath;
    NSString* bundleResourcePath = [[NSBundle mainBundle] resourcePath];
    if (bundleResourcePath.length > 0)
        dataPath = fs::path(bundleResourcePath.fileSystemRepresentation) / "CemuData";
    NSString* executablePath = [[NSBundle mainBundle] executablePath] ?: @"";

    const std::string userData = userDataPath.string();
    const std::string cache = (userDataPath / "cache").string();
    const std::string data = dataPath.string();

    // Which MoltenVK the Vulkan renderer loads this launch. Both builds are embedded and
    // neither is linked, so exactly one is ever loaded: two copies in one process would
    // register the same Objective-C classes twice. The core's loader tries this path first
    // (VulkanAPI.cpp), and a loaded MoltenVK stays for the life of the process, so a change
    // in Settings applies on the next launch.
    {
        NSString* choice = [[NSUserDefaults standardUserDefaults] stringForKey:@"muffin.render.moltenVK"];
        const bool legacy = [choice isEqualToString:@"1.2.8"];
        NSString* path = [[[NSBundle mainBundle] privateFrameworksPath] stringByAppendingPathComponent:
            legacy ? @"MoltenVK128.framework/MoltenVK128" : @"MoltenVK.framework/MoltenVK"];
        if ([[NSFileManager defaultManager] fileExistsAtPath:path])
        {
            setenv("MUFFIN_MOLTENVK_PATH", path.fileSystemRepresentation, 1);
            g_activeMoltenVK = legacy ? "1.2.8" : "1.4.3";
            cemu_bridge_log_checkpoint(("MoltenVK: " + g_activeMoltenVK + " is the build for this launch (loaded only if the Vulkan renderer is selected)").c_str());
        }
        else
        {
            cemu_bridge_log_checkpoint((std::string("MoltenVK: ") + path.fileSystemRepresentation +
                " is missing from the bundle - the core falls back to its own search").c_str());
        }
    }

    // The library screen can call KeyCache_Prepare() (via a TitleInfo for a .wud/.wux/
    // encrypted game folder already in the library) before this point, which permanently latches the
    // key cache against whatever keys.txt path was in effect before CemuInitialize() (the
    // only thing that calls ActiveSettings::SetPaths() on this core) has run. Re-arm the
    // latch right before that call, so the next KeyCache_Prepare() reads keys.txt from
    // the real path instead of leaving the cache believing there are none for the session.
    KeyCache_ResetForNewPaths();

    cemu_bridge_log_checkpoint("initialize: about to call CemuInitialize()");
    try
    {
        CemuInitialize(executablePath.fileSystemRepresentation, userData.c_str(), userData.c_str(), cache.c_str(), data.c_str());
    }
    catch (...)
    {
        std::string message = "initialize: CemuInitialize() threw: " + cemu_describe_current_exception();
        cemu_bridge_log_checkpoint(message.c_str());
        setStatus("The emulator core failed to start (see the crash log).");
        g_initialized.store(false);
        return;
    }
    cemu_bridge_log_checkpoint("initialize: CemuInitialize() returned");
    // Before any title can run: CafeSystem calls back through this without a null check.
    IOSSystemImplementation_Install();

    // OSReport and the OS libs' parameter errors are what homebrew narrates its progress
    // through. Without these a ROM that is working looks exactly like one that never started.
    cemuLog_setActiveLoggingFlags(cemuLog_getFlag(LogType::CoreinitLogging) | cemuLog_getFlag(LogType::APIErrors));
    // The capability line is the first line of log.txt's iOS section; the rest of the report follows it.
    {
        const char* report = cemu_bridge_device_report();
        const char* split = strchr(report, '\n');
        cemuLog_log(LogType::Force, "{}", std::string(report, split ? (size_t)(split - report) : strlen(report)));
        cemuLog_log(LogType::Force, "iOS {}", split ? split + 1 : report);
    }
    {
        std::error_code fontsEc, profilesEc;
        const bool haveFonts = fs::exists(dataPath / "resources" / "sharedFonts" / "CafeStd.ttf", fontsEc);
        const bool haveProfiles = fs::exists(dataPath / "gameProfiles" / "default", profilesEc);
        cemuLog_log(LogType::Force, "iOS data path: {} (shared fonts present: {}, default game profiles present: {})",
            _pathToUtf8(dataPath), haveFonts, haveProfiles);
    }

    ios_apply_cpu_mode();
    // Real time, always. This used to drop to shift 6 whenever the recompiler was not
    // available, and shift 6 is not a tuning constant - ActiveSettings.h spells it out:
    //
    //     s_timer_shift = 3;  // right shift factor, 0 -> 8x, 3 -> 1x, 4 -> 0.5x
    //
    // so 6 is ONE EIGHTH SPEED. The reasoning was that the guest's own deadlines go
    // overdue before they are serviced when the interpreter cannot keep up, and slowing
    // the guest clock keeps its internal timing self-consistent. What it actually did
    // was cap the frame rate at an eighth of whatever the machine could manage, by
    // choice, on every install without a JIT enabler attached - which is the default.
    //
    // Measured on one device, one ROM: Wind Waker HD at a steady 4.6fps with shift 6
    // against a steady 45 at the engine default of 3. Wind Waker targets 30, and 30/8 is
    // 3.75 - that single difference is most of the gap.
    //
    // Slowing the clock stays available as Settings > CPU > Timebase for a title that
    // genuinely needs it, where it is a choice somebody made rather than a tax nobody
    // was told about. TimebaseScale.applyStoredChoiceIfAny() applies it at title start.
    cemu_bridge_set_timebase_shift(3);

    ios_input_start();
    ios_stats_start();
    ios_perf_start();
    ios_stall_watchdog_start();
    Fiber::SetStackFailureHandlers(
        [] {
            // Ask the GPU thread to drop unused textures, and give it a moment to do so.
            auto& w = LatteWait::Get();
            const uint32 passes = w.evictionPasses.load();
            w.evictionRequested.store(true);
            for (int i = 0; i < 150 && w.evictionPasses.load() == passes; ++i)
                std::this_thread::sleep_for(std::chrono::milliseconds(10));
        },
        [] {
            cemuLog_log(LogType::Force, "out of address space creating a game thread");
            cemu_bridge_log_checkpoint("out of address space creating a game thread");
            IOSSystemImplementation_ReportFatal("Out of memory address space creating a game thread. Restart the app and try again.");
        });
    ios_log_tail_start();
    dispatch_async(dispatch_get_main_queue(), ^{
        if (UIWindow* window = ios_key_window())
            CemuUIKit_SetMainWindow(window);
    });

    setStatus("Cemu core initialized.");
    g_initializationComplete.store(true);
}

#include "OfflineInitializationProbe.inc"
#include "OfflineInterpreterProbe.inc"
#include "OfflineMixedProbe.inc"

void cemu_bridge_register_render_surface(void* uiView, int width, int height, double dpiScale) {
    // First thing in a title launch, so it is where the launch log's +0.000s belongs.
    ios_live_log_begin_run();
    if (!uiView)
        return;
    UIView* view = (__bridge UIView*)uiView;
    if (![view.layer isKindOfClass:[CAMetalLayer class]])
    {
        cemu_bridge_log_checkpoint("register_render_surface: the TV view is not CAMetalLayer-backed - the core renders into the view's own layer, so nothing can be drawn");
        setStatus("Render surface registration failed (see crash log).");
        return;
    }
    // The core stores view.layer as the surface for both backends: Metal draws into it,
    // MoltenVK builds its Vulkan surface from it.
    CemuUIKit_SetMainView(view);
    // After SetMainView, which resets contentsScale to the screen's native scale: the
    // user's render-scale setting arrives here as dpiScale and has to win.
    ((CAMetalLayer*)view.layer).contentsScale = dpiScale;
    CemuUIKit_UpdateMainWindowSize(width, height, dpiScale);
    setStatus("Render surface registered.");
}

void cemu_bridge_register_pad_render_surface(void* uiView, int width, int height, double dpiScale) {
    if (!uiView || width <= 0 || height <= 0)
        return;
    UIView* view = (__bridge UIView*)uiView;
    if (![view.layer isKindOfClass:[CAMetalLayer class]])
    {
        cemuLog_log(LogType::Force, "iOS: cannot register the GamePad surface - the view is not CAMetalLayer-backed");
        return;
    }
    CemuUIKit_SetPadView(view);
    ((CAMetalLayer*)view.layer).contentsScale = dpiScale;
    g_padRegistered.store(true);
    // Initialized now whenever a renderer exists (CemuUIKit_InitializeLayer does nothing before one does, and
    // CemuPrepareRenderer() then picks the surface up). This used to wait for g_titleRunning, which is only set
    // after CemuRun() returns: a surface registered between the renderer being built and that flag - an external
    // display connecting while the title boots - was registered and sized but never got a layer, so nothing drew to it.
    // Called from Swift: nothing may throw out of here (Vulkan's swapchain code throws on failure).
    try
    {
        CemuUIKit_InitializeLayer(false);
    }
    catch (const std::exception& ex)
    {
        cemuLog_log(LogType::Force, "iOS: GamePad surface could not be initialized: {}", ex.what());
    }
    catch (...)
    {
        cemuLog_log(LogType::Force, "iOS: GamePad surface could not be initialized (unknown error)");
    }
    CemuUIKit_SetVisibleOutputs(true, true);
    cemuLog_log(LogType::Force, "iOS: GamePad (DRC) screen surface registered, {}x{} points at {}x scale", width, height, dpiScale);
}

void cemu_bridge_release_pad_render_surface(void) {
    // The pad layer is not torn down under a running GPU thread. The pad output is hidden
    // instead, which stops every pad draw; the Swift side keeps the view (and so the layer)
    // alive, and the next boot starts without a pad view at all.
    g_padRegistered.store(false);
    CemuUIKit_SetVisibleOutputs(true, false);
    if (!g_titleRunning.load())
        CemuUIKit_SetPadView(nil);
    cemuLog_log(LogType::Force, "iOS: GamePad (DRC) screen output hidden");
}

bool cemu_bridge_has_pad_render_surface(void) {
    return g_padRegistered.load();
}

void cemu_bridge_set_visible_outputs(bool tv, bool pad) {
    CemuUIKit_SetVisibleOutputs(tv, pad);
}

void cemu_bridge_set_output_sources(bool mainShowsGamePad, bool padShowsTV) {
    CemuUIKit_SetOutputSources(mainShowsGamePad, padShowsTV);
}

bool cemu_bridge_pad_layer_active(void) {
    return g_renderer && g_renderer->IsPadWindowActive();
}

void cemu_bridge_ensure_pad_layer(void) {
    // Only for a surface that is registered but has no layer behind it; one that already has a layer is left alone.
    if (g_padRegistered.load() && !cemu_bridge_pad_layer_active())
        CemuUIKit_InitializeLayer(false);
}

uint32_t cemu_bridge_pad_present_count(void) {
    return PerfTelemetry::Get().padPresents.load(std::memory_order_relaxed);
}

void cemu_bridge_set_pad_touch(double x, double y, bool down) {
    CemuUIKit_SetPadTouch((CGFloat)x, (CGFloat)y, down);
}

void cemu_bridge_resize_render_surface(int width, int height, double dpiScale, bool mainWindow) {
    if (width <= 0 || height <= 0)
        return;
    if (mainWindow)
    {
        CemuUIKit_UpdateMainWindowSize(width, height, dpiScale);
    }
    else
    {
        if (!g_padRegistered.load())
            return;
        CemuUIKit_UpdatePadWindowSize();
    }
    // The CAMetalLayer backs a UIView, so its drawable follows the view's bounds; Vulkan
    // recreates its swapchain when the layer reports a new size at the next present.
    cemuLog_log(LogType::Force, "iOS: {} surface resized to {}x{} points at {}x scale", mainWindow ? "TV" : "GamePad", width, height, dpiScale);
}

void cemu_bridge_log_line(const char* message) {
    if (!message)
        return;
    // The string_view overload: a message containing braces is logged verbatim rather than
    // parsed as a format string.
    cemuLog_log(LogType::Force, std::string_view(message));
}

static CemuBridgeStatus ios_boot_prepared_title(int prepared);
static void ios_report_renderer_fallback();

// A C++ exception leaving this function would unwind through Swift frames and end the app, so anything the
// prepare step throws (a filesystem error, a failed allocation, a bad number in an .xml file) becomes status 13.
static int IOSTitleLaunch_PrepareForegroundTitle_Guarded(const char* path) {
    try
    {
        return IOSTitleLaunch_PrepareForegroundTitle(path);
    }
    catch (...)
    {
        cemu_bridge_log_checkpoint(("boot_title: preparing the title threw: " + cemu_describe_current_exception()).c_str());
        CafeSystem::AbortPreparedTitle();
        return 13;
    }
}

CemuBridgeStatus cemu_bridge_boot_title(const char* path) {
    if (!path || path[0] == '\0') {
        setStatus("boot_title: empty path.");
        return CEMU_BRIDGE_BAD_ARG;
    }
    if (!g_initialized.load()) {
        setStatus("The emulator core is not initialized.");
        return CEMU_BRIDGE_CORE_NOT_BUILT;
    }

    // "mlc-title:<16 hex digits>" boots a title installed in the MLC by its id (the Wii U
    // Menu tile uses this), through the same tail as a path launch.
    static const char kMlcTitlePrefix[] = "mlc-title:";
    if (strncmp(path, kMlcTitlePrefix, sizeof(kMlcTitlePrefix) - 1) == 0) {
        char* end = nullptr;
        const unsigned long long titleId = strtoull(path + sizeof(kMlcTitlePrefix) - 1, &end, 16);
        if (end == path + sizeof(kMlcTitlePrefix) - 1 || *end != '\0' || titleId == 0) {
            setStatus("boot_title: bad title id.");
            return CEMU_BRIDGE_BAD_ARG;
        }
        return cemu_bridge_boot_title_id(titleId);
    }

    cemu_bridge_log_checkpoint("boot_title: about to prepare title");
    int prepared = IOSTitleLaunch_PrepareForegroundTitle_Guarded(path);
    cemu_bridge_log_checkpoint("boot_title: prepare returned");
    return ios_boot_prepared_title(prepared);
}

CemuBridgeStatus cemu_bridge_boot_title_id(uint64_t titleId) {
    if (titleId == 0) {
        setStatus("boot_title_id: empty title id.");
        return CEMU_BRIDGE_BAD_ARG;
    }
    if (!g_initialized.load()) {
        setStatus("The emulator core is not initialized.");
        return CEMU_BRIDGE_CORE_NOT_BUILT;
    }
    cemu_bridge_log_checkpoint("boot_title_id: about to prepare title");
    int prepared = 13;
    try
    {
        prepared = IOSTitleLaunch_PrepareForegroundTitleById(titleId);
    }
    catch (...)
    {
        cemu_bridge_log_checkpoint(("boot_title_id: preparing the title threw: " + cemu_describe_current_exception()).c_str());
        CafeSystem::AbortPreparedTitle();
    }
    cemu_bridge_log_checkpoint("boot_title_id: prepare returned");
    return ios_boot_prepared_title(prepared);
}

// Everything after the title has been prepared: report a failed prepare, otherwise bring up
// the surfaces and start the title thread. Shared by the path and title-id launches.
static CemuBridgeStatus ios_boot_prepared_title(int prepared) {
    switch (prepared) {
        case 0:
            break;
        case 1:
            setStatus("Invalid RPX.");
            return CEMU_BRIDGE_INVALID_RPX;
        case 2:
            setStatus("Unable to mount title (bad/outdated path).");
            return CEMU_BRIDGE_UNABLE_TO_MOUNT;
        case 3:
            setStatus("This game is encrypted and no key in keys.txt opens it. Put the keys.txt you dumped from your own Wii U in MuffinEMU's \"keys\" folder in the Files app (or import it in Settings), then relaunch MuffinEMU and try again.");
            return CEMU_BRIDGE_NO_DISC_KEY;
        case 4:
            setStatus("This game folder is missing title.tik (the ticket), which MuffinEMU needs to decrypt it. Copy title.tik into the folder next to title.tmd, or add this game's title key to keys.txt.");
            return CEMU_BRIDGE_NO_TITLE_TIK;
        case 7:
            setStatus("This game folder's title.tmd couldn't be read. The file may be damaged or incomplete - copy the whole folder again.");
            return CEMU_BRIDGE_BAD_TITLE_TMD;
        case 8:
            setStatus("This game folder's title.tik (the ticket) couldn't be read, so MuffinEMU can't decrypt it. The file may be damaged - copy it again, or add this game's title key to keys.txt.");
            return CEMU_BRIDGE_BAD_TITLE_TIK;
        case 9:
            setStatus("MuffinEMU couldn't decrypt this game folder. Its title.tik doesn't unlock the .app files (the ticket may belong to another console, or the files are damaged). Check that title.tmd, title.tik and the .app files are from the same download.");
            return CEMU_BRIDGE_TITLE_KEY_INVALID;
        case 10: {
            const std::string missingFile = IOSTitleLaunch_LastErrorDetail();
            setStatus(("This game folder is missing " + (missingFile.empty() ? std::string("a .app file") : missingFile) + ", which title.tmd lists. Copy every .app file from the download into the folder.").c_str());
            return CEMU_BRIDGE_MISSING_CONTENT;
        }
        case 6:
            setStatus("That looks like an update or DLC. Launch the base game instead.");
            return CEMU_BRIDGE_BASE_NOT_FOUND;
        case 11:
            setStatus("That system title isn't installed. Import it in Settings > Wii U Menu.");
            return CEMU_BRIDGE_UNABLE_TO_MOUNT;
        case 13:
            setStatus("MuffinEMU hit an internal error while opening this game. The files may be damaged. Details are in the crash log.");
            return CEMU_BRIDGE_UNABLE_TO_MOUNT;
        default:
            setStatus("Not a Wii U title this build can launch.");
            return CEMU_BRIDGE_UNSUPPORTED;
    }

    // Not enough memory left to bring the renderer up: say so, rather than let iOS end the app partway through the boot.
    {
        const uint64_t needed = DeviceCaps::GetBudgets().minBootHeadroomBytes;
        const uint64_t available = (uint64_t)os_proc_available_memory();
        if (needed != 0 && available != 0 && available < needed)
        {
            char message[512];
            snprintf(message, sizeof(message),
                "This game can't start: only %llu MB of memory is free and it needs about %llu MB. Close other apps and try again. "
                "If it keeps happening, this device may not have enough memory for this game.",
                (unsigned long long)(available >> 20), (unsigned long long)(needed >> 20));
            cemu_bridge_log_checkpoint((std::string("boot_title: not enough memory - ") + message).c_str());
            CafeSystem::AbortPreparedTitle();
            setStatus(message);
            return CEMU_BRIDGE_UNABLE_TO_MOUNT;
        }
    }

    // A pad view left over from an earlier title must not be initialized by this one.
    if (!g_padRegistered.load())
        CemuUIKit_SetPadView(nil);
    CemuUIKit_SetVisibleOutputs(true, g_padRegistered.load());
    // CPU mode is written into the config at initialize and on every toggle; re-applied
    // here so a JIT enabler attached after the app started still counts for this boot.
    ios_apply_cpu_mode(true);
    ios_apply_render_profile();

    IOSSystemImplementation_ResetExit();
    cemu_bridge_log_checkpoint("boot_title: about to call CemuRun()");
    try
    {
        // Constructs the renderer for the configured graphics API, initializes the TV
        // (and, if registered, GamePad) layers and starts the title thread.
        CemuRun();
    }
    catch (...)
    {
        std::string message = "boot_title: CemuRun() threw: " + cemu_describe_current_exception();
        cemu_bridge_log_checkpoint(message.c_str());
        // The title was prepared (mounted, memory mapped) before the renderer failed. Left like that, the next launch
        // starts on top of it and trips over it.
        CafeSystem::AbortPreparedTitle();
        g_renderer.reset();
        setStatus("The title failed to start: the graphics renderer could not be created. Try the other renderer in Settings > Graphics. Details are in the crash log.");
        return CEMU_BRIDGE_UNABLE_TO_MOUNT;
    }
    cemu_bridge_log_checkpoint("boot_title: CemuRun() returned");
    ios_report_renderer_fallback();
    // A new title: judge it from scratch, with the start-up grace period counted from now.
    ios_reset_video_stall_state();
    // Save states are only valid inside the launch they were taken in.
    IOSSaveState_BeginSession();
    g_titleRunning.store(true);
    ios_timebase_ladder_start();
    ios_two_core_watch_start();
    setStatus("Title launched.");
    return CEMU_BRIDGE_OK;
}

CemuBridgeStatus cemu_bridge_boot_rpx(const char* rpxPath) {
    // The launch path handles a standalone RPX/ELF itself.
    return cemu_bridge_boot_title(rpxPath);
}

int cemu_bridge_reload_and_count_keys(void) {
    // keys.txt resolves against the user data path initialize sets up; before that there is
    // no file to count, and "cannot answer" is not "zero keys".
    if (!g_initialized.load())
        return -1;
    return IOSTitleLaunch_ReloadAndCountKeys();
}

void cemu_bridge_prepare_keys_before_init(const char* mlcPath) {
    if (!mlcPath || mlcPath[0] == '\0')
        return;
    // Once the engine is initialized the key cache uses its own user data path and these names are never consulted.
    // Same layout IOSTitleLaunch_AdoptDroppedKeys() keeps in step after init: Documents/keys/keys.txt is the copy the
    // user sees and wins, Documents/mlc/keys.txt is the engine's.
    const fs::path userDataRoot(mlcPath);
    KeyCache_SetPreInitKeyFiles(userDataRoot.parent_path() / "keys" / "keys.txt", userDataRoot / "keys.txt");
}

double cemu_bridge_get_fps(void) {
    return g_framesPerSecond.load();
}

void cemu_bridge_get_progress(CemuBridgeProgress* out) {
    if (!out)
        return;
    *out = CemuBridgeProgress{};
    if (!g_titleRunning.load() || !CafeSystem::IsTitleRunning())
        return;
    out->gx2_init_reached = LatteGPUState.gx2InitCalled > 0;
    out->gx2_frame_count = LatteGPUState.frameCounter;
    out->gx2_frames_per_second = g_framesPerSecond.load();
    out->os_screen_scanouts = 0;
    out->guest_flip_requests = (unsigned int)LatteGPUState.flipRequestCount.load();
}

// ---------------------------------------------------------------------------
// Decrypt-to-Files / Decrypt-to-WUA. One at a time by design.
static std::atomic<bool> g_decryptRunning{false};
static std::atomic<bool> g_decryptCompleted{false};
static std::atomic<bool> g_decryptCancelRequested{false};
static std::atomic<int> g_decryptResultStatus{0};
static std::atomic<uint64_t> g_decryptBytesWritten{0};
static std::atomic<uint32_t> g_decryptFilesWritten{0};
static std::thread g_decryptThread;
static std::mutex g_decryptThreadMutex;

static bool StartDecryptJob(const std::function<int(const std::function<void(uint64_t, uint32_t)>&)>& job) {
    if (g_decryptRunning.exchange(true))
        return false;

    std::lock_guard lock{g_decryptThreadMutex};
    if (g_decryptThread.joinable())
        g_decryptThread.join();
    g_decryptCompleted.store(false);
    g_decryptCancelRequested.store(false);
    g_decryptBytesWritten.store(0);
    g_decryptFilesWritten.store(0);

    g_decryptThread = std::thread([job]() {
        auto progress = [](uint64_t bytesWritten, uint32_t filesWritten) {
            g_decryptBytesWritten.store(bytesWritten);
            g_decryptFilesWritten.store(filesWritten);
        };
        int status = 5; // IOS_DECRYPT_INCOMPLETE: an exception means the output can't be trusted
        try {
            status = job(progress);
        } catch (...) {
            std::string message = "decrypt: threw: " + cemu_describe_current_exception();
            cemu_bridge_log_checkpoint(message.c_str());
        }
        g_decryptResultStatus.store(status);
        g_decryptCompleted.store(true);
        g_decryptRunning.store(false);
    });
    return true;
}

bool cemu_bridge_start_decrypt(const char* srcPath, const char* destPath, bool toWua) {
    if (!srcPath || srcPath[0] == '\0' || !destPath || destPath[0] == '\0')
        return false;
    std::string src(srcPath);
    std::string dest(destPath);
    return StartDecryptJob([src, dest, toWua](const std::function<void(uint64_t, uint32_t)>& progress) {
        return toWua
            ? IOSTitleDecrypt_ExtractToWua(src.c_str(), dest.c_str(), g_decryptCancelRequested, progress)
            : IOSTitleDecrypt_ExtractToFolder(src.c_str(), dest.c_str(), g_decryptCancelRequested, progress);
    });
}

bool cemu_bridge_start_wua_build(const char* sourcePathsNewlineSeparated, const char* destPath) {
    if (!sourcePathsNewlineSeparated || !destPath || destPath[0] == '\0')
        return false;
    std::vector<std::string> sources;
    std::string list(sourcePathsNewlineSeparated);
    size_t start = 0;
    while (start <= list.size()) {
        size_t end = list.find('\n', start);
        if (end == std::string::npos)
            end = list.size();
        if (end > start)
            sources.push_back(list.substr(start, end - start));
        start = end + 1;
    }
    if (sources.empty())
        return false;
    std::string dest(destPath);
    return StartDecryptJob([sources, dest](const std::function<void(uint64_t, uint32_t)>& progress) {
        return IOSWuaContent_Build(sources, dest.c_str(), g_decryptCancelRequested, progress);
    });
}

int cemu_bridge_wua_list_titles(const char* wuaPath, char* outLines, size_t outSize) {
    if (!wuaPath || !outLines || outSize == 0)
        return -1;
    std::string lines = IOSWuaContent_ListTitles(wuaPath);
    int count = 0;
    for (char c : lines)
        if (c == '\n')
            count++;
    size_t length = std::min(lines.size(), outSize - 1);
    memcpy(outLines, lines.data(), length);
    outLines[length] = '\0';
    return count;
}

void cemu_bridge_get_decrypt_progress(CemuBridgeDecryptProgress* out) {
    if (!out)
        return;
    *out = CemuBridgeDecryptProgress{};
    out->is_running = g_decryptRunning.load();
    out->completed = g_decryptCompleted.load();
    out->result_status = g_decryptResultStatus.load();
    out->bytes_written = g_decryptBytesWritten.load();
    out->files_written = g_decryptFilesWritten.load();
}

void cemu_bridge_cancel_decrypt(void) {
    g_decryptCancelRequested.store(true);
}

bool cemu_bridge_derive_gametdb_id(const char* romPath, char* outGameID, size_t outGameIDSize) {
    if (!romPath || !outGameID || outGameIDSize < 7)
        return false;
    std::string id = IOSCoverArt_DeriveGameTdbId(romPath);
    if (id.size() != 6)
        return false;
    memcpy(outGameID, id.c_str(), 7);
    return true;
}

bool cemu_bridge_get_title_name(const char* romPath, char* outName, size_t outNameSize) {
    if (!romPath || !outName || outNameSize == 0)
        return false;
    const std::string name = IOSCoverArt_GetTitleName(romPath);
    if (name.empty())
        return false;
    // Truncate on a UTF-8 boundary, so a long Japanese title never ends in half a character.
    size_t length = std::min(name.size(), outNameSize - 1);
    while (length > 0 && length < name.size() && ((unsigned char)name[length] & 0xC0) == 0x80)
        length--;
    memcpy(outName, name.data(), length);
    outName[length] = '\0';
    return true;
}

bool cemu_bridge_derive_title_id(const char* romPath, uint64_t* outTitleId) {
    if (!romPath || !outTitleId)
        return false;
    return IOSDlcUpdateImport_DeriveTitleId(romPath, outTitleId);
}

bool cemu_bridge_read_tmd_title_id(const char* tmdPath, uint64_t* outTitleId) {
    return IOSDlcUpdateImport_ReadTmdTitleId(tmdPath, outTitleId);
}

uint64_t cemu_bridge_derive_base_title_id(uint64_t titleId) {
    return IOSDlcUpdateImport_DeriveBaseTitleId(titleId);
}

int cemu_bridge_get_title_type(uint64_t titleId) {
    return IOSDlcUpdateImport_GetTitleType(titleId);
}

void cemu_bridge_get_mlc_title_path_components(uint64_t titleId, char* outUpperHex, char* outLowerHex) {
    if (!outUpperHex || !outLowerHex)
        return;
    IOSDlcUpdateImport_GetMlcTitlePathComponents(titleId, outUpperHex, outLowerHex);
}

bool cemu_bridge_inspect_title(const char* romPath, uint64_t* outTitleId, uint16_t* outVersion,
    int* outRegion, int* outInvalidReason) {
    return IOSDlcUpdateImport_Inspect(romPath, outTitleId, outVersion, outRegion, outInvalidReason);
}

uint64_t cemu_bridge_derive_content_title_id(uint64_t baseTitleId, bool isUpdate) {
    return IOSDlcUpdateImport_DeriveContentTitleId(baseTitleId, isUpdate);
}

void cemu_bridge_graphic_packs_refresh(void) {
    IOSGraphicPacks_Refresh();
}

const char* cemu_bridge_graphic_packs_list(void) {
    static thread_local std::string g_graphicPacksList;
    g_graphicPacksList = IOSGraphicPacks_List();
    return g_graphicPacksList.c_str();
}

void cemu_bridge_graphic_pack_set_enabled(int index, bool enabled) {
    IOSGraphicPacks_SetEnabled(index, enabled);
}

// ---------------------------------------------------------------------------
// Wii U console accounts and each one's Network Service. See the doc comments in
// CemuBridge.h for the record/field shapes and what Custom does and doesn't need; the
// actual Account/NetworkService C++ calls live in IOSAccounts.cpp, same split as the
// graphic pack functions above.

const char* cemu_bridge_accounts_list(void) {
    static thread_local std::string g_accountsList;
    g_accountsList = IOSAccounts_List();
    return g_accountsList.c_str();
}

void cemu_bridge_accounts_refresh(void) {
    IOSAccounts_Refresh();
}

bool cemu_bridge_accounts_has_free_slot(void) {
    return IOSAccounts_HasFreeSlot();
}

uint32_t cemu_bridge_accounts_next_persistent_id(void) {
    return IOSAccounts_NextPersistentId();
}

uint32_t cemu_bridge_accounts_min_persistent_id(void) {
    return IOSAccounts_MinPersistentId();
}

bool cemu_bridge_accounts_locked(void) {
    return IOSAccounts_Locked();
}

bool cemu_bridge_account_create(uint32_t persistentId, const char* miiName, uint16_t birthYear,
    uint8_t birthMonth, uint8_t birthDay, int gender, const char* email, int country) {
    return IOSAccounts_Create(persistentId, miiName, birthYear, birthMonth, birthDay, gender, email, country);
}

bool cemu_bridge_account_delete(uint32_t persistentId) {
    return IOSAccounts_Delete(persistentId);
}

bool cemu_bridge_account_set_mii_name(uint32_t persistentId, const char* miiName) {
    return IOSAccounts_SetMiiName(persistentId, miiName);
}

bool cemu_bridge_account_set_gender(uint32_t persistentId, int gender) {
    return IOSAccounts_SetGender(persistentId, gender);
}

bool cemu_bridge_account_set_email(uint32_t persistentId, const char* email) {
    return IOSAccounts_SetEmail(persistentId, email);
}

bool cemu_bridge_account_set_country(uint32_t persistentId, int country) {
    return IOSAccounts_SetCountry(persistentId, country);
}

bool cemu_bridge_account_set_birthdate(uint32_t persistentId, uint16_t year, uint8_t month, uint8_t day) {
    return IOSAccounts_SetBirthdate(persistentId, year, month, day);
}

uint32_t cemu_bridge_active_account_persistent_id(void) {
    return IOSAccounts_ActivePersistentId();
}

void cemu_bridge_set_active_account_persistent_id(uint32_t persistentId) {
    IOSAccounts_SetActivePersistentId(persistentId);
}

int cemu_bridge_account_online_error(uint32_t persistentId) {
    return IOSAccounts_OnlineError(persistentId);
}

bool cemu_bridge_account_is_online_valid(uint32_t persistentId) {
    return IOSAccounts_IsOnlineValid(persistentId);
}

const char* cemu_bridge_countries_list(void) {
    static thread_local std::string g_countriesList;
    g_countriesList = IOSAccounts_CountriesList();
    return g_countriesList.c_str();
}

CemuBridgeNetworkService cemu_bridge_network_service(uint32_t persistentId) {
    return (CemuBridgeNetworkService)IOSAccounts_NetworkService(persistentId);
}

void cemu_bridge_set_network_service(uint32_t persistentId, CemuBridgeNetworkService service) {
    IOSAccounts_SetNetworkService(persistentId, (int)service);
}

bool cemu_bridge_custom_network_service_available(void) {
    return IOSAccounts_CustomNetworkServiceAvailable();
}

bool cemu_bridge_reload_custom_network_service(void) {
    return IOSAccounts_ReloadCustomNetworkService();
}

bool cemu_bridge_network_services_xml_is_valid(const char* path) {
    return IOSAccounts_IsValidNetworkServicesXML(path);
}

void cemu_bridge_set_device_network(CemuBridgeDeviceNetwork kind) {
    nn_ac::SetDeviceReachable(kind != CEMU_BRIDGE_DEVICE_NETWORK_OFFLINE);
}

bool cemu_bridge_console_appears_connected(void) {
    return nn_ac::IsConsoleConnected();
}

bool cemu_bridge_online_play_enabled(void) {
    return ActiveSettings::IsOnlineEnabled();
}

// ---------------------------------------------------------------------------
// Emulated toy-to-life devices. Enable flags are plain ConfigValue<bool>s nsyshid's own
// AttachDefaultBackends() reads when a title's nsyshid module loads (see
// Cafe/OS/libs/nsyshid/BackendEmulated.cpp) - same "takes effect next launch" timing as
// the other settings on this page. Figure management forwards to IOSEmulatedDevices.cpp,
// which owns the slot bookkeeping and talks to nsyshid::g_skyportal/g_infinitybase/
// g_dimensionstoypad directly. `device` crosses this boundary as CemuBridgeUSBDevice's
// own int values (0/1/2) - IOSEmulatedDevices.cpp mirrors them 1:1 as plain ints, the
// same convention IOSTitleLaunch.cpp uses for CemuBridgeStatus.

void cemu_bridge_set_emulate_skylander_portal(bool enabled) {
    GetConfig().emulated_usb_devices.emulate_skylander_portal = enabled;
}

bool cemu_bridge_emulate_skylander_portal(void) {
    return GetConfig().emulated_usb_devices.emulate_skylander_portal.GetValue();
}

void cemu_bridge_set_emulate_infinity_base(bool enabled) {
    GetConfig().emulated_usb_devices.emulate_infinity_base = enabled;
}

bool cemu_bridge_emulate_infinity_base(void) {
    return GetConfig().emulated_usb_devices.emulate_infinity_base.GetValue();
}

void cemu_bridge_set_emulate_dimensions_toypad(bool enabled) {
    GetConfig().emulated_usb_devices.emulate_dimensions_toypad = enabled;
}

bool cemu_bridge_emulate_dimensions_toypad(void) {
    return GetConfig().emulated_usb_devices.emulate_dimensions_toypad.GetValue();
}

int cemu_bridge_usb_device_slot_count(CemuBridgeUSBDevice device) {
    return IOSEmulatedDevices_SlotCount((int)device);
}

const char* cemu_bridge_usb_device_slot_names(CemuBridgeUSBDevice device) {
    static thread_local std::string g_usbDeviceSlotNames;
    g_usbDeviceSlotNames = IOSEmulatedDevices_SlotNames((int)device);
    return g_usbDeviceSlotNames.c_str();
}

const char* cemu_bridge_usb_device_figure_list(CemuBridgeUSBDevice device, int slot) {
    static thread_local std::string g_usbDeviceFigureList;
    g_usbDeviceFigureList = IOSEmulatedDevices_FigureList((int)device, slot);
    return g_usbDeviceFigureList.c_str();
}

const char* cemu_bridge_usb_device_load(CemuBridgeUSBDevice device, int slot, const char* path) {
    static thread_local std::string g_usbDeviceLoadError;
    g_usbDeviceLoadError = IOSEmulatedDevices_Load((int)device, slot, path);
    return g_usbDeviceLoadError.empty() ? nullptr : g_usbDeviceLoadError.c_str();
}

const char* cemu_bridge_usb_device_clear(CemuBridgeUSBDevice device, int slot) {
    static thread_local std::string g_usbDeviceClearError;
    g_usbDeviceClearError = IOSEmulatedDevices_Clear((int)device, slot);
    return g_usbDeviceClearError.empty() ? nullptr : g_usbDeviceClearError.c_str();
}

const char* cemu_bridge_usb_device_create(CemuBridgeUSBDevice device, uint32_t figureId, uint16_t variant, const char* path) {
    static thread_local std::string g_usbDeviceCreateError;
    g_usbDeviceCreateError = IOSEmulatedDevices_Create((int)device, figureId, variant, path);
    return g_usbDeviceCreateError.empty() ? nullptr : g_usbDeviceCreateError.c_str();
}

const char* cemu_bridge_usb_device_move_dimensions(int fromSlot, int toSlot) {
    static thread_local std::string g_usbDeviceMoveError;
    g_usbDeviceMoveError = IOSEmulatedDevices_MoveDimensions(fromSlot, toSlot);
    return g_usbDeviceMoveError.empty() ? nullptr : g_usbDeviceMoveError.c_str();
}

// ---------------------------------------------------------------------------
// amiibo. Desktop Cemu's "Load amiibo / NFC file": nnNfp_touchNfcTagFromFile() (Cafe/OS/libs/
// nn_nfp/nn_nfp.cpp) loads the NTAG215 dump as the tag on the reader and signals the title's
// activate event; the core lifts it again after about 1.5 seconds, the way a real tap does.
// The amiibo master keys are built into the core (amiiboInitMasterKeys), so no
// key_retail.bin is read from anywhere.
const char* cemu_bridge_touch_amiibo(const char* path) {
    static thread_local std::string g_amiiboError;
    if (!path || path[0] == '\0') {
        g_amiiboError = "No amiibo file was chosen.";
        return g_amiiboError.c_str();
    }
    if (!g_titleRunning.load() || !nnNfp_isInitialized()) {
        g_amiiboError = "No game is waiting for an amiibo right now. Start a game that uses amiibo, get to the point where it asks you to tap one, then scan again.";
        return g_amiiboError.c_str();
    }
    uint32_t nfcError = 0;
    if (nnNfp_touchNfcTagFromFile(fs::path(path), &nfcError)) {
        g_amiiboError.clear();
        return nullptr;
    }
    // The core's codes: 1 = the file could not be read, 2 = it is not an amiibo dump.
    g_amiiboError = (nfcError == 2)
        ? "That file isn't a valid amiibo dump. MuffinEMU needs a full amiibo dump (a .bin or .nfc file of 532 bytes or more, usually 540 or 572)."
        : "MuffinEMU couldn't read that amiibo file.";
    return g_amiiboError.c_str();
}

// ---------------------------------------------------------------------------
// Emulated timebase
//
// PPCTimer computes elapsedTick = (elapsedTick << 3) >> shift on a uint64, so a large
// enough shift stops the guest's clock outright. 10 is 1/128 real time.
static constexpr int kTimebaseShiftMin = 0;
static constexpr int kTimebaseShiftMax = 10;

void cemu_bridge_set_timebase_shift(int shift) {
    if (shift < kTimebaseShiftMin) shift = kTimebaseShiftMin;
    if (shift > kTimebaseShiftMax) shift = kTimebaseShiftMax;
    ActiveSettings::SetTimerShiftFactor((uint8)shift);
    cemuLog_log(LogType::Force, "Emulated timebase: shift {} ({:.4g}x real time)",
        shift, 8.0 / (double)(1u << shift));
}

int cemu_bridge_get_timebase_shift(void) {
    return (int)ActiveSettings::GetTimerShiftFactor();
}

void cemu_bridge_set_console_clock_offset(int64_t seconds) {
    CafeSystem::SetConsoleClockOffset((sint64)seconds);
    cemuLog_log(LogType::Force, "Console clock: {} s from real time at the next title start", (sint64)seconds);
}

bool cemu_bridge_advance_console_clock(int64_t seconds) {
    if (seconds <= 0 || !cemu_bridge_is_title_running())
        return false;
    coreinit::AdvanceConsoleClock((uint64)seconds * (uint64)ESPRESSO_TIMER_CLOCK);
    cemuLog_log(LogType::Force, "Console clock: moved forward {} s", (sint64)seconds);
    return true;
}

// The automatic clock ladder: while an interpreter boot has not reached GX2Init, step the
// guest's clock down a notch every twelve seconds, to a floor of 1/64, and log the value
// that got it through. A hand-picked value turns it off for good.
static constexpr int kLadderFloorShift = 9;
static constexpr int kLadderStepSeconds = 12;

static std::atomic<bool> g_timebaseAutoEnabled{true};
static std::atomic<bool> g_timebaseLadderRunning{false};
static std::thread g_timebaseLadderThread;
static std::mutex g_timebaseLadderMutex;

void cemu_bridge_set_timebase_auto_enabled(bool enabled) {
    const bool was = g_timebaseAutoEnabled.exchange(enabled);
    if (was == enabled)
        return;
    cemuLog_log(LogType::Force, "Emulated timebase: automatic clock ladder {}",
        enabled ? "enabled" : "disabled - a value was chosen by hand, so it stands");
}

bool cemu_bridge_timebase_auto_enabled(void) {
    return g_timebaseAutoEnabled.load();
}

static void ios_timebase_ladder_entry() {
    const auto start = std::chrono::steady_clock::now();
    // The clock this ladder inherited, so it can be put back.
    //
    // Everything below is a SEARCH, and a search that does not restore what it changed
    // is just damage. Without this the ladder would step the guest's clock down while a
    // title was slow to boot, watch the title boot anyway, conclude the slow clock was
    // "the value that worked", and leave it there for the rest of the session - so a
    // title that took 36 seconds to reach GX2Init then ran at an eighth speed forever.
    const int startShift = cemu_bridge_get_timebase_shift();
    auto lastStep = start;
    // Baselines from the first poll, not zero: a title that drew one frame and stopped
    // must not read as advancing.
    bool baselineTaken = false;
    unsigned long long baseGX2Frames = 0;
    unsigned int baseGuestFlipRequests = 0;
    while (g_timebaseLadderRunning.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (!g_timebaseLadderRunning.load() || !g_timebaseAutoEnabled.load() || !CafeSystem::IsTitleRunning())
            return;
        if (IOSTitlePause_IsPaused())
            continue;

        CemuBridgeProgress progress{};
        cemu_bridge_get_progress(&progress);
        const auto now = std::chrono::steady_clock::now();
        const double elapsed = std::chrono::duration<double>(now - start).count();

        if (!baselineTaken) {
            baselineTaken = true;
            baseGX2Frames = progress.gx2_frame_count;
            baseGuestFlipRequests = progress.guest_flip_requests;
        }

        const bool advancing = progress.gx2_init_reached ||
                               progress.gx2_frame_count > baseGX2Frames ||
                               progress.guest_flip_requests > baseGuestFlipRequests;
        if (advancing) {
            const int shift = cemu_bridge_get_timebase_shift();
            // Put the clock back once the title is advancing: it got past the stall because
            // it finished booting, not because the console was slowed, and keeping the slow
            // clock costs frame rate for the rest of the session. A title that needs a
            // slower clock has Settings > CPU > Timebase.
            if (shift != startShift) {
                cemuLog_log(LogType::Force,
                    "Emulated timebase: the title is advancing ({}) after {:.1f}s. Restoring the clock from "
                    "shift {} ({:.4g}x real time) to shift {} ({:.4g}x) - the ladder was searching for a way "
                    "past the stall, not choosing a speed to run at.",
                    progress.gx2_init_reached ? "GX2Init reached" : "guest output moving", elapsed,
                    shift, 8.0 / (double)(1u << shift),
                    startShift, 8.0 / (double)(1u << startShift));
                cemu_bridge_set_timebase_shift(startShift);
            } else {
                cemuLog_log(LogType::Force,
                    "Emulated timebase: the title is advancing ({}) after {:.1f}s with the clock untouched at "
                    "shift {} ({:.4g}x real time). Ladder stopped without having had to step.",
                    progress.gx2_init_reached ? "GX2Init reached" : "guest output moving",
                    elapsed, shift, 8.0 / (double)(1u << shift));
            }
            return;
        }

        if (now - lastStep < std::chrono::seconds(kLadderStepSeconds))
            continue;
        lastStep = now;

        const int shift = cemu_bridge_get_timebase_shift();
        if (shift >= kLadderFloorShift) {
            // And put it back on the way out. This branch has already concluded that the
            // guest's clock is not what is holding the title - so every step the ladder
            // took was wrong, and leaving the console at 1/64 speed on the strength of a
            // theory it just disproved is the worst of both.
            cemuLog_log(LogType::Force,
                "Emulated timebase: the ladder is at its floor - shift {} ({:.4g}x real time) - and after "
                "{:.1f}s the title still has not reached GX2Init. The guest's clock is not what is holding "
                "this title, so every step taken was wrong; restoring shift {} ({:.4g}x) and stopping.",
                shift, 8.0 / (double)(1u << shift), elapsed,
                startShift, 8.0 / (double)(1u << startShift));
            if (shift != startShift)
                cemu_bridge_set_timebase_shift(startShift);
            return;
        }

        cemuLog_log(LogType::Force,
            "Emulated timebase: no GX2Init after {:.1f}s, stepping the guest's clock down to shift {} "
            "({:.4g}x real time). This is the ladder searching, not a value anyone chose.",
            elapsed, shift + 1, 8.0 / (double)(1u << (shift + 1)));
        cemu_bridge_set_timebase_shift(shift + 1);
    }
}

static void ios_timebase_ladder_stop() {
    std::lock_guard lock{g_timebaseLadderMutex};
    g_timebaseLadderRunning.store(false);
    if (g_timebaseLadderThread.joinable())
        g_timebaseLadderThread.join();
}

static void ios_timebase_ladder_start() {
    ios_timebase_ladder_stop();
    if (!g_timebaseAutoEnabled.load())
        return;
    // Not under the recompiler, where the guest's clock and CPU are already in step.
    if (g_cpuMode.load() != kCpuModeInterpreter)
        return;
    std::lock_guard lock{g_timebaseLadderMutex};
    g_timebaseLadderRunning.store(true);
    g_timebaseLadderThread = std::thread(ios_timebase_ladder_entry);
    cemuLog_log(LogType::Force,
        "Emulated timebase: automatic clock ladder armed - if the title has not reached GX2Init after "
        "{}s the clock steps down one notch, to a floor of 1/64 real time.", kLadderStepSeconds);
}

uint32_t cemu_bridge_storage_read_fault_count(void) {
    return fscShortReadCount();
}

bool cemu_bridge_has_txm(void) {
    return ios_has_txm();
}

bool cemu_bridge_is_title_running(void) {
    // A title that called coreinit exit() has finished even though CafeSystem still holds it,
    // and the UI should see that as the end of the game rather than a frozen one.
    // A title switch (the Wii U Menu launching a game) has CafeSystem::IsTitleRunning() false
    // for a moment between the old title's shutdown and the new one's start. That is not the
    // end of the session, and reporting it as one would tear the emulator view down.
    if (g_titleRunning.load() && CafeSystem::IsTitleSwitchInProgress())
        return true;
    return g_titleRunning.load() && CafeSystem::IsTitleRunning() && !IOSSystemImplementation_TitleExited(nullptr);
}

// Called by the iOS SystemImplementation from the title-switch launcher thread. The
// renderer has to be rebuilt (ShutdownTitle() destroyed it), and desktop Cemu does its
// equivalent - recreating the canvas - on the UI thread, so this runs on the main thread
// and blocks until it is done. If the main thread is not responding within 10 seconds it is
// done on the calling thread instead rather than deadlocking the switch.
bool IOSBridge_RecreateRenderSurface() {
    struct State {
        std::atomic_bool claimed{false};
        std::atomic_bool ok{true};
    };
    auto state = std::make_shared<State>();
    auto work = [state]() {
        if (state->claimed.exchange(true))
            return;
        try
        {
            // The title that was just stopped by the switch went through the same clean-slate check as any other stop
            ios_check_clean_slate_after_stop();
            // The outgoing title's GPU state must not carry into the new renderer.
            ios_reset_video_stall_state();
            ios_apply_render_profile();
            CemuPrepareRenderer();
            ios_report_renderer_fallback();
        }
        catch (...)
        {
            state->ok.store(false);
            std::string message = "title switch: rebuilding the renderer threw: " + cemu_describe_current_exception();
            cemu_bridge_log_checkpoint(message.c_str());
        }
    };
    if ([NSThread isMainThread]) {
        work();
        return state->ok.load();
    }
    dispatch_group_t group = dispatch_group_create();
    dispatch_group_async(group, dispatch_get_main_queue(), ^{ work(); });
    if (dispatch_group_wait(group, dispatch_time(DISPATCH_TIME_NOW, 10 * NSEC_PER_SEC)) != 0) {
        cemuLog_log(LogType::Force, "iOS: title switch - the main thread did not respond in 10s, rebuilding the renderer on the launcher thread");
        work();
        // work() returns at once if the main thread got there first; wait for it to finish.
        dispatch_group_wait(group, DISPATCH_TIME_FOREVER);
    }
    return state->ok.load();
}

// Called by the Vulkan renderer (GPU or render-worker thread) when the GPU reports the device lost, a command buffer never
// finishes. Stops the title with a message the UI shows, and remembers the failure against this MoltenVK build so the next
// launch uses Metal, the same bookkeeping as a Vulkan start failure (ios_report_renderer_fallback).
void IOSBridge_VulkanDeviceLost(const char* why) {
    NSUserDefaults* defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:[NSString stringWithUTF8String:g_activeMoltenVK.c_str()] forKey:kVulkanFailedBuildKey];
    [defaults setObject:[NSString stringWithFormat:@"stopped while running: %s", (why && *why) ? why : "unknown"] forKey:kVulkanFailureReasonKey];
    ios_migrate_renderer_setting_to_metal();
    cemu_bridge_log_checkpoint((std::string("Renderer: Vulkan failed while running with MoltenVK ") + g_activeMoltenVK
        + " (" + (why ? why : "unknown") + "). The title is being stopped and the saved renderer is now Metal.").c_str());
    IOSSystemImplementation_ReportFatal("Vulkan stopped working while this game was running (the GPU stopped responding or ran out of memory), so the game was stopped. The renderer is back on Metal for the next launch; you can try Vulkan again in Settings > Graphics.");
}

// Called from the catch-all in Latte_ThreadEntry when an exception escapes the GPU thread, on any renderer. Nothing is torn down here:
// the GPU thread is the wrong place for it, and Metal had nothing else that stopped the title, so the GPU thread parked and the game
// froze with no crash log. This writes a crash-style entry (exception type, what(), and the GPU thread's backtrace at the catch site,
// since the throw site is already unwound) and raises the same fatal flag the core uses. That flag is only an atomic; the app polls
// it on the main thread, shows the message and runs cemu_bridge_shutdown_title(), the clean-slate stop path.
// Called by the Metal allocators when the device refuses a buffer (the first few times only). Writes where the address space and the
// footprint stand into CemuCrashLog.txt, so the next log says whether the limit hit was physical memory or the address space.
void IOSBridge_LogAllocationFailure(const char* what, uint64_t wantedBytes) {
    cemu_crash_open_log();
    cemu_vm_report(what, wantedBytes);
}

// Logged at title start: how much address space is still free below the highest mapping, and the largest single hole.
// A buffer bigger than the largest hole cannot be created however much memory is free, so this is the number to watch.
void IOSBridge_LogFreeAddressSpace(const char* when) {
    uint64_t total = 0, largest = 0, largestAt = 0, atLeast256 = 0, prevEnd = 0, highestEnd = 0;
    vm_address_t addr = 0;
    natural_t depth = 0;
    for (int guard = 0; guard < 200000; guard++) {
        vm_size_t size = 0;
        vm_region_submap_info_data_64_t info;
        mach_msg_type_number_t count = VM_REGION_SUBMAP_INFO_COUNT_64;
        if (vm_region_recurse_64(mach_task_self(), &addr, &size, &depth, (vm_region_recurse_info_t)&info, &count) != KERN_SUCCESS)
            break;
        if (info.is_submap) { depth++; continue; }
        if (prevEnd != 0 && addr > prevEnd) {
            const uint64_t gap = (uint64_t)addr - prevEnd;
            total += gap;
            if (gap >= (256ull << 20)) atLeast256++;
            if (gap > largest) { largest = gap; largestAt = prevEnd; }
        }
        prevEnd = (uint64_t)addr + size;
        highestEnd = prevEnd;
        addr += size;
    }
    cemuLog_log(LogType::Force, "Address space ({}): largest free hole {} MB at {:#x}, {} hole(s) of 256 MB or more, {} MB free in total below the highest mapping at {:#x}",
        when ? when : "?", largest >> 20, largestAt, atLeast256, total >> 20, highestEnd);
}

void IOSBridge_GPUThreadException(const char* type, const char* what) {
    cemu_crash_open_log();
    cemu_bridge_log_checkpoint("\n=== GPU THREAD EXCEPTION ===");
    cemu_bridge_log_checkpoint((std::string("uncaught C++ exception on the GPU thread, type: ") + (type && *type ? type : "unknown")).c_str());
    cemu_bridge_log_checkpoint((std::string("what(): ") + (what && *what ? what : "(none)")).c_str());
    cemu_bridge_log_checkpoint("GPU thread backtrace (where it was caught):");
    void* frames[32];
    const int count = backtrace(frames, 32);
    if (g_crashLogFd >= 0)
        backtrace_symbols_fd(frames, count, g_crashLogFd);
    cemu_bridge_log_checkpoint("=== the title is being stopped ===");
    IOSSystemImplementation_ReportFatal("The graphics engine hit an error and the game was stopped. Use Share diagnostics on the next screen if you report it.");
}

void cemu_bridge_pause(void) {
    IOSTitlePause_Pause();
}

void cemu_bridge_resume(void) {
    IOSTitlePause_Resume();
}

bool cemu_bridge_save_state(const char* path) {
    if (!path || !*path)
        return false;
    return IOSSaveState_Save(path);
}

bool cemu_bridge_load_state(const char* path) {
    if (!path || !*path)
        return false;
    return IOSSaveState_Load(path);
}

const char* cemu_bridge_save_state_last_error(void) {
    return IOSSaveState_LastErrorMessage();
}

int cemu_bridge_save_state_last_error_code(void) {
    return IOSSaveState_LastErrorCode();
}

int cemu_bridge_save_state_inspect(const char* path) {
    return IOSSaveState_InspectFile(path);
}

void cemu_bridge_shutdown_title(void) {
    cemu_bridge_memory_note("before title shutdown");
    ios_timebase_ladder_stop();
    ios_two_core_watch_stop();
    // Suspended guest threads cannot be joined, so a paused title is resumed first.
    IOSTitlePause_Resume();
    IOSTitlePause_Forget();
    if (CafeSystem::IsTitleRunning())
        CafeSystem::ShutdownTitle();
    ios_check_clean_slate_after_stop();
    // A title that ran has its renderer deleted by the GPU thread when ShutdownTitle() stops it, so this is normally a
    // no-op. It still matters when a launch failed before the GPU thread started: the renderer CemuRun() built is then
    // left, and dropping it here makes the next CemuRun() build a fresh one for whatever graphics API is configured
    // then, instead of reusing a renderer whose layers belong to views Swift has since replaced.
    g_renderer.reset();
    g_titleRunning.store(false);
    g_framesPerSecond.store(0.0);
    ios_reset_video_stall_state();
    cemu_bridge_release_all_buttons();
    cemu_bridge_memory_note("after title shutdown");
    setStatus("Title shut down.");
}

static std::atomic<CemuTitleSwitchCallback> g_titleSwitchCallback{nullptr};

void cemu_bridge_set_title_switch_callback(CemuTitleSwitchCallback callback) {
    g_titleSwitchCallback.store(callback);
}

void IOSBridge_TitleSwitching(uint64_t titleId) {
    // The Menu is gone and a different title is about to start: save states taken so far belong to the old one.
    IOSSaveState_BeginSession();
    if (CemuTitleSwitchCallback callback = g_titleSwitchCallback.load())
        callback(titleId);
}

bool cemu_bridge_clean_start_required(void) {
    return g_cleanStartRequired.load();
}

const char* cemu_bridge_clean_start_reason(void) {
    static thread_local std::string reason;
    {
        std::lock_guard<std::mutex> lock(g_cleanStartMutex);
        reason = g_cleanStartReason;
    }
    return reason.c_str();
}

void cemu_bridge_shutdown(void) {
    g_initializationComplete.store(false);
    cemu_bridge_shutdown_title();
    CemuShutdown();
    g_initialized.store(false);
    setStatus("Cemu core shut down.");
}

void cemu_bridge_set_menu_input_callback(CemuMenuInputCallback callback) {
    g_menuCallback.store(callback);
}

void cemu_bridge_set_menu_capture(bool capture) {
    g_menuCapture.store(capture);
    // Applies at once rather than at the controller's next change: the game has to stop seeing what is held now, and on
    // the way out it has to start ignoring it until it is let go.
    dispatch_async(dispatch_get_main_queue(), ^{
        if (GCExtendedGamepad* pad = g_boundController.extendedGamepad)
            ios_update_physical(pad);
    });
}

void cemu_bridge_refresh_input_devices(void) {
    dispatch_async(dispatch_get_main_queue(), ^{
        ios_bind_first_controller();
    });
}

void cemu_bridge_set_button_state(CemuBridgeButton button, bool pressed) {
    const int bit = ios_button_bit(button);
    if (bit < 0)
    {
        if (button == CEMU_BRIDGE_BUTTON_HOME && !g_homeWarned)
        {
            g_homeWarned = true;
            cemuLog_log(LogType::Force, "iOS input: HOME has no binding in the core's GamePad mapping, so it is ignored (the app opens its HOME menu from HOME and should not send it here)");
        }
        return;
    }
    const uint32_t mask = 1u << bit;
    const auto now = std::chrono::steady_clock::now();
    std::lock_guard lock(g_inputMutex);
    if (pressed)
    {
        // Already queued to come back down: the finger is simply down again.
        if ((g_touchRepress | g_touchRepressQueued) & mask)
        {
            g_touchRepressReleased &= ~mask;
            return;
        }
        if (!(g_touchButtons & mask))
        {
            g_touchButtons |= mask;
            g_touchSeen &= ~mask;
            g_touchPendingRelease &= ~mask;
            g_touchPressedAt[bit] = now;
            return;
        }
        if (g_touchPendingRelease & mask)
        {
            // Lifted and pressed again before the latch let go. If a read saw the first
            // press, the title needs an up and a second down; if none did, there is only
            // one press to report and it simply continues.
            if (g_touchSeen & mask)
                g_touchRepress |= mask;
            else
                g_touchPendingRelease &= ~mask;
        }
        // Otherwise a repeat "down" for a held button: a no-op, so the pad may re-assert
        // a press freely without restarting the latch.
    }
    else
    {
        if ((g_touchRepress | g_touchRepressQueued) & mask)
        {
            g_touchRepressReleased |= mask;
            return;
        }
        if (!(g_touchButtons & mask))
            return;
        if (ios_touch_release_due(bit, now))
        {
            g_touchButtons &= ~mask;
            g_touchSeen &= ~mask;
            g_touchPendingRelease &= ~mask;
        }
        else
        {
            g_touchPendingRelease |= mask;
        }
    }
}

// ---------------------------------------------------------------------------
// Input introspection
//
// The GamePad's button mappings live in C++ (InputManager / EmulatedController) and are
// persisted to controllerProfiles/controller{N} on the device. These functions let Swift
// see them, so a state where every on-screen button is dead but the sticks work can be
// diagnosed from the app.
//
// Axes reach the emulated controller directly, while every button goes through the
// mapping table, so "sticks respond but no button does" means the controller has no
// button mappings (for example from a stale profile on disk). These functions report
// the binding count and the profile name, and reset the bindings.

int cemu_bridge_input_button_mapping_count(void) {
    auto vpad = InputManager::instance().get_vpad_controller(0);
    if (!vpad)
        return -1;   // no GamePad wired at all - distinct from "wired, zero bindings"
    int count = 0;
    // Buttons only: the ids from A up to StickR. Everything at StickL_Up and beyond is an
    // AXIS mapping (VPADController::is_axis_mapping), and counting those would report a
    // healthy number for exactly the broken case this is meant to detect - sticks bound,
    // buttons not.
    for (uint64 id = VPADController::kButtonId_A; id < VPADController::kButtonId_StickL_Up; ++id)
    {
        if (vpad->get_mapping_controller(id))
            count++;
    }
    return count;
}

const char* cemu_bridge_input_profile_name(void) {
    static thread_local std::string name;
    auto vpad = InputManager::instance().get_vpad_controller(0);
    name = vpad ? vpad->get_profile_name() : std::string("<no controller>");
    return name.c_str();
}

bool cemu_bridge_reset_controller_bindings(void) {
    // Deletes the persisted profile as well as the in-memory controller, then re-runs the
    // provider wiring - which is the one path that calls apply_default_gc_mappings(). A
    // reset that only cleared memory would be undone by the same bad profile on the next
    // launch, which is the failure it exists to cure.
    InputManager::instance().delete_controller(0, /*delete_profile*/ true);
    InputManager::instance().load_gc_controllers();
    const int bindings = cemu_bridge_input_button_mapping_count();
    cemuLog_log(LogType::Force, "iOS input: controller bindings reset; GamePad now has {} button mappings", bindings);
    return bindings > 0;
}

void cemu_bridge_set_stick_axis(CemuBridgeStick stick, float x, float y) {
    // Clamped by magnitude so a diagonal cannot ask for more deflection than a stick has.
    const float magnitude = std::sqrt(x * x + y * y);
    if (magnitude > 1.0f) {
        x /= magnitude;
        y /= magnitude;
    }
    if (std::isnan(x) || std::isnan(y))
        return;
    // CemuBridge's convention (+y up) is also GCBridge's.
    std::lock_guard lock(g_inputMutex);
    g_touchSticks[stick == CEMU_BRIDGE_STICK_RIGHT ? 1 : 0] = GCBridgeVec2{x, y};
}

void cemu_bridge_release_all_buttons(void) {
    std::lock_guard lock(g_inputMutex);
    // Immediate, bypassing the latch: this is the "nothing may stay held" path (pause,
    // pad hidden, app backgrounded).
    g_touchButtons = 0;
    g_touchSeen = 0;
    g_touchPendingRelease = 0;
    g_touchRepress = 0;
    g_touchRepressQueued = 0;
    g_touchRepressReleased = 0;
    g_touchSticks[0] = g_touchSticks[1] = GCBridgeVec2{};
}

const char* cemu_bridge_status_text(void) {
    int exitStatus = 0;
    if (const char* fatal = IOSSystemImplementation_FatalReason())
    {
        setStatus(fatal);
    }
    else if (g_titleRunning.load() && IOSSystemImplementation_TitleExited(&exitStatus))
    {
        char line[96];
        snprintf(line, sizeof(line), "The game closed itself (exit status %d).", exitStatus);
        const std::string hint = IOSAccounts_OnlineHint();
        setStatus((hint.empty() ? std::string(line) : std::string(line) + " If it closed after an online account prompt: " + hint).c_str());
    }
    if (g_titleRunning.load() && IOSSystemImplementation_TitleSwitchFailed() && IOSSystemImplementation_SystemAppletRequested())
        setStatus("The game tried to open the Wii U's account or system settings, which MuffinEMU can't run. A Pretendo ID can't be created or linked inside MuffinEMU: link it on a real Wii U, then import that console's account.dat, otp.bin and seeprom.bin in Settings > Network Service.");
    else if (g_titleRunning.load() && IOSSystemImplementation_TitleSwitchFailed())
        setStatus("The Wii U Menu tried to open another title and it couldn't be started. Check that game is in your library and its keys are installed, then launch it from the library instead.");
    // Only fall back to a computed default when nothing specific has been set, so a boot
    // failure's reason is not overwritten by a generic line on the next read.
    if (statusIsEmpty())
        setStatus(cemu_bridge_is_title_running() ? "Title running." : "Core ready (no title running).");
    return getStatus();
}

void LatteRenderTarget_SetSkipHiddenOutputs(bool tv, bool pad);

void cemu_bridge_set_skip_hidden_screen(bool tv, bool pad) {
    LatteRenderTarget_SetSkipHiddenOutputs(tv, pad);
}

// Two-core guard. A two-core run cannot be turned into a one-core run while the title is up, so a
// run that never reaches GX2Init is remembered and the next launch of that title uses one core.
static constexpr int kTwoCoreGx2InitSeconds = 240;
static std::atomic<bool> g_twoCoreWatchRunning{false};
static std::thread g_twoCoreWatchThread;
static std::mutex g_twoCoreWatchMutex;

static void ios_two_core_watch_entry(uint64_t titleId) {
    int waitedHalfSeconds = 0;
    while (g_twoCoreWatchRunning.load()) {
        std::this_thread::sleep_for(std::chrono::milliseconds(500));
        if (!g_twoCoreWatchRunning.load() || !CafeSystem::IsTitleRunning())
            return;
        if (IOSTitlePause_IsPaused())
            continue;
        if (LatteGPUState.gx2InitCalled > 0) {
            ios_two_core_hang_set(titleId, false);
            cemuLog_log(LogType::Force, "CPU cores: the two-core run reached GX2Init after {:.1f}s", waitedHalfSeconds / 2.0);
            return;
        }
        if (++waitedHalfSeconds >= kTwoCoreGx2InitSeconds * 2) {
            ios_two_core_hang_set(titleId, true);
            cemuLog_log(LogType::Force, "CPU cores: the two-core run has not reached GX2Init after {}s. The next launch of this title uses one core.",
                kTwoCoreGx2InitSeconds);
            return;
        }
    }
}

static void ios_two_core_watch_stop() {
    std::lock_guard lock{g_twoCoreWatchMutex};
    g_twoCoreWatchRunning.store(false);
    if (g_twoCoreWatchThread.joinable())
        g_twoCoreWatchThread.join();
}

static void ios_two_core_watch_start() {
    ios_two_core_watch_stop();
    if (g_coresRunning.load() != 2)
        return;
    std::lock_guard lock{g_twoCoreWatchMutex};
    g_twoCoreWatchRunning.store(true);
    g_twoCoreWatchThread = std::thread(ios_two_core_watch_entry, (uint64_t)CafeSystem::GetForegroundTitleId());
}
