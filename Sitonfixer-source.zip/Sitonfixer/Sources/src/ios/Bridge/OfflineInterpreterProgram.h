// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
#pragma once
#include <array>
#include <cstdint>
namespace OfflineInterpreterProgram {
constexpr uint32_t storageSize = 4096, callerOffset = 64, calleeOffset = 320;
constexpr uint32_t dataOffset = 1024, dataSize = 64, storeOffset = dataOffset + 16;
// Same instruction semantics as revision13, relocated into Cemu-owned memory.
// mflr r10; add r6,r3,r4; bl B; mtlr r10; addi r9,r8,3; blr
constexpr std::array<uint32_t, 6> caller{
    0x7d4802a6, 0x7cc32214, 0x480000f9, 0x7d4803a6, 0x39280003, 0x4e800020};
// stw r6,16(r5); lwz r7,16(r5); addi r8,r7,5; blr
constexpr std::array<uint32_t, 4> callee{
    0x90c50010, 0x80e50010, 0x39070005, 0x4e800020};
constexpr std::array<uint32_t, 10> trace{
    callerOffset, callerOffset+4, callerOffset+8,
    calleeOffset, calleeOffset+4, calleeOffset+8, calleeOffset+12,
    callerOffset+12, callerOffset+16, callerOffset+20};
}
