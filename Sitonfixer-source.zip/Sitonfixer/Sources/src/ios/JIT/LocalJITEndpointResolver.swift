// Experimental local endpoint discovery for a MuffinEMU-derived app.
// SPDX-License-Identifier: GPL-3.0-only
// No Internet endpoints, pairing reads, USB transports or JIT activation here.
// TCP reachability is not proof of a valid pairing or prepared executable memory.
import Foundation
import Network

struct LocalJITEndpoint {
    let host: String
    let port: UInt16
    let source: String
}

enum LocalJITEndpointFailure: LocalizedError {
    case unreachable
    var errorDescription: String? {
        "No se puede alcanzar el servicio local de depuración. La VPN puede figurar conectada sin que el túnel responda. No se ha iniciado el juego ni cambiado el emparejamiento."
    }
}

/// Discovers only services advertised on loopback. A different device on the LAN
/// must never supply the debug port for this iPhone. A literal private peer address
/// is then probed through the existing local VPN, without DNS or an Internet test.
final class LocalJITEndpointResolver {
    private static let cacheKey = "sitonfixer.localJIT.endpoint.v1"
    private let queue = DispatchQueue(label: "sitonfixer.localJIT.endpoint")
    private let defaults: UserDefaults
    private var browser: NWBrowser?
    private var resolving: [NWConnection] = []
    private var probe: NWConnection?
    private var discovered = Set<UInt16>()
    private var candidates: [(UInt16, String)] = []
    private var completion: ((Result<LocalJITEndpoint, Error>) -> Void)?
    private var discoveryFinished = false
    private var attempt = 0
    private var finished = false
    private var deadline: DispatchWorkItem?

    init(defaults: UserDefaults = .standard) { self.defaults = defaults }

    static func resolve() async throws -> LocalJITEndpoint {
        let resolver = LocalJITEndpointResolver()
        defer { withExtendedLifetime(resolver) {} }
        let endpoint: LocalJITEndpoint = try await withCheckedThrowingContinuation { continuation in
            resolver.queue.async {
                resolver.start { continuation.resume(with: $0) }
            }
        }
        try Task.checkCancellation()
        return endpoint
    }

    private func start(completion: @escaping (Result<LocalJITEndpoint, Error>) -> Void) {
        self.completion = completion
        let parameters = NWParameters.tcp
        parameters.includePeerToPeer = true
        let browser = NWBrowser(
            for: .bonjour(type: "_remotepairing._tcp", domain: "local."),
            using: parameters)
        self.browser = browser
        browser.browseResultsChangedHandler = { [weak self] results, _ in
            guard let self, !self.discoveryFinished else { return }
            for result in results {
                guard result.interfaces.contains(where: {
                    $0.type == .loopback || $0.name.hasPrefix("lo")
                }), case .service = result.endpoint else { continue }
                self.resolveService(result.endpoint, parameters: parameters)
            }
        }
        browser.stateUpdateHandler = { [weak self] state in
            if case .failed = state { self?.finishDiscovery() }
        }
        browser.start(queue: queue)
        let work = DispatchWorkItem { self.finishDiscovery() }
        deadline = work
        queue.asyncAfter(deadline: .now() + 2, execute: work)
    }

    private func resolveService(_ endpoint: NWEndpoint, parameters: NWParameters) {
        // Bound the work if Bonjour repeatedly emits the same local service.
        guard resolving.count < 8 else { return }
        let connection = NWConnection(to: endpoint, using: parameters)
        resolving.append(connection)
        connection.pathUpdateHandler = { [weak self, weak connection] _ in
            guard let self, let connection else { return }
            self.recordPort(from: connection)
        }
        connection.stateUpdateHandler = { [weak self, weak connection] _ in
            guard let self, let connection else { return }
            self.recordPort(from: connection)
        }
        connection.start(queue: queue)
    }

    private func recordPort(from connection: NWConnection) {
        guard !discoveryFinished,
              case .hostPort(_, let port) = connection.currentPath?.remoteEndpoint,
              port.rawValue != 0 else { return }
        discovered.insert(port.rawValue)
    }

    private func finishDiscovery() {
        guard !discoveryFinished, !finished else { return }
        discoveryFinished = true
        deadline?.cancel()
        deadline = nil
        browser?.cancel()
        browser = nil
        for connection in resolving { connection.cancel() }
        resolving.removeAll()
        candidates = discovered.sorted().map { ($0, "Bonjour local") }
        if let cached = defaults.dictionary(forKey: Self.cacheKey),
           let port = cached["port"] as? Int,
           let date = cached["date"] as? Date,
           (1...65535).contains(port),
           (0...86400).contains(Date().timeIntervalSince(date)),
           !discovered.contains(UInt16(port)) {
            candidates.append((UInt16(port), "Caché local; comprobada de nuevo"))
        }
        if !candidates.contains(where: { $0.0 == 49152 }) {
            candidates.append((49152, "Puerto de compatibilidad; comprobado"))
        }
        probeNext()
    }

    private func probeNext() {
        guard !finished else { return }
        guard !candidates.isEmpty else {
            finish(.failure(LocalJITEndpointFailure.unreachable))
            return
        }
        let (port, source) = candidates.removeFirst()
        attempt += 1
        let token = attempt
        let host = "10.7.0.1"
        let connection = NWConnection(host: NWEndpoint.Host(host),
            port: NWEndpoint.Port(rawValue: port)!, using: .tcp)
        probe = connection
        connection.stateUpdateHandler = { [weak self, weak connection] state in
            guard let self, let connection, !self.finished,
                  self.attempt == token, self.probe === connection else { return }
            switch state {
            case .ready:
                self.defaults.set(["port": Int(port), "date": Date()], forKey: Self.cacheKey)
                self.finish(.success(LocalJITEndpoint(host: host, port: port, source: source)))
            case .failed:
                self.advanceProbe(connection)
            default:
                break
            }
        }
        connection.start(queue: queue)
        let work = DispatchWorkItem { [weak self, weak connection] in
            guard let self, let connection, !self.finished,
                  self.attempt == token, self.probe === connection else { return }
            self.advanceProbe(connection)
        }
        deadline = work
        queue.asyncAfter(deadline: .now() + 2, execute: work)
    }

    private func advanceProbe(_ connection: NWConnection) {
        probe = nil
        deadline?.cancel()
        deadline = nil
        connection.cancel()
        probeNext()
    }

    private func finish(_ result: Result<LocalJITEndpoint, Error>) {
        guard !finished else { return }
        finished = true
        deadline?.cancel()
        deadline = nil
        browser?.cancel()
        probe?.cancel()
        probe = nil
        let callback = completion
        completion = nil
        callback?(result)
    }
}
