// MuffinEMU — code by the MuffinEMU Development Team.
// Copyright (c) 2026 MuffinEMU Development Team (Void).
// SPDX-License-Identifier: GPL-3.0-only
// Additional terms under GPL-3.0 section 7(b) and 7(c) apply: see ATTRIBUTION.md in the repository root.
//
// The host side of built-in JIT: gather what the helper needs, launch it, and keep
// the result. The actual device-link work runs in the helper extension; the host only
// assembles the request (its own PID, the pairing file, the TXM and DDI-format facts)
// and reads the result and log back.

import Foundation

@MainActor
final class JITCoordinator: ObservableObject {
    static let shared = JITCoordinator()

    /// The identifier the helper is built with. NOT what to look it up by at runtime: a re-signer
    /// (SideStore, AltStore, a custom certificate) rewrites every bundle identifier to fit the signing
    /// Apple ID, so the INSTALLED extension's id is usually not this. Kept only as the last-ditch fallback.
    static let buildTimeHelperIdentifier = "com.void.muffinemu.jithelper"

    /// Where the last run's log is kept for Copy bug report.
    static let lastLogKey = "muffin.jit.lastLog"

    /// The JIT helper app extension as actually installed: its real bundle identifier and location,
    /// read from the embedded `.appex`. This is what `NSExtension extensionWithIdentifier:` needs —
    /// looking the helper up by the build-time id fails after a re-sign, which showed as "the JIT
    /// helper isn't available in this build" even with the extension installed. `nil` means no
    /// extension is embedded at all (some installers drop app extensions on a free Apple ID).
    static var embeddedHelper: (identifier: String, url: URL)? {
        guard let plugins = Bundle.main.builtInPlugInsURL,
              let entries = try? FileManager.default.contentsOfDirectory(at: plugins, includingPropertiesForKeys: nil)
        else { return nil }
        let appexes = entries.filter { $0.pathExtension == "appex" }
        // Prefer the one whose bundle name is the JIT helper, in case other extensions ship later.
        let chosen = appexes.first { $0.lastPathComponent.localizedCaseInsensitiveContains("JITHelper") } ?? appexes.first
        guard let url = chosen, let bundle = Bundle(url: url), let id = bundle.bundleIdentifier else { return nil }
        return (id, url)
    }

    /// The identifier to launch by: the installed extension's real id, or the build-time id if none was found.
    static var helperIdentifier: String { embeddedHelper?.identifier ?? buildTimeHelperIdentifier }

    @Published var isRunning = false
    @Published var lastMessage: String?
    /// The most recent helper log, folded into Copy bug report.
    @Published private(set) var lastLog: [String] = []

    enum CoordinatorError: LocalizedError {
        case oldOS
        case liveContainer
        case noEntitlement
        case noPairing
        case helperMissing
        case helper(String)

        var errorDescription: String? {
            switch self {
            case .oldOS:
                return "Built-in JIT needs iOS 17.4 or later."
            case .liveContainer:
                return "Built-in JIT can't run inside LiveContainer. Open MuffinEMU on its own, or use a JIT enabler."
            case .noEntitlement:
                return "This install doesn't have get-task-allow, so JIT can't attach. Reinstall MuffinEMU with a signing method that keeps it."
            case .noPairing:
                return "Import a pairing file first (or pair on this device on iOS 27)."
            case .helperMissing:
                return "The JIT helper extension isn't in this install, so built-in JIT can't run. Reinstall MuffinEMU and keep the MuffinJITHelper extension — some installers drop app extensions on a free Apple ID. You can also use a JIT enabler (StikJIT, SideStore or LiveContainer) instead."
            case .helper(let message):
                return message
            }
        }
    }

    /// Runs the full enable flow for this process. Returns the final status line.
    @discardableResult
    func enableJIT() async throws -> String {
        guard !isRunning else { throw CoordinatorError.helper("Ya hay una preparación JIT en curso.") }
        isRunning = true
        defer { isRunning = false }
        guard JITEnvironment.meetsMinimumOS else { throw CoordinatorError.oldOS }
        guard !JITEnvironment.isLiveContainer else { throw CoordinatorError.liveContainer }
        guard JITEntitlement.hasGetTaskAllow else { throw CoordinatorError.noEntitlement }
        // If the extension was dropped at install, say so plainly instead of the generic launcher error.
        guard let helper = Self.embeddedHelper else { throw CoordinatorError.helperMissing }
        guard let pairing = JITPairing.read() else { throw CoordinatorError.noPairing }

        let endpoint = try await LocalJITEndpointResolver.resolve()

        let request = JITHelperRequest(
            targetPID: getpid(),
            pairingFile: pairing,
            deviceIP: endpoint.host,
            rsdPort: endpoint.port,
            usesCryptexDDI: JITEnvironment.usesCryptexDDI,
            txm: JITEnvironment.isTXM,
            allowOnlinePreparation: UserDefaults.standard.bool(forKey: "sitonfixer.allowOnlinePreparation"))
        let requestData = try JSONEncoder().encode(request)

        // The top-bar pill turns yellow while the last attempt stands failed.
        UserDefaults.standard.set(true, forKey: JITPillModel.lastRunFailedKey)
        let resultData = try await runHelper(requestData, identifier: helper.identifier)
        let result = try JSONDecoder().decode(JITHelperResult.self, from: resultData)
        lastLog = result.log
        lastMessage = result.message
        // Persisted plainly so Copy bug report can read it without actor hops.
        UserDefaults.standard.set(result.log, forKey: Self.lastLogKey)
        if !result.success {
            throw CoordinatorError.helper(result.message)
        }
        UserDefaults.standard.set(false, forKey: JITPillModel.lastRunFailedKey)
        return result.message
    }

    /// The JIT log for the bug report: the last run's stages, newest run only.
    var bugReportLines: [String] {
        guard !lastLog.isEmpty else { return [] }
        let idLine = "helper id: " + Self.helperIdentifier
        return ["--- built-in JIT ---", idLine] + lastLog
    }

    private func runHelper(_ data: Data, identifier: String) async throws -> Data {
        try await withCheckedThrowingContinuation { continuation in
            MuffinJITLauncher.run(extensionIdentifier: identifier, requestData: data) { resultData, error in
                if let resultData {
                    continuation.resume(returning: resultData)
                } else {
                    let message = error?.localizedDescription ?? "The JIT helper didn't respond."
                    continuation.resume(throwing: CoordinatorError.helper(message))
                }
            }
        }
    }
}
