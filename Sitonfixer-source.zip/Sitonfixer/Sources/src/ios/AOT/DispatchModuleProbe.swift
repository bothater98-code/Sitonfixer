// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Darwin

/// Two different trusted PPC functions. All native pointer borrows cover the
/// entire cross-module execution; no pointer is published to a game thread.
enum DispatchModuleProbe {
    private typealias Prepare = @convention(c) (UInt32, UnsafeMutablePointer<UInt8>?, Int, UnsafeMutablePointer<Int>?, UnsafeMutablePointer<Int>?, Int) -> Int32
    private typealias Check = @convention(c) (UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UInt32, UnsafeMutablePointer<Int>?) -> Int32
    private typealias Sign = @convention(c) (UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafeMutablePointer<UnsafeMutablePointer<CChar>?>?) -> Int32
    private typealias Free = @convention(c) (UnsafeMutablePointer<CChar>?) -> Void
    private static func failure(_ message: String) -> OfflineProbe.Failure { .init(message: "SF-DISPATCH: " + message) }

    static func run(certificate: Data, password: String) throws -> String {
        try OfflineProbe.requireCleanProcess()
        guard !certificate.isEmpty, certificate.count <= 1_048_576, !password.contains("\0"),
              let profileURL = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let templateURL = Bundle.main.url(forResource: "scalar-probe", withExtension: "bin")
                ?? Bundle.main.url(forResource: "scalar-probe", withExtension: "bin", subdirectory: "AOT") else {
            throw failure("faltan certificado, perfil o plantilla válidos.")
        }
        let profile = try Data(contentsOf: profileURL), template = try Data(contentsOf: templateURL)
        guard profile.count <= 1_048_576 else { throw failure("perfil demasiado grande.") }
        let root = Bundle.main.privateFrameworksPath ?? ""
        guard let signer = dlopen(root + "/MuffinJITPairing.framework/MuffinJITPairing", RTLD_NOW | RTLD_LOCAL) else { throw failure("no se puede abrir el firmador.") }
        defer { dlclose(signer) }
        guard let core = dlopen(root + "/Cemu.framework/Cemu", RTLD_NOW | RTLD_LOCAL) else { throw failure("no se puede abrir Cemu.") }
        defer { dlclose(core) }
        guard let signAddress = dlsym(signer, "sitonfixer_sign_probe"),
              let freeAddress = dlsym(signer, "muffin_jit_string_free"),
              let prepareAddress = dlsym(core, "sitonfixer_dispatch_probe_prepare"),
              let checkAddress = dlsym(core, "sitonfixer_dispatch_probe_check") else { throw failure("faltan las funciones de despacho.") }
        let sign = unsafeBitCast(signAddress, to: Sign.self), free = unsafeBitCast(freeAddress, to: Free.self)
        let prepare = unsafeBitCast(prepareAddress, to: Prepare.self), check = unsafeBitCast(checkAddress, to: Check.self)
        func signFile(_ file: URL) throws {
            var error: UnsafeMutablePointer<CChar>?
            let status = file.path.withCString { path in password.withCString { pass in
                certificate.withUnsafeBytes { key in profile.withUnsafeBytes { prov in
                    sign(path, key.bindMemory(to: UInt8.self).baseAddress, certificate.count, pass,
                         prov.bindMemory(to: UInt8.self).baseAddress, profile.count, &error)
                }}
            }}
            let detail = error.map { String(cString: $0) }
            if let error { free(error) }
            guard status == 0 else { throw failure(detail ?? "la firma local ha fallado.") }
        }
        func load(_ fixture: UInt32) throws -> (SignedCodeModule, [Int]) {
            var bytes = [UInt8](repeating: 0, count: 65536), offsets = [Int](repeating: -1, count: 4), written = 0
            let status = bytes.withUnsafeMutableBufferPointer { buffer in
                offsets.withUnsafeMutableBufferPointer { entries in
                    prepare(fixture, buffer.baseAddress, buffer.count, &written, entries.baseAddress, entries.count)
                }
            }
            guard status == 0, written == bytes.count,
                  offsets.allSatisfy({ $0 > 0 && $0 < written && $0 % 4 == 0 }),
                  offsets[0] < 32768, offsets[1] < 32768, offsets[0] != offsets[1],
                  offsets[2] >= 32768, offsets[3] >= 32768,
                  (fixture == 0 ? offsets[2] != offsets[3] : offsets[2] == offsets[3]) else {
                throw failure("generación o entradas rechazadas (función \(fixture), código \(status)).")
            }
            let words = stride(from: 0, to: written, by: 4).map { offset in
                (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
            }
            let image = try SignedCodeImage.prepare(template: template, instructions: words, entries: Array(Set([0] + offsets)).sorted())
            let module = try SignedCodeModule.load(image: image, sign: signFile, validate: OfflineProbe.requireCleanProcess)
            return (module, offsets)
        }
        let (a, aOffsets) = try load(0)
        defer { a.requestClose() }
        let (b, bOffsets) = try load(1)
        defer { b.requestClose() }
        guard a.identifier != b.identifier else { throw failure("módulos repetidos.") }
        let seed = UInt32.random(in: 1...32767)
        var total = 0
        for exitIndex in 0..<2 {
            var completed = 0
            let status = try a.withEntry(at: 0) { enter in
                try a.withEntry(at: aOffsets[exitIndex]) { leave in
                    try a.withEntry(at: aOffsets[2]) { caller in
                        try a.withEntry(at: aOffsets[3]) { continuation in
                            try b.withEntry(at: bOffsets[2]) { callee in
                                check(enter, leave, caller, continuation, callee, seed &+ UInt32(exitIndex), &completed)
                            }
                        }
                    }
                }
            }
            guard status == 0, completed == 96 else { throw failure("salida \(exitIndex + 1): código \(status), casos \(completed)/96.") }
            total += completed
        }
        a.requestClose(); b.requestClose()
        guard a.phase == .closed, b.phase == .closed,
              !FileManager.default.fileExists(atPath: a.fileURL.path),
              !FileManager.default.fileExists(atPath: b.fileURL.path), total == 192 else { throw failure("cierre o total incorrectos.") }
        try OfflineProbe.requireCleanProcess()
        return "Despacho PowerPC correcto: 2 funciones distintas en 2 módulos firmados, llamada A → B → continuación de A, retirada y reposición privada de B y reanudación; 192 comprobaciones con ambas salidas, sin JIT ni depurador. Prueba controlada; la integración con juegos, el intérprete y la renovación sigue pendiente."
    }
}
