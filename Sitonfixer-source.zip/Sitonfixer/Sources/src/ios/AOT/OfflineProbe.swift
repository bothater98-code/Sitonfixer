// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Darwin

enum OfflineProbe {
    struct Failure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }
    private typealias Sign = @convention(c) (UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int,
        UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafeMutablePointer<UnsafeMutablePointer<CChar>?>?) -> Int32
    private typealias Free = @convention(c) (UnsafeMutablePointer<CChar>?) -> Void
    private typealias Block = @convention(c) (UnsafeMutablePointer<UInt32>?) -> Void
    private typealias CorePrepare = @convention(c) (UnsafeMutablePointer<UInt8>?, Int, UnsafeMutablePointer<Int>?) -> Int32
    private typealias CoreCheck = @convention(c) (UnsafeMutableRawPointer?, UInt32, UnsafeMutablePointer<Int>?) -> Int32

    /// Fail closed if process state cannot be read, or if debugger/JIT was enabled.
    static func requireCleanProcess() throws {
        var process = kinfo_proc()
        var processSize = MemoryLayout<kinfo_proc>.size
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        guard sysctl(&mib, u_int(mib.count), &process, &processSize, nil, 0) == 0,
              (process.kp_proc.p_flag & P_TRACED) == 0 else {
            throw Failure(message: "Cierra Sitonfixer y vuelve a abrirla directamente, sin activar JIT ni usar un depurador.")
        }
        typealias CSOps = @convention(c) (pid_t, UInt32, UnsafeMutableRawPointer?, size_t) -> Int32
        guard let symbol = dlsym(UnsafeMutableRawPointer(bitPattern: -2), "csops") else {
            throw Failure(message: "No se puede verificar el estado de JIT; la prueba se cancela.")
        }
        let csops = unsafeBitCast(symbol, to: CSOps.self)
        var flags: UInt32 = 0
        guard csops(getpid(), 0, &flags, MemoryLayout<UInt32>.size) == 0,
              (flags & 0x10000000) == 0 else {
            throw Failure(message: "Este proceso tiene JIT activo o un estado desconocido. Reinicia solo la app antes de probar.")
        }
    }

    /// No URLSession, pairing, network client, debugger attach, mmap(PROT_EXEC) or mprotect.
    /// Only runs an internal scalar/backend fixture; never reads a game.
    static func run(certificate: Data, password: String, usingCore: Bool = false, usingFrontend: Bool = false, usingModule: Bool = false, usingManagedModules: Bool = false, usingInterface: Bool = false, usingDispatch: Bool = false) throws -> String {
        try requireCleanProcess()
        if usingDispatch { return try DispatchModuleProbe.run(certificate: certificate, password: password) }
        if usingInterface {
            do { return try ManagedModuleProbe.run(certificate: certificate, password: password, usingInterface: true) }
            catch { throw Failure(message: "SF-ENTRY: " + error.localizedDescription) }
        }
        if usingManagedModules { return try ManagedModuleProbe.run(certificate: certificate, password: password) }
        let realFrontend = usingFrontend || usingModule
        let diagnostic = usingModule ? "SF-MODULE" : (realFrontend ? "SF-FRONT" : "SF-CORE")
        guard !certificate.isEmpty, certificate.count <= 1_048_576, !password.contains("\0") else {
            throw Failure(message: "El certificado local no es válido.")
        }
        guard let profileURL = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let templateURL = Bundle.main.url(forResource: "scalar-probe", withExtension: "bin")
                ?? Bundle.main.url(forResource: "scalar-probe", withExtension: "bin", subdirectory: "AOT") else {
            throw Failure(message: "Falta el perfil de esta instalación o la plantilla de prueba.")
        }
        let profile = try Data(contentsOf: profileURL)
        guard profile.count <= 1_048_576 else { throw Failure(message: "El perfil de instalación supera el tamaño permitido.") }
        let framework = (Bundle.main.privateFrameworksPath ?? "") + "/MuffinJITPairing.framework/MuffinJITPairing"
        guard let signerLibrary = dlopen(framework, RTLD_NOW | RTLD_LOCAL) else {
            throw Failure(message: "No se puede cargar el firmador local.")
        }
        defer { dlclose(signerLibrary) }
        guard let signSymbol = dlsym(signerLibrary, "sitonfixer_sign_probe"),
              let freeSymbol = dlsym(signerLibrary, "muffin_jit_string_free") else {
            throw Failure(message: "Esta compilación no incluye el firmador de la prueba.")
        }
        let sign = unsafeBitCast(signSymbol, to: Sign.self), free = unsafeBitCast(freeSymbol, to: Free.self)
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SitonfixerProbe-" + UUID().uuidString, isDirectory: true)
        try FileManager.default.createDirectory(at: folder, withIntermediateDirectories: false)
        defer { try? FileManager.default.removeItem(at: folder) }
        let file = folder.appendingPathComponent("scalar-probe.dylib")
        let salt = UInt32.random(in: 1...32767)
        var coreLibrary: UnsafeMutableRawPointer?
        defer { if let coreLibrary { dlclose(coreLibrary) } }
        var coreCheck: CoreCheck?
        let native: [UInt32]
        if usingCore || realFrontend {
            let corePath = (Bundle.main.privateFrameworksPath ?? "") + "/Cemu.framework/Cemu"
            guard let library = dlopen(corePath, RTLD_NOW | RTLD_LOCAL) else {
                throw Failure(message: "No se puede cargar el motor Cemu de esta instalación.")
            }
            coreLibrary = library
            guard let prepareSymbol = dlsym(library, realFrontend ? "sitonfixer_frontend_probe_prepare" : "sitonfixer_backend_probe_prepare"),
                  let checkSymbol = dlsym(library, realFrontend ? "sitonfixer_frontend_probe_check" : "sitonfixer_backend_probe_check") else {
                throw Failure(message: "\(diagnostic): esta versión del motor no incluye la prueba seleccionada.")
            }
            let prepare = unsafeBitCast(prepareSymbol, to: CorePrepare.self)
            coreCheck = unsafeBitCast(checkSymbol, to: CoreCheck.self)
            var bytes = [UInt8](repeating: 0, count: 1028)
            var written = 0
            let result = bytes.withUnsafeMutableBufferPointer { prepare($0.baseAddress, $0.count, &written) }
            guard result == 0, written > 0, written <= bytes.count, written % 4 == 0 else {
                throw Failure(message: "\(diagnostic): generación rechazada (\(result)).")
            }
            native = stride(from: 0, to: written, by: 4).map { offset in
                (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
            }
        } else {
        // addi r3,r0,salt; addis r4,r0,-1; ori r5,r4,0x1234; add r6,r3,r5; blr
        let program: [UInt32] = [0x38600000 | salt, 0x3c80ffff, 0x60851234, 0x7cc32a14, 0x4e800020]
            native = try ScalarTranslation.translate(program)
        }
        let moduleWords: [UInt32]
        if usingModule { moduleWords = try SignedProbeModule.compose(frontend: native) }
        else { moduleWords = native }
        let image = try ScalarTranslation.replaceText(in: Data(contentsOf: templateURL), instructions: moduleWords)
        try image.write(to: file, options: .withoutOverwriting)
        var errorPointer: UnsafeMutablePointer<CChar>?
        let status = file.path.withCString { path in password.withCString { pass in
            certificate.withUnsafeBytes { key in profile.withUnsafeBytes { prov in
                sign(path, key.bindMemory(to: UInt8.self).baseAddress, certificate.count, pass,
                    prov.bindMemory(to: UInt8.self).baseAddress, profile.count, &errorPointer)
            }}
        }}
        let signingError = errorPointer.map { String(cString: $0) }
        if let errorPointer { free(errorPointer) }
        guard status == 0 else { throw Failure(message: signingError ?? "La firma local ha fallado.") }
        try requireCleanProcess()
        guard let handle = dlopen(file.path, RTLD_NOW | RTLD_LOCAL) else {
            // Capture dyld's error immediately, before another dynamic-loader operation.
            let detail = dlerror().map { String(cString: $0) } ?? "Sin detalle del cargador."
            let redacted = detail.replacingOccurrences(of: folder.path, with: "<prueba>")
                .replacingOccurrences(of: "/(?:private/)?var/(?:mobile/Containers|containers)/[^\\s'\"),]+", with: "<contenedor>", options: .regularExpression)
                .replacingOccurrences(of: "[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", with: "<id>", options: .regularExpression)
                .replacingOccurrences(of: "\\b[A-Z0-9]{10}\\b", with: "<equipo>", options: .regularExpression)
            throw Failure(message: "SF-LOAD: iOS ha rechazado cargar el bloque firmado.\n" + String(redacted.prefix(1024)))
        }
        defer { dlclose(handle) }
        guard let entry = dlsym(handle, "sitonfixer_aot_probe") else { throw Failure(message: "Falta la función de prueba.") }
        if let coreCheck {
            let offsets = usingModule ? SignedProbeModule.entryOffsets : [0]
            var total = 0
            for (index, offset) in offsets.enumerated() {
                var completed = 0
                let status = coreCheck(entry.advanced(by: offset), salt &+ UInt32(index), &completed)
                try requireCleanProcess()
                guard status == 0, completed == 32 else {
                    throw Failure(message: "\(diagnostic): entrada \(index + 1), comprobación fallida (\(status), casos \(completed)/32).")
                }
                total += completed
            }
            if usingModule {
                return "Módulo firmado de 64 KiB correcto: 3 entradas, llamadas entre páginas y \(total) casos del frontend PowerPC real, sin JIT ni depurador. Reutiliza el programa sintético de la revisión 9; todavía no integra funciones de juegos ni renovación autónoma."
            }
            if realFrontend {
                return "Frontend PowerPC de Cemu correcto: 32 casos de suma, RAM big-endian, comparación, ramas, ciclos y retorno, con optimización y asignación de registros reales, firma local y ejecución sin JIT ni depurador. No demuestra todavía juegos Wii U ni renovación autónoma."
            }
            return "Backend Cemu correcto: 32 casos con enteros, RAM big-endian, división con saltos, coma flotante y llamada al motor, mediante firma local sin activar JIT ni depurador. No demuestra todavía juegos Wii U ni renovación autónoma."
        }
        let block = unsafeBitCast(entry, to: Block.self)
        var registers = (0..<32).map { UInt32($0) &* 0x1020304 }
        var expected = registers
        expected[3] = salt; expected[4] = 0xffff0000; expected[5] = 0xffff1234
        expected[6] = salt &+ expected[5]
        registers.withUnsafeMutableBufferPointer { block($0.baseAddress) }
        try requireCleanProcess()
        guard registers == expected else { throw Failure(message: "El bloque ARM64 no produjo los registros esperados.") }
        return "Prueba escalar correcta: PowerPC → ARM64, firma local y ejecución sin JIT ni depurador. Esto no demuestra todavía emulación de Wii U, rendimiento de juegos ni renovación autónoma."
    }
}
