// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
// Uses SideStore's documented-in-source certificate callback, entirely app-to-app.
// No HTTP endpoint, disk storage, Keychain write, analytics or URL logging.
import Foundation
import Combine
import UIKit

@MainActor
final class OfflineCertificateTransfer: ObservableObject {
    static let shared = OfflineCertificateTransfer()
    @Published private(set) var payload: CertificateCallback.Payload?
    @Published private(set) var message: String?
    private var nonce: String?
    private var deadline: Date?
    private var expiryTask: Task<Void, Never>?

    func request() {
        clear()
        let token = UUID().uuidString.lowercased()
        nonce = token; deadline = Date().addingTimeInterval(120)
        expiryTask = Task { @MainActor [weak self] in
            do { try await Task.sleep(nanoseconds: 120_000_000_000) } catch { return }
            guard let self else { return }
            if self.nonce == token {
                self.clear(); self.message = "La solicitud de certificado ha caducado. Puedes volver a solicitarla."
            } else { self.payload = nil }
        }
        let callback = "sitonfixer-aot://certificate?nonce=\(token)&cert=$(BASE64_CERT)&password=$(PASSWORD)"
        var components = URLComponents()
        components.scheme = "sidestore"; components.host = "certificate"
        components.queryItems = [URLQueryItem(name: "callback_template", value: callback)]
        guard let url = components.url else { clear(); return }
        message = "Confirma la entrega del certificado a Sitonfixer en SideStore. Después vuelve a esta pantalla."
        UIApplication.shared.open(url, options: [:]) { opened in
            Task { @MainActor in
                if !opened { self.clear(); self.message = "No se pudo abrir SideStore para solicitar el certificado." }
            }
        }
    }

    /// Return true for our scheme even on rejection: certificate URLs must never enter file-import code.
    func handle(_ url: URL) -> Bool {
        guard url.scheme?.lowercased() == "sitonfixer-aot" else { return false }
        guard let delivery = CertificateCallback.parse(url, nonce: nonce, deadline: deadline) else {
            clear(); message = "Se rechazó una entrega de certificado no solicitada, caducada o inválida."
            return true
        }
        nonce = nil; self.deadline = nil
        message = "Certificado recibido solo en memoria; ya puedes ejecutar la prueba sin red."
        payload = delivery
        return true
    }

    func consume() { payload = nil }
    func clear() { expiryTask?.cancel(); expiryTask = nil; nonce = nil; deadline = nil; payload = nil; message = nil }
}
