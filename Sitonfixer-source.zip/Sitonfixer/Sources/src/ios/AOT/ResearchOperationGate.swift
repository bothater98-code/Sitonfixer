// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// All old synthetic probes share this gate with the process-wide engine probe.
/// Initialization owns it until process exit: cancellation cannot stop Cemu safely.
enum ResearchOperationGate {
    private static let lock = NSLock()
    private static var occupied = false
    static func acquire() -> Bool {
        lock.lock(); defer { lock.unlock() }
        guard !occupied else { return false }
        occupied = true; return true
    }
    static func releaseSyntheticProbe() {
        lock.lock(); defer { lock.unlock() }
        occupied = false
    }
}
