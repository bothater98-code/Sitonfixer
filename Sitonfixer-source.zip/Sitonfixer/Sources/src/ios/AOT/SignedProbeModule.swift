// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// Controlled 64 KiB carrier proof, not a game module manager or a persistent cache.
/// The real frontend's complete ABI wrapper/body is copied unchanged at 32 KiB.
/// Two small native functions call it across pages, including a backward call.
enum SignedProbeModule {
    static let textBytes = 65_536
    static let bodyOffset = 32_768
    static let nestedOffset = 49_152
    static let markerOffset = 16_384
    static let entryOffsets = [0, bodyOffset, nestedOffset]

    static func compose(frontend: [UInt32], marker: UInt16? = nil) throws -> [UInt32] {
        guard !frontend.isEmpty, frontend.count <= 1028 / 4 else {
            throw ScalarTranslation.Failure.malformed
        }
        var words = [UInt32](repeating: 0xd503201f, count: textBytes / 4)
        func bridge(at source: Int, to destination: Int) throws -> [UInt32] {
            // stp x29,x30,[sp,#-16]!; mov x29,sp; bl target;
            // ldp x29,x30,[sp],#16; ret. Incoming x0/x1 are forwarded unchanged.
            let delta = destination - (source + 8)
            guard delta % 4 == 0, delta >= -(1 << 27), delta < (1 << 27) else {
                throw ScalarTranslation.Failure.malformed
            }
            let immediate = UInt32(truncatingIfNeeded: delta / 4) & 0x03ffffff
            return [0xa9bf7bfd, 0x910003fd, 0x94000000 | immediate, 0xa8c17bfd, 0xd65f03c0]
        }
        let direct = try bridge(at: 0, to: bodyOffset)
        let nested = try bridge(at: nestedOffset, to: 0)
        words.replaceSubrange(0..<direct.count, with: direct)
        words.replaceSubrange(bodyOffset / 4..<bodyOffset / 4 + frontend.count, with: frontend)
        words.replaceSubrange(nestedOffset / 4..<nestedOffset / 4 + nested.count, with: nested)
        if let marker {
            words[markerOffset / 4] = 0x52800000 | UInt32(marker) << 5 // movz w0, marker
            words[markerOffset / 4 + 1] = 0xd65f03c0
        }
        return words
    }
}
