// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// Fixed-capacity, trusted carrier. Identity and text are changed BEFORE signing.
/// This is not a persistent cache format or an arbitrary Mach-O program loader.
struct SignedCodeImage {
    static let placeholderName = "@rpath/SitonfixerModule-00000000-0000-0000-0000-000000000000.dylib"
    let bytes: Data
    let identifier: UUID
    let allowedEntries: Set<Int>
    let textBytes: Int
    let platform: UInt32
    let uuidRange: Range<Int>
    let nameRange: Range<Int>

    private init(bytes: Data, identifier: UUID, entries: Set<Int>, textBytes: Int,
                 platform: UInt32, uuidRange: Range<Int>, nameRange: Range<Int>) {
        self.bytes = bytes; self.identifier = identifier; allowedEntries = entries
        self.textBytes = textBytes; self.platform = platform
        self.uuidRange = uuidRange; self.nameRange = nameRange
    }

    static func prepare(template: Data, instructions: [UInt32], entries: [Int], identifier: UUID = UUID()) throws -> SignedCodeImage {
        guard instructions.count == 65_536 / 4, !entries.isEmpty, entries.count <= 1024,
              Set(entries).count == entries.count, entries.contains(0),
              entries.allSatisfy({ $0 >= 0 && $0 % 4 == 0 && $0 / 4 < instructions.count }) else {
            throw ScalarTranslation.Failure.malformed
        }
        var image = try ScalarTranslation.replaceText(in: template, instructions: instructions)
        let bytes = [UInt8](template)
        func u32(_ offset: Int) throws -> UInt32 {
            guard offset >= 0, offset <= bytes.count - 4 else { throw ScalarTranslation.Failure.malformed }
            return (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
        }
        let count = Int(try u32(16)), size = Int(try u32(20))
        var cursor = 32
        var uuidRange: Range<Int>?, nameRange: Range<Int>?, platform: UInt32?, textSize: UInt32?
        for _ in 0..<count {
            let command = try u32(cursor), length = Int(try u32(cursor + 4))
            guard length >= 8, length <= 32 + size - cursor else { throw ScalarTranslation.Failure.malformed }
            if command == 0x1b { // LC_UUID
                guard length == 24, uuidRange == nil else { throw ScalarTranslation.Failure.malformed }
                uuidRange = cursor + 8..<cursor + 24
            }
            if command == 0x0d { // LC_ID_DYLIB, name offset is relative to this command
                guard length >= 24, nameRange == nil else { throw ScalarTranslation.Failure.malformed }
                let offset = Int(try u32(cursor + 8))
                guard offset >= 24, offset < length else { throw ScalarTranslation.Failure.malformed }
                let range = cursor + offset..<cursor + length
                guard let end = bytes[range].firstIndex(of: 0),
                      String(bytes: bytes[range.lowerBound..<end], encoding: .utf8) == placeholderName else {
                    throw ScalarTranslation.Failure.malformed
                }
                nameRange = range
            }
            if command == 0x32 { // LC_BUILD_VERSION
                guard length >= 24, platform == nil else { throw ScalarTranslation.Failure.malformed }
                platform = try u32(cursor + 8)
            }
            if command == 0x19 {
                guard length >= 72 else { throw ScalarTranslation.Failure.malformed }
                let sections = Int(try u32(cursor + 64))
                guard sections <= (length - 72) / 80 else { throw ScalarTranslation.Failure.malformed }
                for index in 0..<sections {
                    let section = cursor + 72 + index * 80
                    let name = String(bytes: bytes[section..<section + 16].prefix { $0 != 0 }, encoding: .utf8)
                    if name == "__text" {
                        guard textSize == nil, try u32(section + 44) == 0 else { throw ScalarTranslation.Failure.malformed }
                        textSize = try u32(section + 40)
                    }
                }
            }
            cursor += length
        }
        guard cursor == 32 + size, let uuidRange, let nameRange, let platform,
              textSize == 65_536, platform == 1 || platform == 2 else { throw ScalarTranslation.Failure.malformed }
        let name = Array("@rpath/SitonfixerModule-\(identifier.uuidString).dylib".utf8) + [0]
        guard name.count <= nameRange.count else { throw ScalarTranslation.Failure.malformed }
        var uuid = identifier.uuid
        let uuidBytes = withUnsafeBytes(of: &uuid) { Data($0) }
        guard uuidBytes.count == uuidRange.count else { throw ScalarTranslation.Failure.malformed }
        image.replaceSubrange(uuidRange, with: uuidBytes)
        image.replaceSubrange(nameRange, with: name + [UInt8](repeating: 0, count: nameRange.count - name.count))
        return SignedCodeImage(bytes: image, identifier: identifier, entries: Set(entries),
            textBytes: instructions.count * 4, platform: platform, uuidRange: uuidRange, nameRange: nameRange)
    }
}
