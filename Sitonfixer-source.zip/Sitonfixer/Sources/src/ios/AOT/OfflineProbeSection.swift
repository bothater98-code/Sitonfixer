// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import SwiftUI
import UniformTypeIdentifiers

struct OfflineProbeSection: View {
    @State private var choosingCertificate = false
    @State private var certificate: Data?
    @State private var password = ""
    @State private var running = false
    @State private var result: String?

    var body: some View {
        Section("Prueba experimental sin JIT") {
            Text("Cierra y abre Sitonfixer directamente. Desconecta la VPN y activa modo avión para comprobar esta vía sin red. La prueba no activa JIT ni abre un juego.")
                .font(.footnote)
            Button(certificate == nil ? "Elegir certificado propio (.p12)" : "Certificado cargado solo en memoria") {
                choosingCertificate = true
            }.disabled(running)
            SecureField("Contraseña del certificado", text: $password).disabled(running)
            Text("Utiliza el certificado que firmó esta instalación. Se usa solo aquí; no se envía ni se guarda. No introduzcas la contraseña de tu cuenta Apple.")
                .font(.footnote)
            Button(running ? "Probando…" : "Traducir, firmar y ejecutar prueba") { start() }
                .disabled(certificate == nil || running)
            if let result { Text(result).font(.footnote).textSelection(.enabled) }
            Text("Solo admite unas pocas instrucciones aritméticas. No sustituye todavía el motor Wii U ni la renovación de firma.")
                .font(.footnote)
        }
        .fileImporter(isPresented: $choosingCertificate, allowedContentTypes: [.data]) { selection in
            do {
                let url = try selection.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard url.pathExtension.lowercased() == "p12", size > 0, size <= 1_048_576 else {
                    throw OfflineProbe.Failure(message: "Elige un archivo .p12 de hasta 1 MiB.")
                }
                let data = try Data(contentsOf: url)
                guard data.count <= 1_048_576 else { throw OfflineProbe.Failure(message: "El certificado supera 1 MiB.") }
                certificate = data; result = nil
            } catch { certificate = nil; result = error.localizedDescription }
        }
        .onDisappear { certificate = nil; password = "" }
    }

    private func start() {
        guard let key = certificate, !running else { return }
        let pass = password
        running = true; result = nil; certificate = nil; password = ""
        Task { @MainActor in
            let message = await Task.detached(priority: .userInitiated) {
                do { return try OfflineProbe.run(certificate: key, password: pass) }
                catch { return error.localizedDescription }
            }.value
            result = message; running = false
        }
    }
}
