// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import SwiftUI
import UniformTypeIdentifiers

struct OfflineProbeSection: View {
    @State private var choosingCertificate = false
    @State private var certificate: Data?
    @State private var password = ""
    @State private var running = false
    @State private var result: String?
    @ObservedObject private var transfer = OfflineCertificateTransfer.shared

    var body: some View {
        Section("Prueba experimental sin JIT") {
            Text("Cierra y abre Sitonfixer directamente. Desconecta la VPN y activa modo avión para comprobar esta vía sin red. La prueba no activa JIT ni abre un juego.")
                .font(.footnote)
            Button("Solicitar certificado a SideStore") { transfer.request() }.disabled(running)
            if let message = transfer.message { Text(message).font(.footnote) }
            Button(certificate == nil ? "Elegir certificado propio (.p12)" : "Certificado cargado solo en memoria") {
                choosingCertificate = true
            }.disabled(running)
            SecureField("Contraseña del certificado", text: $password).disabled(running)
            Text("Utiliza el certificado que firmó esta instalación. Se usa solo aquí; no se envía ni se guarda. No introduzcas la contraseña de tu cuenta Apple.")
                .font(.footnote)
            Text("El intercambio lo confirma SideStore. No compartas los registros de esa operación: el protocolo de SideStore puede incluir el certificado en sus registros locales.")
                .font(.footnote)
            Button(running ? "Probando…" : "Traducir, firmar y ejecutar prueba") { start() }
                .disabled(certificate == nil || running)
            Button("Probar backend real de Cemu") { start(usingCore: true) }
                .disabled(certificate == nil || running)
            Button("Probar frontend PowerPC de Cemu") { start(usingFrontend: true) }
                .disabled(certificate == nil || running)
            Button("Probar módulo firmado de 64 KiB") { start(usingModule: true) }
                .disabled(certificate == nil || running)
            Button("Probar carga y cierre de módulos") { start(usingManagedModules: true) }
                .disabled(certificate == nil || running)
            Button("Probar entrada y salida de Cemu") { start(usingInterface: true) }
                .disabled(certificate == nil || running)
            Button("Probar despacho entre funciones PowerPC") { start(usingDispatch: true) }
                .disabled(certificate == nil || running)
            if let result { Text(result).font(.footnote).textSelection(.enabled) }
            Text("La prueba frontend traduce un programa PowerPC sintético con comparación y ramas. Estas pruebas todavía no arrancan juegos ni renuevan la firma.")
                .font(.footnote)
        }
        .fileImporter(isPresented: $choosingCertificate, allowedContentTypes: [.data]) { selection in
            do {
                let url = try selection.get()
                let scoped = url.startAccessingSecurityScopedResource()
                defer { if scoped { url.stopAccessingSecurityScopedResource() } }
                let size = try url.resourceValues(forKeys: [.fileSizeKey]).fileSize ?? 0
                guard url.pathExtension.lowercased() == "p12", size > 0, size <= 1_048_576 else {
                    throw OfflineProbe.Failure(message: "Elige un archivo .p12 de hasta 1 MiB.")
                }
                let data = try Data(contentsOf: url)
                guard data.count <= 1_048_576 else { throw OfflineProbe.Failure(message: "El certificado supera 1 MiB.") }
                certificate = data; result = nil
            } catch { certificate = nil; result = error.localizedDescription }
        }
        .onReceive(transfer.$payload) { delivery in
            guard let delivery else { return }
            certificate = delivery.certificate; password = delivery.password; result = nil
            transfer.consume()
        }
        .onDisappear { certificate = nil; password = ""; transfer.consume() }
    }

    private func start(usingCore: Bool = false, usingFrontend: Bool = false, usingModule: Bool = false, usingManagedModules: Bool = false, usingInterface: Bool = false, usingDispatch: Bool = false) {
        guard let key = certificate, !running else { return }
        let pass = password
        running = true; result = nil; certificate = nil; password = ""
        Task { @MainActor in
            let message = await Task.detached(priority: .userInitiated) {
                do { return try OfflineProbe.run(certificate: key, password: pass, usingCore: usingCore, usingFrontend: usingFrontend, usingModule: usingModule, usingManagedModules: usingManagedModules, usingInterface: usingInterface, usingDispatch: usingDispatch) }
                catch { return error.localizedDescription }
            }.value
            result = message; running = false
        }
    }
}
