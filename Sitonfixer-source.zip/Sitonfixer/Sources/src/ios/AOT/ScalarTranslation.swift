// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// Deliberately small proof, not a Wii U CPU replacement. Host state is 32 UInt32 GPRs.
/// Only addi, addis, ori, add (no OE/Rc) and the final blr are accepted.
enum ScalarTranslation {
    enum Failure: LocalizedError {
        case unsupported(UInt32), malformed
        var errorDescription: String? {
            switch self {
            case .unsupported(let word): return String(format: "La prueba no admite la instrucción %08x.", word)
            case .malformed: return "El bloque de prueba no tiene un retorno final válido."
            }
        }
    }
    static func translate(_ words: [UInt32]) throws -> [UInt32] {
        guard !words.isEmpty, words.count <= 32, words.last == 0x4e800020 else { throw Failure.malformed }
        var output: [UInt32] = []
        func load(_ guest: UInt32, _ host: UInt32) { output.append(0xb9400000 | (guest << 10) | host) }
        func store(_ guest: UInt32) { output.append(0xb900000b | (guest << 10)) }
        func immediate(_ value: UInt32) {
            output.append(0x5280000a | ((value & 0xffff) << 5)) // movz w10, low
            output.append(0x72a0000a | ((value >> 16) << 5))    // movk w10, high, lsl 16
        }
        for word in words.dropLast() {
            let primary = word >> 26, d = (word >> 21) & 31, a = (word >> 16) & 31
            switch primary {
            case 14, 15: // rA == 0 means literal zero, unlike ori/add.
                if a == 0 { output.append(0x52800009) } else { load(a, 9) }
                let signed = UInt32(bitPattern: Int32(Int16(bitPattern: UInt16(word & 0xffff))))
                immediate(primary == 15 ? signed << 16 : signed)
                output.append(0x0b0a012b) // add w11,w9,w10
                store(d)
            case 24: // PPC ori rA,rS,UI: destination is rA, source is rS.
                load(d, 9); immediate(word & 0xffff)
                output.append(0x2a0a012b) // orr w11,w9,w10
                store(a)
            case 31 where ((word >> 1) & 0x3ff) == 266 && (word & 1) == 0:
                load(a, 9); load((word >> 11) & 31, 10)
                output.append(0x0b0a012b); store(d)
            default: throw Failure.unsupported(word)
            }
        }
        output.append(0xd65f03c0) // ret, follows the host ABI; guest LR is not modified.
        return output
    }

    /// Locate the actual Mach-O __text section. Never search or patch a byte pattern.
    static func replaceText(in original: Data, instructions: [UInt32]) throws -> Data {
        let bytes = [UInt8](original)
        func u32(_ p: Int) throws -> UInt32 {
            guard p >= 0, p <= bytes.count - 4 else { throw Failure.malformed }
            return (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[p + $1]) << ($1 * 8) }
        }
        func u64(_ p: Int) throws -> UInt64 { UInt64(try u32(p)) | UInt64(try u32(p + 4)) << 32 }
        func name(_ p: Int) throws -> String {
            guard p >= 0, p <= bytes.count - 16 else { throw Failure.malformed }
            return String(bytes: bytes[p..<p+16].prefix { $0 != 0 }, encoding: .utf8) ?? ""
        }
        guard try u32(0) == 0xfeedfacf, try u32(4) == 0x0100000c,
              try u32(12) == 6 else { throw Failure.malformed }
        let count = Int(try u32(16)), commandsSize = Int(try u32(20))
        guard count <= 128, commandsSize <= bytes.count - 32 else { throw Failure.malformed }
        var cursor = 32
        var textRange: Range<Int>?
        for _ in 0..<count {
            let command = try u32(cursor), size = Int(try u32(cursor + 4))
            guard size >= 8, size <= 32 + commandsSize - cursor else { throw Failure.malformed }
            if command == 0x19 {
                guard size >= 72 else { throw Failure.malformed }
                let sections = Int(try u32(cursor + 64))
                guard sections <= (size - 72) / 80 else { throw Failure.malformed }
                for index in 0..<sections {
                    let p = cursor + 72 + index * 80
                    if try name(p) == "__text", try name(p + 16) == "__TEXT" {
                        let length = try u64(p + 40), offset = Int(try u32(p + 48))
                        guard textRange == nil, length > 0, length <= 65536, length % 4 == 0,
                              offset >= 32 + commandsSize, length <= UInt64(bytes.count - min(offset, bytes.count)),
                              offset <= bytes.count, instructions.count <= Int(length) / 4 else { throw Failure.malformed }
                        textRange = offset..<offset + Int(length)
                    }
                }
            }
            cursor += size
        }
        guard cursor == 32 + commandsSize, let range = textRange else { throw Failure.malformed }
        var result = original
        let filled = instructions + Array(repeating: UInt32(0xd503201f), count: range.count / 4 - instructions.count)
        var patch = Data()
        for var word in filled.map({ $0.littleEndian }) { withUnsafeBytes(of: &word) { patch.append(contentsOf: $0) } }
        result.replaceSubrange(range, with: patch)
        return result
    }
}
