// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Darwin

/// Exercises the reusable loader with two images and the unchanged real PPC9 fixture.
/// It does not publish game functions or own the game's native worker threads.
enum ManagedModuleProbe {
    private typealias Prepare = @convention(c) (UnsafeMutablePointer<UInt8>?, Int, UnsafeMutablePointer<Int>?) -> Int32
    private typealias Check = @convention(c) (UnsafeMutableRawPointer?, UInt32, UnsafeMutablePointer<Int>?) -> Int32
    private typealias Marker = @convention(c) () -> UInt32
    private typealias Sign = @convention(c) (UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafeMutablePointer<UnsafeMutablePointer<CChar>?>?) -> Int32
    private typealias Free = @convention(c) (UnsafeMutablePointer<CChar>?) -> Void
    private static func failure(_ message: String) -> OfflineProbe.Failure { .init(message: "SF-LIFE: " + message) }

    static func run(certificate: Data, password: String) throws -> String {
        try OfflineProbe.requireCleanProcess()
        guard !certificate.isEmpty, certificate.count <= 1_048_576, !password.contains("\0"),
              let profileURL = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let templateURL = Bundle.main.url(forResource: "scalar-probe", withExtension: "bin")
                ?? Bundle.main.url(forResource: "scalar-probe", withExtension: "bin", subdirectory: "AOT") else {
            throw failure("faltan el certificado, perfil o plantilla válidos.")
        }
        let profile = try Data(contentsOf: profileURL), template = try Data(contentsOf: templateURL)
        guard profile.count <= 1_048_576 else { throw failure("perfil demasiado grande.") }
        let root = Bundle.main.privateFrameworksPath ?? ""
        guard let signer = dlopen(root + "/MuffinJITPairing.framework/MuffinJITPairing", RTLD_NOW | RTLD_LOCAL) else {
            throw failure("no se puede abrir el firmador local.")
        }
        defer { dlclose(signer) }
        guard let core = dlopen(root + "/Cemu.framework/Cemu", RTLD_NOW | RTLD_LOCAL) else {
            throw failure("no se puede abrir Cemu.")
        }
        defer { dlclose(core) }
        guard let signAddress = dlsym(signer, "sitonfixer_sign_probe"),
              let freeAddress = dlsym(signer, "muffin_jit_string_free"),
              let prepareAddress = dlsym(core, "sitonfixer_frontend_probe_prepare"),
              let checkAddress = dlsym(core, "sitonfixer_frontend_probe_check") else { throw failure("faltan funciones requeridas.") }
        let sign = unsafeBitCast(signAddress, to: Sign.self), free = unsafeBitCast(freeAddress, to: Free.self)
        let prepare = unsafeBitCast(prepareAddress, to: Prepare.self), check = unsafeBitCast(checkAddress, to: Check.self)
        var bytes = [UInt8](repeating: 0, count: 1028), written = 0
        let generation = bytes.withUnsafeMutableBufferPointer { prepare($0.baseAddress, $0.count, &written) }
        guard generation == 0, written > 0, written <= bytes.count, written % 4 == 0 else {
            throw failure("generación rechazada (\(generation)).")
        }
        let frontend = stride(from: 0, to: written, by: 4).map { offset in
            (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
        }
        func signFile(_ file: URL) throws {
            var error: UnsafeMutablePointer<CChar>?
            let result = file.path.withCString { path in password.withCString { pass in
                certificate.withUnsafeBytes { key in profile.withUnsafeBytes { prov in
                    sign(path, key.bindMemory(to: UInt8.self).baseAddress, certificate.count, pass,
                         prov.bindMemory(to: UInt8.self).baseAddress, profile.count, &error)
                }}
            }}
            let detail = error.map { String(cString: $0) }
            if let error { free(error) }
            guard result == 0 else { throw failure(detail ?? "la firma local ha fallado.") }
        }
        func load(marker: UInt16) throws -> SignedCodeModule {
            let words = try SignedProbeModule.compose(frontend: frontend, marker: marker)
            let image = try SignedCodeImage.prepare(template: template, instructions: words,
                entries: SignedProbeModule.entryOffsets + [SignedProbeModule.markerOffset])
            return try SignedCodeModule.load(image: image, sign: signFile, validate: OfflineProbe.requireCleanProcess)
        }
        let a = try load(marker: 0x1357)
        defer { a.requestClose() }
        let b = try load(marker: 0x2468)
        defer { b.requestClose() }
        guard a.identifier != b.identifier else { throw failure("identidades repetidas.") }
        func marker(_ module: SignedCodeModule) throws -> UInt32 {
            try module.withEntry(at: SignedProbeModule.markerOffset) { unsafeBitCast($0, to: Marker.self)() }
        }
        guard try marker(a) == 0x1357, try marker(b) == 0x2468 else { throw failure("las imágenes no son distintas.") }
        var total = 0
        let salt = UInt32.random(in: 1...32767)
        for (moduleIndex, module) in [a, b].enumerated() {
            for (entryIndex, offset) in SignedProbeModule.entryOffsets.enumerated() {
                var completed = 0
                let status = try module.withEntry(at: offset) { check($0, salt &+ UInt32(moduleIndex * 3 + entryIndex), &completed) }
                guard status == 0, completed == 32 else { throw failure("módulo \(moduleIndex + 1), entrada \(entryIndex + 1): \(status), casos \(completed)/32.") }
                total += completed
            }
        }
        try a.withEntry(at: SignedProbeModule.markerOffset) { pointer in
            a.requestClose()
            guard a.phase == .closing else { throw failure("el cierre no conserva la llamada activa.") }
            var rejected = false
            do { _ = try a.withEntry(at: 0) { _ in 0 } }
            catch ModuleLifetime.Failure.closed { rejected = true }
            guard rejected, unsafeBitCast(pointer, to: Marker.self)() == 0x1357 else { throw failure("préstamo o rechazo de llamada incorrectos.") }
        }
        guard a.phase == .closed, !FileManager.default.fileExists(atPath: a.fileURL.path),
              try marker(b) == 0x2468 else { throw failure("el cierre afecta a otra biblioteca.") }
        b.requestClose()
        guard b.phase == .closed, !FileManager.default.fileExists(atPath: b.fileURL.path), total == 192 else { throw failure("limpieza o total incorrectos.") }
        try OfflineProbe.requireCleanProcess()
        return "Carga y cierre correctos: 2 módulos distintos, 192 casos del frontend real y cierre aplazado hasta terminar la llamada. Reutiliza el programa sintético; todavía no arranca juegos ni renueva la firma."
    }
}
