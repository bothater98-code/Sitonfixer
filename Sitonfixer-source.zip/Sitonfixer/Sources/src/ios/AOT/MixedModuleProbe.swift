// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Darwin

/// ResearchOperationGate and the process-wide initialization latch are acquired
/// by EngineInitializationProbe before this function runs. All entry borrows
/// cover the entire native -> interpreter -> native call, including both exits.
enum MixedModuleProbe {
    private typealias Begin = @convention(c) (UnsafePointer<CChar>?, UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt32>?) -> Int32
    private typealias Prepare = @convention(c) (UInt32, UnsafeMutablePointer<UInt8>?, Int, UnsafeMutablePointer<Int>?, UnsafeMutablePointer<Int>?, Int) -> Int32
    private typealias Check = @convention(c) (UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UnsafeMutableRawPointer?, UInt32, UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt32>?) -> Int32
    private typealias Sign = @convention(c) (UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafePointer<CChar>?, UnsafePointer<UInt8>?, Int, UnsafeMutablePointer<UnsafeMutablePointer<CChar>?>?) -> Int32
    private typealias Free = @convention(c) (UnsafeMutablePointer<CChar>?) -> Void
    private static func failure(_ text: String) -> OfflineProbe.Failure { .init(message: text) }

    static func run(certificate: Data, password: String) throws -> String {
        try OfflineProbe.requireCleanProcess()
        guard !certificate.isEmpty, certificate.count <= 1_048_576, !password.contains("\0"),
              let profileURL = Bundle.main.url(forResource: "embedded", withExtension: "mobileprovision"),
              let templateURL = Bundle.main.url(forResource: "scalar-probe", withExtension: "bin")
                ?? Bundle.main.url(forResource: "scalar-probe", withExtension: "bin", subdirectory: "AOT") else {
            throw failure("faltan certificado, perfil o plantilla válidos. Cierra la app antes de continuar.")
        }
        let profile = try Data(contentsOf: profileURL), template = try Data(contentsOf: templateURL)
        guard profile.count <= 1_048_576 else { throw failure("perfil demasiado grande.") }
        let root = Bundle.main.privateFrameworksPath ?? ""
        guard let signer = dlopen(root + "/MuffinJITPairing.framework/MuffinJITPairing", RTLD_NOW | RTLD_LOCAL) else {
            throw failure("no se puede abrir el firmador.")
        }
        defer { dlclose(signer) }
        guard let core = dlopen(root + "/Cemu.framework/Cemu", RTLD_NOW | RTLD_LOCAL) else { throw failure("no se puede abrir Cemu.") }
        defer { dlclose(core) }
        guard let beginAddress = dlsym(core, "sitonfixer_mixed_probe_begin"),
              let prepareAddress = dlsym(core, "sitonfixer_mixed_probe_prepare"),
              let checkAddress = dlsym(core, "sitonfixer_mixed_probe_check"),
              let signAddress = dlsym(signer, "sitonfixer_sign_probe"),
              let freeAddress = dlsym(signer, "muffin_jit_string_free") else { throw failure("faltan las funciones de prueba mixta.") }
        let begin = unsafeBitCast(beginAddress, to: Begin.self), prepare = unsafeBitCast(prepareAddress, to: Prepare.self)
        let check = unsafeBitCast(checkAddress, to: Check.self), sign = unsafeBitCast(signAddress, to: Sign.self)
        let free = unsafeBitCast(freeAddress, to: Free.self)
        let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
        let mlc = documents.appendingPathComponent("mlc", isDirectory: true)
        try FileManager.default.createDirectory(at: mlc, withIntermediateDirectories: true)
        var conditions: UInt32 = 0, guest: UInt32 = 0
        let initCode = mlc.path.withCString { begin($0, &conditions, &guest) }
        guard initCode == 0, conditions == 255, guest >= 0x0e000000,
              guest % 4096 == 0, UInt64(guest) + 4096 <= 0x10000000 else {
            throw failure("inicialización mixta rechazada (código \(initCode), máscara \(conditions)/255). Cierra la app.")
        }
        var bytes = [UInt8](repeating: 0, count: 65536), offsets = [Int](repeating: -1, count: 4), written = 0
        let code = bytes.withUnsafeMutableBufferPointer { buffer in
            offsets.withUnsafeMutableBufferPointer { entries in
                prepare(guest, buffer.baseAddress, buffer.count, &written, entries.baseAddress, entries.count)
            }
        }
        guard code == 0, written == bytes.count, Set(offsets).count == 4,
              offsets.allSatisfy({ $0 > 0 && $0 < written && $0 % 4 == 0 }),
              offsets[0] < 32768, offsets[1] < 32768, offsets[2] >= 32768, offsets[3] >= 32768 else {
            throw failure("preparación mixta rechazada (código \(code)). Cierra la app.")
        }
        let words = stride(from: 0, to: written, by: 4).map { offset in
            (0..<4).reduce(UInt32(0)) { $0 | UInt32(bytes[offset + $1]) << ($1 * 8) }
        }
        let image = try SignedCodeImage.prepare(template: template, instructions: words, entries: ([0] + offsets).sorted())
        let module = try SignedCodeModule.load(image: image, sign: { file in
            var error: UnsafeMutablePointer<CChar>?
            let result = file.path.withCString { path in password.withCString { pass in
                certificate.withUnsafeBytes { key in profile.withUnsafeBytes { prov in
                    sign(path, key.bindMemory(to: UInt8.self).baseAddress, certificate.count, pass,
                         prov.bindMemory(to: UInt8.self).baseAddress, profile.count, &error)
                }}
            }}
            let detail = error.map { String(cString: $0) }
            if let error { free(error) }
            guard result == 0 else { throw failure(detail ?? "la firma local ha fallado.") }
        }, validate: OfflineProbe.requireCleanProcess)
        defer { module.requestClose() }
        var completed: UInt32 = 0, interpreted: UInt32 = 0, pages: UInt32 = 0
        let result = try module.withEntry(at: 0) { enter in
            try module.withEntry(at: offsets[0]) { unvisited in
                try module.withEntry(at: offsets[1]) { visited in
                    try module.withEntry(at: offsets[2]) { caller in
                        try module.withEntry(at: offsets[3]) { continuation in
                            check(enter, unvisited, visited, caller, continuation, guest, &completed, &interpreted, &pages)
                        }
                    }
                }
            }
        }
        guard result == 0, completed == 64, interpreted == 256, pages == 2 else {
            throw failure("recorrido mixto no validado (código \(result), casos \(completed)/64, pasos interpretados \(interpreted)/256, páginas \(pages)/2). Cierra la app.")
        }
        module.requestClose()
        guard module.phase == .closed, !FileManager.default.fileExists(atPath: module.fileURL.path) else {
            throw failure("cierre del módulo incompleto. Cierra la app.")
        }
        try OfflineProbe.requireCleanProcess()
        return "Puente mixto de Cemu correcto: 64 casos y 256 pasos del intérprete real, A firmada → B interpretada → continuación de A firmada, CPU y RAM reales compartidas, ambas salidas y dos páginas de tabla privada, sin JIT ni depurador. No integra todavía juegos ni renovación. Cierra completamente la app antes de continuar."
    }
}
