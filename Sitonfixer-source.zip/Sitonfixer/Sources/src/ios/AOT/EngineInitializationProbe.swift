// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Combine
import Darwin

/// Process-wide research latch. A hung/failed core initialization cannot be
/// cancelled safely, retried or overlapped with a title by leaving Settings.
@MainActor final class EngineInitializationProbe: ObservableObject {
    static let shared = EngineInitializationProbe()
    @Published private(set) var claimed = false
    @Published private(set) var running = false
    @Published private(set) var result: String?
    private static let markerKey = "sitonfixer.initializationProbe.phase"

    private init() {
        if UserDefaults.standard.string(forKey: Self.markerKey) == "initializing" {
            result = "SF-INIT: el intento anterior no llegó a registrar su resultado. Puede haberse cerrado o interrumpido la app; este dato no identifica la causa."
        }
    }

    // Called only by GameManager after checking idle/no pending launch. Both
    // check and claim run on MainActor, before the first suspension point.
    func runWhenIdle(usingInterpreter: Bool = false) async -> String {
        guard !claimed else { return result ?? "SF-INIT: cierra y vuelve a abrir la app antes de repetir." }
        guard ResearchOperationGate.acquire() else {
            let message = "SF-INIT: otra prueba sigue activa. Espera a que termine antes de intentarlo."
            result = message; return message
        }
        // Deliberately never release the gate for this process, including errors.
        claimed = true; running = true
        result = "Inicializando Cemu y su memoria real. No abras juegos; espera el resultado."
        UserDefaults.standard.set("initializing", forKey: Self.markerKey)
        let message = await Task.detached(priority: .userInitiated) {
            do { return try Self.runBlocking(usingInterpreter: usingInterpreter) }
            catch { return (usingInterpreter ? "SF-INTERP: " : "SF-INIT: ") + error.localizedDescription }
        }.value
        UserDefaults.standard.set("returned", forKey: Self.markerKey)
        result = message; running = false
        return message
    }

    nonisolated private static func runBlocking(usingInterpreter: Bool) throws -> String {
        try OfflineProbe.requireCleanProcess()
        let root = Bundle.main.privateFrameworksPath ?? ""
        guard let core = dlopen(root + "/Cemu.framework/Cemu", RTLD_NOW | RTLD_LOCAL) else {
            throw OfflineProbe.Failure(message: "no se puede abrir el motor de esta instalación.")
        }
        defer { dlclose(core) }
        guard let symbol = dlsym(core, usingInterpreter ? "sitonfixer_interpreter_probe" : "sitonfixer_initialization_probe") else {
            throw OfflineProbe.Failure(message: "esta revisión no incluye la prueba de inicialización.")
        }
        typealias Probe = @convention(c) (UnsafePointer<CChar>?, UnsafeMutablePointer<UInt32>?) -> Int32
        let documents = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask,
                                                   appropriateFor: nil, create: false)
        let mlc = documents.appendingPathComponent("mlc", isDirectory: true)
        try FileManager.default.createDirectory(at: mlc, withIntermediateDirectories: true)
        var checks: UInt32 = 0
        var completed: UInt32 = 0, executed: UInt32 = 0
        let code: Int32
        if usingInterpreter {
            typealias InterpreterProbe = @convention(c) (UnsafePointer<CChar>?, UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt32>?, UnsafeMutablePointer<UInt32>?) -> Int32
            let probe = unsafeBitCast(symbol, to: InterpreterProbe.self)
            code = mlc.path.withCString { probe($0, &checks, &completed, &executed) }
        } else {
            let probe = unsafeBitCast(symbol, to: Probe.self)
            code = mlc.path.withCString { probe($0, &checks) }
        }
        try OfflineProbe.requireCleanProcess()
        if usingInterpreter {
            guard code == 0, checks == 255, completed == 32, executed == 320 else {
                throw OfflineProbe.Failure(message: "intérprete no validado (código \(code), máscara \(checks)/255, casos \(completed)/32, instrucciones \(executed)/320). Cierra la app antes de continuar.")
            }
            return "Intérprete real de Cemu correcto: inicialización con 8 condiciones, 32 casos y 320 instrucciones PowerPC, llamada A → B → continuación de A y RAM big-endian en un bloque de 4 KiB asignado por Cemu, sin JIT ni depurador. No integra todavía módulos firmados con el intérprete, juegos, rendimiento ni renovación. Cierra completamente la app antes de continuar."
        }
        guard code == 0, checks == 255 else {
            throw OfflineProbe.Failure(message: "inicialización no validada (código \(code), máscara \(checks)/255). Cierra la app antes de continuar.")
        }
        return "Inicialización real de Cemu correcta: 8 condiciones verificadas, núcleo y puente preparados, base de memoria y dos zonas iniciales mapeadas, intérprete seleccionado, sin título, JIT ni depurador. No ejecuta instrucciones de juego ni demuestra rendimiento o renovación. Cierra completamente la app antes de continuar."
    }
}
