// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation
import Darwin

/// A loaded image with scoped entry borrowing. Pointers must not escape withEntry.
/// Game publication still needs a session owner spanning all native worker threads.
final class SignedCodeModule {
    struct Failure: LocalizedError {
        let message: String
        var errorDescription: String? { message }
    }
    let identifier: UUID
    let fileURL: URL
    private let base: UnsafeMutableRawPointer
    private let allowedEntries: Set<Int>
    private let validateProcess: () throws -> Void
    private let lifetime: ModuleLifetime
    var phase: ModuleLifetime.Phase { lifetime.phase }

    private init(image: SignedCodeImage, handle: UnsafeMutableRawPointer, entry: UnsafeMutableRawPointer,
                 folder: URL, file: URL, validate: @escaping () throws -> Void) {
        identifier = image.identifier; base = entry; allowedEntries = image.allowedEntries
        fileURL = file; validateProcess = validate
        lifetime = ModuleLifetime {
            // Balanced ownership. dyld is allowed to retain an image after dlclose.
            dlclose(handle)
            try? FileManager.default.removeItem(at: folder)
        }
    }

    static func load(image: SignedCodeImage, sign: (URL) throws -> Void,
                     validate: @escaping () throws -> Void) throws -> SignedCodeModule {
        #if os(iOS)
        let expectedPlatform: UInt32 = 2
        #elseif os(macOS)
        let expectedPlatform: UInt32 = 1
        #else
        let expectedPlatform: UInt32 = 0
        #endif
        guard image.platform == expectedPlatform else { throw ScalarTranslation.Failure.malformed }
        try validate()
        let folder = FileManager.default.temporaryDirectory.appendingPathComponent("SitonfixerModule-" + image.identifier.uuidString, isDirectory: true)
        // mkdir is exclusive: failure must not clean up a directory owned by another
        // live module with the same identity (FileManager may accept an existing dir).
        guard folder.path.withCString({ mkdir($0, mode_t(0o700)) }) == 0 else {
            throw Failure(message: "SF-LIFE: no se puede crear un directorio exclusivo para el módulo.")
        }
        var transferred = false
        defer { if !transferred { try? FileManager.default.removeItem(at: folder) } }
        let file = folder.appendingPathComponent("scalar-probe.dylib")
        try image.bytes.write(to: file, options: .withoutOverwriting)
        try sign(file)
        try validate()
        guard let handle = dlopen(file.path, RTLD_NOW | RTLD_LOCAL) else {
            let detail = dlerror().map { String(cString: $0) } ?? "Sin detalle del cargador."
            let redacted = detail.replacingOccurrences(of: folder.path, with: "<módulo>")
                .replacingOccurrences(of: "/(?:private/)?var/(?:mobile/Containers|containers)/[^\\s'\"),]+", with: "<contenedor>", options: .regularExpression)
                .replacingOccurrences(of: "[0-9a-fA-F]{8}-(?:[0-9a-fA-F]{4}-){3}[0-9a-fA-F]{12}", with: "<id>", options: .regularExpression)
                .replacingOccurrences(of: "\\b[A-Z0-9]{10}\\b", with: "<equipo>", options: .regularExpression)
            throw Failure(message: "SF-LOAD: el sistema ha rechazado cargar el módulo firmado.\n" + String(redacted.prefix(1024)))
        }
        guard let entry = dlsym(handle, "sitonfixer_aot_probe") else {
            dlclose(handle)
            throw Failure(message: "SF-LIFE: falta la entrada del módulo.")
        }
        let module = SignedCodeModule(image: image, handle: handle, entry: entry, folder: folder, file: file, validate: validate)
        transferred = true
        return module
    }

    func withEntry<T>(at offset: Int, _ action: (UnsafeMutableRawPointer) throws -> T) throws -> T {
        guard allowedEntries.contains(offset) else { throw ScalarTranslation.Failure.malformed }
        let token = try lifetime.beginCall()
        defer { lifetime.endCall(token) }
        try validateProcess()
        let value = try action(base.advanced(by: offset))
        try validateProcess()
        return value
    }
    func requestClose() { lifetime.requestClose() }
    deinit { lifetime.requestClose() }
}
