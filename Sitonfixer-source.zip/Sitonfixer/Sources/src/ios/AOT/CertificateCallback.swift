// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

enum CertificateCallback {
    struct Payload { let certificate: Data; let password: String }
    static func parse(_ url: URL, nonce: String?, deadline: Date?, now: Date = Date()) -> Payload? {
        guard url.absoluteString.utf8.count <= 1_500_000,
              url.scheme?.lowercased() == "sitonfixer-aot", url.host?.lowercased() == "certificate",
              url.path.isEmpty, url.user == nil, url.password == nil, url.port == nil, url.fragment == nil,
              let nonce, !nonce.isEmpty, let deadline, deadline > now,
              let components = URLComponents(url: url, resolvingAgainstBaseURL: false),
              let items = components.queryItems, items.count == 3,
              Set(items.map(\.name)) == Set(["nonce", "cert", "password"]),
              items.first(where: { $0.name == "nonce" })?.value == nonce,
              let encoded = items.first(where: { $0.name == "cert" })?.value,
              let password = items.first(where: { $0.name == "password" })?.value,
              password.utf8.count <= 4096, !password.contains("\0"),
              let certificate = Data(base64Encoded: encoded),
              !certificate.isEmpty, certificate.count <= 1_048_576 else { return nil }
        return Payload(certificate: certificate, password: password)
    }
}
