// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
import Foundation

/// Borrowed calls keep the resource alive. Closing prevents new calls immediately;
/// finalization runs once, outside the lock, after the last borrowed call ends.
final class ModuleLifetime {
    enum Failure: Error { case closed }
    enum Phase: Equatable { case open, closing, closed }
    private let lock = NSLock()
    private var current = Phase.open
    private var borrowers = Set<UUID>()
    private var finalizer: (() -> Void)?

    init(finalize: @escaping () -> Void) { finalizer = finalize }
    var phase: Phase {
        lock.lock(); defer { lock.unlock() }
        return current
    }
    func beginCall() throws -> UUID {
        lock.lock(); defer { lock.unlock() }
        guard current == .open else { throw Failure.closed }
        let token = UUID()
        borrowers.insert(token)
        return token
    }
    func endCall(_ token: UUID) {
        lock.lock()
        guard borrowers.remove(token) != nil else { lock.unlock(); return }
        let action = takeFinalizerIfReady()
        lock.unlock()
        action?()
    }
    func requestClose() {
        lock.lock()
        if current == .open { current = .closing }
        let action = takeFinalizerIfReady()
        lock.unlock()
        action?()
    }
    private func takeFinalizerIfReady() -> (() -> Void)? {
        guard current == .closing, borrowers.isEmpty else { return nil }
        current = .closed
        let action = finalizer
        finalizer = nil
        return action
    }
    deinit { requestClose() }
}
