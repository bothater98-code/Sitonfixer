// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
// Derive the library's CodeDirectory identifier from this host's exact profile.
pub(crate) fn identifier<'a>(app_id: &'a str, team: &str) -> Result<&'a str, &'static str> {
    if team.is_empty() { return Err("The installed profile has no team"); }
    let bundle = app_id.strip_prefix(team).and_then(|rest| rest.strip_prefix('.'))
        .ok_or("The installed profile's application identifier belongs to another team")?;
    if bundle.is_empty() || bundle.split('.').any(|part| part.is_empty() ||
        !part.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'-')) {
        return Err("The probe requires an exact application profile, not a wildcard");
    }
    Ok(bundle)
}

#[cfg(test)]
mod tests {
    use super::identifier;
    #[test]
    fn keeps_the_hosts_full_bundle_id_including_free_signing_suffix() {
        assert_eq!(identifier("TESTTEAM12.com.example.app.TESTTEAM12", "TESTTEAM12").unwrap(), "com.example.app.TESTTEAM12");
    }
    #[test]
    fn rejects_wrong_team_without_accepting_a_prefix_collision() {
        assert!(identifier("TESTTEAM123.com.example.app", "TESTTEAM12").is_err());
        assert!(identifier("OTHERTEAM1.com.example.app", "TESTTEAM12").is_err());
    }
    #[test]
    fn rejects_wildcards_empty_and_malformed_ids() {
        for value in ["TESTTEAM12.*", "TESTTEAM12.com.example.*", "TESTTEAM12.",
            "TESTTEAM12.com..app", "TESTTEAM12.com.example/app"] {
            assert!(identifier(value,"TESTTEAM12").is_err());
        }
        assert!(identifier(".com.example.app", "").is_err());
    }
}
