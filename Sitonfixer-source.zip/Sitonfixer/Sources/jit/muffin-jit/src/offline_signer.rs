// Sitonfixer research. SPDX-License-Identifier: GPL-3.0-only
// Pure local signing: deliberately has no link, Tokio runtime, Apple login or network call.
use std::ffi::{c_char, CStr};
use std::path::Path;
use apple_codesign_quick::{MachOSigningConfig, ProvisioningProfile, RustCryptoCmsSigner, sign_macho_file};
use x509_cert::der::Encode;
use crate::{set_err, MjStatus};

#[no_mangle]
pub unsafe extern "C" fn sitonfixer_sign_probe(
    path: *const c_char, p12: *const u8, p12_len: usize,
    password: *const c_char, profile: *const u8, profile_len: usize,
    out_error: *mut *mut c_char,
) -> i32 {
    if path.is_null() || p12.is_null() || password.is_null() || profile.is_null()
        || p12_len == 0 || p12_len > 1_048_576 || profile_len == 0 || profile_len > 1_048_576 {
        set_err(out_error, "Invalid local signing input");
        return MjStatus::InvalidArg as i32;
    }
    let result = (|| -> Result<(), String> {
        let path = CStr::from_ptr(path).to_str().map_err(|_| "Invalid path")?;
        let path = Path::new(path);
        // This ABI only signs the disposable probe, never the installed app or arbitrary bundles.
        if path.file_name().and_then(|p| p.to_str()) != Some("scalar-probe.dylib") {
            return Err("Only the disposable scalar probe can be signed".into());
        }
        let password = CStr::from_ptr(password).to_str().map_err(|_| "Invalid password encoding")?;
        let profile = ProvisioningProfile::parse(std::slice::from_raw_parts(profile, profile_len))
            .map_err(|_| "Cannot parse this installation's provisioning profile")?;
        if profile.plist().get("ExpirationDate").and_then(|v| v.as_date())
            .map(|date| std::time::SystemTime::from(date) <= std::time::SystemTime::now()).unwrap_or(true) {
            return Err("This installation's provisioning profile has expired".into());
        }
        let identity = crate::installer::read_identity(std::slice::from_raw_parts(p12, p12_len), password)
            .map_err(|_| "Cannot open the certificate and private key; check the password")?;
        let certificate_der = identity.certificate.to_der().map_err(|_| "Cannot encode certificate")?;
        if !profile.plist().get("DeveloperCertificates").and_then(|v| v.as_array())
            .map(|list| list.iter().any(|v| v.as_data() == Some(certificate_der.as_slice()))).unwrap_or(false) {
            return Err("Use the certificate that signed this installation".into());
        }
        let chain = identity.profile_to_certificate_chain(&profile)
            .map_err(|_| "The certificate is incompatible with the installed profile")?;
        let signer = RustCryptoCmsSigner::new(identity.private_key, identity.certificate, chain);
        let app_id = profile.entitlements().get("application-identifier").and_then(|v| v.as_string())
            .ok_or("The installed profile has no application identifier")?;
        let identifier = crate::probe_identity::identifier(app_id, profile.team_id())?;
        let entitlements = plist::Dictionary::new();
        let config = MachOSigningConfig::new(identifier, profile.team_id(), &entitlements, Some(&signer));
        sign_macho_file(path, &config).map_err(|_| "Local signing of the generated function failed")?;
        Ok(())
    })();
    match result {
        Ok(()) => 0,
        Err(error) => { set_err(out_error, error); MjStatus::Internal as i32 }
    }
}
